package vn.zembo.app.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow
import vn.zembo.app.domain.LedgerEvent

@Entity(tableName = "account")
data class AccountEntity(
    @PrimaryKey val id: Int,
    val snapshot: String,
)

@Entity(tableName = "ledger")
data class LedgerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val step: Long,
    val type: String,
    val asset: String?,
    val quantity: String?,
    val price: String?,
    val phoDelta: String,
    val fee: String,
    val orderId: Long?,
)

fun LedgerEvent.toEntity(): LedgerEntity = LedgerEntity(
    step = step,
    type = type.name,
    asset = asset?.symbol,
    quantity = quantity?.toPlainString(),
    price = price?.toPlainString(),
    phoDelta = phoDelta.toPlainString(),
    fee = fee.toPlainString(),
    orderId = orderId,
)

@Dao
interface ZemboDao {
    @Query("SELECT snapshot FROM account WHERE id = 1")
    suspend fun snapshot(): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSnapshot(entity: AccountEntity)

    @Insert
    suspend fun insertLedger(items: List<LedgerEntity>)

    @Query("SELECT * FROM ledger ORDER BY id DESC LIMIT 500")
    fun observeLedger(): Flow<List<LedgerEntity>>

    @Query("DELETE FROM ledger")
    suspend fun clearLedger()
}

@Database(entities = [AccountEntity::class, LedgerEntity::class], version = 1, exportSchema = false)
abstract class ZemboDatabase : RoomDatabase() {
    abstract fun dao(): ZemboDao
}
