package vn.zembo.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import vn.zembo.app.domain.AccountState
import vn.zembo.app.domain.Lessons

@Composable
fun LearnScreen(state: AccountState, onOpenLesson: (String) -> Unit) {
    val done = Lessons.all.count { it.id in state.completedLessons }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { ScreenHeader("Học tập") }
        item {
            Text(
                text = "Đã hoàn thành $done/${Lessons.all.size} bài. Nội dung mang tính giáo dục, không phải lời khuyên đầu tư.",
                style = MaterialTheme.typography.bodyMedium,
            )
        }
        items(Lessons.all.size) { index ->
            val lesson = Lessons.all[index]
            val completed = lesson.id in state.completedLessons
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenLesson(lesson.id) },
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Bài ${index + 1}", style = MaterialTheme.typography.labelMedium)
                        Text(lesson.title, fontWeight = FontWeight.SemiBold)
                    }
                    Text(
                        text = if (completed) "Đã học" else "Chưa học",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (completed) gainColor(true) else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
fun LessonScreen(lessonId: String, completed: Boolean, onComplete: () -> Unit, onBack: () -> Unit) {
    val lesson = Lessons.byId(lessonId)
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { ScreenHeader(lesson?.title ?: "Bài học", onBack) }
        if (lesson == null) {
            item { Text("Không tìm thấy bài học.") }
        } else {
            items(lesson.paragraphs.size) { index ->
                Text(lesson.paragraphs[index], style = MaterialTheme.typography.bodyLarge)
            }
            item {
                Button(onClick = onComplete, enabled = !completed, modifier = Modifier.fillMaxWidth()) {
                    Text(if (completed) "Đã đánh dấu đã học" else "Đánh dấu đã học")
                }
            }
        }
    }
}
