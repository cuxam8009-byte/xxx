package vn.zembo.app.domain

import java.math.BigDecimal
import java.math.RoundingMode

sealed interface OrderType {
    data object Market : OrderType
    data class Limit(val price: BigDecimal) : OrderType
}

data class Quote(val asset: Asset, val price: BigDecimal, val step: Long)

enum class Reject {
    INVALID_QUANTITY,
    INVALID_LIMIT_PRICE,
    BELOW_MIN_NOTIONAL,
    INSUFFICIENT_PHO,
    INSUFFICIENT_ASSET,
    QUOTE_EXPIRED,
    ORDER_NOT_FOUND,
    INVALID_AMOUNT,
    DUPLICATE_REQUEST,
    NOT_READY,
}

enum class LedgerType { PRACTICE_FUNDS, BUY, SELL, ORDER_PLACED, ORDER_CANCELLED }

/** phoDelta is the change in total PHO (available plus locked), so reserving funds for an order is zero. */
data class LedgerEvent(
    val step: Long,
    val type: LedgerType,
    val asset: Asset?,
    val quantity: BigDecimal?,
    val price: BigDecimal?,
    val phoDelta: BigDecimal,
    val fee: BigDecimal,
    val orderId: Long?,
)

data class Preview(
    val asset: Asset,
    val side: Side,
    val type: OrderType,
    val quantity: BigDecimal,
    val price: BigDecimal,
    val notional: BigDecimal,
    val fee: BigDecimal,
    val total: BigDecimal,
    val fillsNow: Boolean,
)

sealed interface PreviewResult {
    data class Ok(val preview: Preview) : PreviewResult
    data class Bad(val reason: Reject) : PreviewResult
}

sealed interface Outcome {
    data class Done(val state: AccountState, val events: List<LedgerEvent>) : Outcome
    data class Rejected(val reason: Reject) : Outcome
}

data class Processed(val state: AccountState, val events: List<LedgerEvent>)

object TradingEngine {
    const val QUOTE_TTL_STEPS = 15L
    const val SAMPLE_EVERY_STEPS = 5L
    const val MAX_BACKFILL_STEPS = 86_400L
    val MAX_PRACTICE_FUNDS: BigDecimal = BigDecimal("1000000")

    fun preview(
        state: AccountState,
        quote: Quote,
        side: Side,
        type: OrderType,
        quantity: BigDecimal,
    ): PreviewResult {
        val asset = quote.asset
        if (quantity.signum() <= 0 || quantity.compareTo(Money.floorTo(quantity, asset.quantityScale)) != 0) {
            return PreviewResult.Bad(Reject.INVALID_QUANTITY)
        }
        var price = quote.price
        var fillsNow = true
        if (type is OrderType.Limit) {
            val limit = type.price
            if (limit.signum() <= 0 || limit.compareTo(Money.floorTo(limit, asset.priceScale)) != 0) {
                return PreviewResult.Bad(Reject.INVALID_LIMIT_PRICE)
            }
            val crosses = if (side == Side.BUY) {
                limit.compareTo(quote.price) >= 0
            } else {
                limit.compareTo(quote.price) <= 0
            }
            if (!crosses) {
                price = limit
                fillsNow = false
            }
        }
        val raw = price.multiply(quantity)
        val notional = if (side == Side.BUY) Money.up(raw) else Money.down(raw)
        if (notional.compareTo(Money.MIN_NOTIONAL) < 0) {
            return PreviewResult.Bad(Reject.BELOW_MIN_NOTIONAL)
        }
        val fee = Money.fee(notional)
        val total = if (side == Side.BUY) notional.add(fee) else notional.subtract(fee)
        if (side == Side.BUY) {
            if (total.compareTo(state.spotPho) > 0) return PreviewResult.Bad(Reject.INSUFFICIENT_PHO)
        } else if (quantity.compareTo(state.holding(asset)) > 0) {
            return PreviewResult.Bad(Reject.INSUFFICIENT_ASSET)
        }
        return PreviewResult.Ok(Preview(asset, side, type, quantity, price, notional, fee, total, fillsNow))
    }

    fun place(
        state: AccountState,
        quote: Quote,
        nowStep: Long,
        side: Side,
        type: OrderType,
        quantity: BigDecimal,
    ): Outcome {
        if (nowStep - quote.step > QUOTE_TTL_STEPS) return Outcome.Rejected(Reject.QUOTE_EXPIRED)
        val preview = when (val result = preview(state, quote, side, type, quantity)) {
            is PreviewResult.Bad -> return Outcome.Rejected(result.reason)
            is PreviewResult.Ok -> result.preview
        }
        return if (preview.fillsNow) fillNow(state, preview, nowStep) else rest(state, preview, nowStep)
    }

    private fun fillNow(state: AccountState, preview: Preview, step: Long): Outcome {
        val holdings = state.holdings.toMutableMap()
        val next: AccountState
        val delta: BigDecimal
        val type: LedgerType
        if (preview.side == Side.BUY) {
            holdings[preview.asset] = state.holding(preview.asset).add(preview.quantity)
            next = state.copy(spotPho = state.spotPho.subtract(preview.total), holdings = holdings)
            delta = preview.total.negate()
            type = LedgerType.BUY
        } else {
            holdings[preview.asset] = state.holding(preview.asset).subtract(preview.quantity)
            next = state.copy(spotPho = state.spotPho.add(preview.total), holdings = holdings)
            delta = preview.total
            type = LedgerType.SELL
        }
        val event = LedgerEvent(step, type, preview.asset, preview.quantity, preview.price, delta, preview.fee, null)
        return Outcome.Done(next, listOf(event))
    }

    private fun rest(state: AccountState, preview: Preview, step: Long): Outcome {
        val id = state.nextOrderId
        val isBuy = preview.side == Side.BUY
        val order = PendingOrder(
            id = id,
            asset = preview.asset,
            side = preview.side,
            quantity = preview.quantity,
            limitPrice = preview.price,
            reservedPho = if (isBuy) preview.total else Money.ZERO,
            placedStep = step,
        )
        val holdings = state.holdings.toMutableMap()
        val spot = if (isBuy) {
            state.spotPho.subtract(preview.total)
        } else {
            holdings[preview.asset] = state.holding(preview.asset).subtract(preview.quantity)
            state.spotPho
        }
        val next = state.copy(
            spotPho = spot,
            holdings = holdings,
            orders = state.orders + order,
            nextOrderId = id + 1,
            scanStep = if (state.orders.isEmpty()) step else state.scanStep,
        )
        val event = LedgerEvent(
            step, LedgerType.ORDER_PLACED, preview.asset, preview.quantity, preview.price, Money.ZERO, Money.ZERO, id,
        )
        return Outcome.Done(next, listOf(event))
    }

    fun cancel(state: AccountState, orderId: Long, step: Long): Outcome {
        val order = state.orders.firstOrNull { it.id == orderId }
            ?: return Outcome.Rejected(Reject.ORDER_NOT_FOUND)
        val remaining = state.orders.filter { it.id != orderId }
        val next = if (order.side == Side.BUY) {
            state.copy(spotPho = state.spotPho.add(order.reservedPho), orders = remaining)
        } else {
            val holdings = state.holdings.toMutableMap()
            holdings[order.asset] = state.holding(order.asset).add(order.quantity)
            state.copy(holdings = holdings, orders = remaining)
        }
        val event = LedgerEvent(
            step, LedgerType.ORDER_CANCELLED, order.asset, order.quantity, order.limitPrice,
            Money.ZERO, Money.ZERO, order.id,
        )
        return Outcome.Done(next, listOf(event))
    }

    /** Samples prices every SAMPLE_EVERY_STEPS up to toStep, so orders also fill for time the app was closed. */
    fun process(state: AccountState, prices: PriceSource, toStep: Long): Processed {
        if (state.orders.isEmpty()) {
            return Processed(state.copy(scanStep = maxOf(state.scanStep, toStep)), emptyList())
        }
        var current = state
        val events = mutableListOf<LedgerEvent>()
        var cursor = maxOf(state.scanStep, toStep - MAX_BACKFILL_STEPS)
        while (cursor < toStep && current.orders.isNotEmpty()) {
            cursor = minOf(cursor + SAMPLE_EVERY_STEPS, toStep)
            for (order in current.orders.sortedBy { it.id }) {
                if (cursor <= order.placedStep) continue
                val price = prices.priceAt(order.asset, cursor)
                val crossed = if (order.side == Side.BUY) {
                    price.compareTo(order.limitPrice) <= 0
                } else {
                    price.compareTo(order.limitPrice) >= 0
                }
                if (!crossed) continue
                val (next, event) = fill(current, order, price, cursor)
                current = next
                events.add(event)
            }
        }
        return Processed(current.copy(scanStep = maxOf(current.scanStep, toStep)), events)
    }

    private fun fill(
        state: AccountState,
        order: PendingOrder,
        price: BigDecimal,
        step: Long,
    ): Pair<AccountState, LedgerEvent> {
        val remaining = state.orders.filter { it.id != order.id }
        return if (order.side == Side.BUY) {
            val cost = Money.up(price.multiply(order.quantity))
            val fee = Money.fee(cost)
            val total = cost.add(fee)
            val refund = order.reservedPho.subtract(total)
            check(refund.signum() >= 0) { "Fill cost exceeds reserved funds" }
            val holdings = state.holdings.toMutableMap()
            holdings[order.asset] = state.holding(order.asset).add(order.quantity)
            val next = state.copy(spotPho = state.spotPho.add(refund), holdings = holdings, orders = remaining)
            next to LedgerEvent(step, LedgerType.BUY, order.asset, order.quantity, price, total.negate(), fee, order.id)
        } else {
            val proceeds = Money.down(price.multiply(order.quantity))
            val fee = Money.fee(proceeds)
            val net = proceeds.subtract(fee)
            val next = state.copy(spotPho = state.spotPho.add(net), orders = remaining)
            next to LedgerEvent(step, LedgerType.SELL, order.asset, order.quantity, price, net, fee, order.id)
        }
    }

    fun addPracticeFunds(state: AccountState, amount: BigDecimal, step: Long): Outcome {
        if (amount.signum() <= 0 || amount.compareTo(MAX_PRACTICE_FUNDS) > 0) {
            return Outcome.Rejected(Reject.INVALID_AMOUNT)
        }
        val value = Money.down(amount)
        val next = state.copy(
            spotPho = state.spotPho.add(value),
            netContributed = state.netContributed.add(value),
        )
        val event = LedgerEvent(step, LedgerType.PRACTICE_FUNDS, null, null, null, value, Money.ZERO, null)
        return Outcome.Done(next, listOf(event))
    }

    fun maxBuyQuantity(state: AccountState, asset: Asset, price: BigDecimal): BigDecimal {
        if (price.signum() <= 0) return BigDecimal.ZERO
        val perUnit = price.multiply(BigDecimal.ONE.add(Money.FEE_RATE))
        var qty = Money.floorTo(state.spotPho.divide(perUnit, 12, RoundingMode.DOWN), asset.quantityScale)
        while (qty.signum() > 0 && buyTotal(qty, price).compareTo(state.spotPho) > 0) {
            qty = qty.subtract(asset.quantityStep)
        }
        return if (qty.signum() < 0) BigDecimal.ZERO else qty
    }

    private fun buyTotal(quantity: BigDecimal, price: BigDecimal): BigDecimal {
        val notional = Money.up(price.multiply(quantity))
        return notional.add(Money.fee(notional))
    }
}
