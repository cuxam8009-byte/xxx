package vn.zembo.app.ui

import vn.zembo.app.domain.Asset
import java.math.BigDecimal
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Fmt {
    private val locale: Locale = Locale.forLanguageTag("vi-VN")

    private fun formatter(minDigits: Int, maxDigits: Int): NumberFormat =
        NumberFormat.getNumberInstance(locale).apply {
            minimumFractionDigits = minDigits
            maximumFractionDigits = maxDigits
        }

    fun pho(value: BigDecimal): String = formatter(2, 2).format(value) + " PHO"

    fun signedPho(value: BigDecimal): String = (if (value.signum() > 0) "+" else "") + pho(value)

    fun quantity(value: BigDecimal, asset: Asset): String = formatter(0, asset.quantityScale).format(value)

    fun price(value: BigDecimal, asset: Asset): String =
        formatter(asset.priceScale, asset.priceScale).format(value)

    fun percent(value: Double): String = (if (value > 0) "+" else "") + formatter(2, 2).format(value) + "%"

    fun dateTime(epochSeconds: Long): String =
        SimpleDateFormat("dd/MM/yyyy HH:mm", locale).format(Date(epochSeconds * 1000))
}
