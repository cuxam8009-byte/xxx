package vn.zembo.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import vn.zembo.app.domain.AccountState
import vn.zembo.app.domain.Asset

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("home", "Trang chủ", Icons.Filled.Home),
    Tab("market", "Thị trường", Icons.Filled.Search),
    Tab("trade", "Giao dịch", Icons.Filled.ShoppingCart),
    Tab("learn", "Học tập", Icons.Filled.Info),
    Tab("wallet", "Ví", Icons.Filled.AccountBox),
)

private fun NavController.goTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun ZemboRoot(vm: AppViewModel = viewModel()) {
    val account by vm.account.collectAsStateWithLifecycle()
    val failed by vm.loadFailed.collectAsStateWithLifecycle()
    val step by vm.step.collectAsStateWithLifecycle()

    LaunchedEffect(step) { vm.onTick(step) }

    val state = account
    when {
        failed -> LoadErrorScreen(onReset = vm::resetAll)
        state == null -> LoadingScreen()
        !state.onboardingDone -> OnboardingScreen(onFinish = vm::finishOnboarding)
        else -> MainScaffold(vm, state, step)
    }
}

@Composable
private fun LoadingScreen() {
    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            CircularProgressIndicator()
        }
    }
}

@Composable
private fun LoadErrorScreen(onReset: () -> Unit) {
    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
        ) {
            Text("Không đọc được dữ liệu", style = MaterialTheme.typography.headlineSmall)
            Text(
                "Dữ liệu luyện tập đã lưu bị lỗi hoặc không tương thích với phiên bản này. " +
                    "Bạn có thể đặt lại để bắt đầu với 100.000 PHO mô phỏng. Thao tác này xóa dữ liệu cũ.",
            )
            Button(onClick = onReset) { Text("Đặt lại dữ liệu luyện tập") }
        }
    }
}

@Composable
private fun MainScaffold(vm: AppViewModel, state: AccountState, step: Long) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val showBar = tabs.any { it.route == route }
    val go: (String) -> Unit = { target ->
        if (tabs.any { it.route == target }) nav.goTab(target) else nav.navigate(target)
    }
    val openAsset: (Asset) -> Unit = { asset -> nav.navigate("asset/${asset.symbol}") }

    Scaffold(
        bottomBar = {
            if (showBar) {
                NavigationBar {
                    tabs.forEach { tab ->
                        NavigationBarItem(
                            selected = route == tab.route,
                            onClick = { nav.goTab(tab.route) },
                            icon = { Icon(tab.icon, contentDescription = null) },
                            label = { Text(tab.label) },
                        )
                    }
                }
            }
        },
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = "home",
            modifier = Modifier.padding(padding),
        ) {
            composable("home") {
                HomeScreen(state, step, vm.prices, openAsset, vm::toggleWatch, go)
            }
            composable("market") {
                MarketScreen(state, step, vm.prices, openAsset, vm::toggleWatch)
            }
            composable("asset/{symbol}") { entry ->
                val asset = Asset.fromSymbol(entry.arguments?.getString("symbol") ?: "") ?: Asset.BTC
                AssetScreen(
                    asset = asset,
                    state = state,
                    step = step,
                    prices = vm.prices,
                    onBack = { nav.popBackStack() },
                    onToggleWatch = { vm.toggleWatch(asset) },
                    onTrade = {
                        vm.selectAsset(asset)
                        nav.goTab("trade")
                    },
                )
            }
            composable("trade") { TradeScreen(vm, state, step) }
            composable("learn") { LearnScreen(state) { id -> nav.navigate("lesson/$id") } }
            composable("lesson/{id}") { entry ->
                val id = entry.arguments?.getString("id") ?: ""
                LessonScreen(
                    lessonId = id,
                    completed = id in state.completedLessons,
                    onComplete = { vm.completeLesson(id) },
                    onBack = { nav.popBackStack() },
                )
            }
            composable("wallet") {
                WalletScreen(vm, state, step, onOpenHistory = { nav.navigate("history") })
            }
            composable("history") { HistoryScreen(vm, onBack = { nav.popBackStack() }) }
        }
    }
}
