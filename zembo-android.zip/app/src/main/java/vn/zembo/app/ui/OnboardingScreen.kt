package vn.zembo.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val onboardingPages = listOf(
    "Chào mừng đến với Zembo" to
        "Zembo giúp bạn tìm hiểu thị trường tiền mã hóa và tập giao dịch trong môi trường an toàn.",
    "PHO là tiền mô phỏng" to
        "Bạn bắt đầu với 100.000 PHO. Đây không phải tiền thật, không thể nạp hay rút. " +
        "Giá trong ứng dụng cũng là giá mô phỏng, không phải giá thị trường thật.",
    "Bắt đầu như thế nào?" to
        "Xem thị trường, đặt lệnh đầu tiên và đọc các bài học ngắn về phí, lệnh chờ và rủi ro. " +
        "Kết quả luyện tập không đảm bảo kết quả khi giao dịch thật.",
)

@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    var page by rememberSaveable { mutableStateOf(0) }
    val (title, body) = onboardingPages[page]
    val last = page == onboardingPages.lastIndex

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
        ) {
            Text(
                text = "Bước ${page + 1}/${onboardingPages.size}",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
            )
            Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(body, style = MaterialTheme.typography.bodyLarge)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TextButton(onClick = onFinish) { Text("Bỏ qua") }
                Button(onClick = { if (last) onFinish() else page += 1 }) {
                    Text(if (last) "Bắt đầu" else "Tiếp tục")
                }
            }
        }
    }
}
