package vn.zembo.app.domain

import java.math.BigDecimal

enum class Side { BUY, SELL }

data class PendingOrder(
    val id: Long,
    val asset: Asset,
    val side: Side,
    val quantity: BigDecimal,
    val limitPrice: BigDecimal,
    val reservedPho: BigDecimal,
    val placedStep: Long,
)

data class AccountState(
    val spotPho: BigDecimal,
    val holdings: Map<Asset, BigDecimal>,
    val orders: List<PendingOrder>,
    val nextOrderId: Long,
    val netContributed: BigDecimal,
    val scanStep: Long,
    val watchlist: Set<Asset>,
    val completedLessons: Set<String>,
    val onboardingDone: Boolean,
) {
    val lockedPho: BigDecimal
        get() = orders.filter { it.side == Side.BUY }.fold(Money.ZERO) { acc, o -> acc.add(o.reservedPho) }

    fun holding(asset: Asset): BigDecimal = holdings[asset] ?: BigDecimal.ZERO

    fun lockedQuantity(asset: Asset): BigDecimal =
        orders
            .filter { it.side == Side.SELL && it.asset == asset }
            .fold(BigDecimal.ZERO) { acc, o -> acc.add(o.quantity) }

    fun totalQuantity(asset: Asset): BigDecimal = holding(asset).add(lockedQuantity(asset))

    fun equity(priceOf: (Asset) -> BigDecimal): BigDecimal =
        Asset.entries.fold(spotPho.add(lockedPho)) { acc, asset ->
            acc.add(totalQuantity(asset).multiply(priceOf(asset)))
        }

    companion object {
        val INITIAL_PHO: BigDecimal = BigDecimal("100000").setScale(Money.SCALE)

        fun initial(): AccountState = AccountState(
            spotPho = INITIAL_PHO,
            holdings = emptyMap(),
            orders = emptyList(),
            nextOrderId = 1L,
            netContributed = INITIAL_PHO,
            scanStep = 0L,
            watchlist = emptySet(),
            completedLessons = emptySet(),
            onboardingDone = false,
        )
    }
}
