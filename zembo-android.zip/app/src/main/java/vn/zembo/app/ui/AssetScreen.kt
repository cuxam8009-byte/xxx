package vn.zembo.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import vn.zembo.app.domain.AccountState
import vn.zembo.app.domain.Asset
import vn.zembo.app.domain.PriceSource
import vn.zembo.app.domain.changePercent
import java.math.BigDecimal

private data class ChartRange(val label: String, val seconds: Long)

private val chartRanges = listOf(
    ChartRange("1 giờ", 3_600L),
    ChartRange("6 giờ", 21_600L),
    ChartRange("24 giờ", 86_400L),
)

@Composable
fun AssetScreen(
    asset: Asset,
    state: AccountState,
    step: Long,
    prices: PriceSource,
    onBack: () -> Unit,
    onToggleWatch: () -> Unit,
    onTrade: () -> Unit,
) {
    var rangeIndex by rememberSaveable { mutableStateOf(0) }
    val range = chartRanges[rangeIndex]
    val price = prices.priceAt(asset, step)
    val change = prices.changePercent(asset, step)
    val points = remember(asset, rangeIndex, step / 10) {
        (0..59).map { i ->
            prices.priceAt(asset, step - range.seconds + range.seconds * i / 59).toDouble()
        }
    }
    val watched = asset in state.watchlist
    val up = points.last() >= points.first()
    val owned = state.totalQuantity(asset)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { ScreenHeader("${asset.symbol}/PHO", onBack) }
                IconButton(onClick = onToggleWatch) {
                    Icon(
                        imageVector = if (watched) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = if (watched) "Bỏ theo dõi ${asset.symbol}" else "Theo dõi ${asset.symbol}",
                        tint = if (watched) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(asset.displayName, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    text = "${Fmt.price(price, asset)} PHO",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    text = "${Fmt.percent(change)} so với 24 giờ trước (mô phỏng)",
                    color = gainColor(change >= 0),
                )
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                chartRanges.forEachIndexed { index, r ->
                    FilterChip(
                        selected = index == rangeIndex,
                        onClick = { rangeIndex = index },
                        label = { Text(r.label) },
                    )
                }
            }
        }
        item {
            PriceChart(
                points = points,
                color = gainColor(up),
                description = "Biểu đồ giá mô phỏng ${asset.symbol} trong ${range.label}",
            )
        }
        item {
            Column {
                InfoRow("Cao nhất trong khoảng", Fmt.price(BigDecimal.valueOf(points.max()), asset))
                InfoRow("Thấp nhất trong khoảng", Fmt.price(BigDecimal.valueOf(points.min()), asset))
                InfoRow("Bạn đang nắm giữ", "${Fmt.quantity(owned, asset)} ${asset.symbol}")
            }
        }
        item {
            Text(
                text = "Giá do ứng dụng mô phỏng, không phải giá thị trường thật.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onTrade, modifier = Modifier.weight(1f)) { Text("Giao dịch ${asset.symbol}") }
                OutlinedButton(onClick = onToggleWatch, modifier = Modifier.weight(1f)) {
                    Text(if (watched) "Bỏ theo dõi" else "Theo dõi")
                }
            }
        }
    }
}
