package vn.zembo.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import vn.zembo.app.domain.Asset
import java.math.BigDecimal

@Composable
fun SimulatedBanner(modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
    ) {
        Text(
            text = "PHO và giá trong Zembo đều là mô phỏng. Không dùng tiền thật.",
            modifier = Modifier.padding(12.dp),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
        )
    }
}

@Composable
fun gainColor(positive: Boolean): Color {
    val dark = isSystemInDarkTheme()
    return if (positive) {
        if (dark) Color(0xFF2AD39A) else Color(0xFF0B7A52)
    } else {
        if (dark) Color(0xFFFF6B7F) else Color(0xFFC62F44)
    }
}

fun assetColor(asset: Asset): Color = when (asset) {
    Asset.BTC -> Color(0xFFB45F06)
    Asset.ETH -> Color(0xFF4A5FC1)
    Asset.SOL -> Color(0xFF6B3FB8)
    Asset.XRP -> Color(0xFF2F3A44)
    Asset.BNB -> Color(0xFF8A6A00)
    Asset.DOGE -> Color(0xFF7A6200)
}

@Composable
fun AssetBadge(asset: Asset) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(assetColor(asset)),
        contentAlignment = Alignment.Center,
    ) {
        Text(asset.symbol.take(1), color = Color.White, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun InfoRow(label: String, value: String, valueColor: Color = Color.Unspecified) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            color = valueColor,
        )
    }
}

@Composable
fun ScreenHeader(title: String, onBack: (() -> Unit)? = null) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại")
            }
        }
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
        )
    }
}

@Composable
fun AssetRow(
    asset: Asset,
    price: BigDecimal,
    changePct: Double,
    watched: Boolean,
    onClick: () -> Unit,
    onToggleWatch: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AssetBadge(asset)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("${asset.symbol}/PHO", fontWeight = FontWeight.SemiBold)
            Text(
                text = asset.displayName,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(Fmt.price(price, asset), fontWeight = FontWeight.SemiBold)
            Text(
                text = Fmt.percent(changePct),
                style = MaterialTheme.typography.bodySmall,
                color = gainColor(changePct >= 0),
            )
        }
        IconButton(onClick = onToggleWatch) {
            Icon(
                imageVector = if (watched) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                contentDescription = if (watched) "Bỏ theo dõi ${asset.symbol}" else "Theo dõi ${asset.symbol}",
                tint = if (watched) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
fun PriceChart(points: List<Double>, color: Color, description: String) {
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .semantics { contentDescription = description },
    ) {
        if (points.size < 2) return@Canvas
        val low = points.min()
        val high = points.max()
        val range = if (high - low < 1e-9) 1.0 else high - low
        val pad = 6.dp.toPx()
        val path = Path()
        points.forEachIndexed { i, value ->
            val x = size.width * i / (points.size - 1)
            val y = pad + (size.height - 2 * pad) * (1f - ((value - low) / range).toFloat())
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, color, style = Stroke(width = 3.dp.toPx()))
    }
}
