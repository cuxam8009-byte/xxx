package vn.zembo.app.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import vn.zembo.app.ZemboApp
import vn.zembo.app.data.LedgerEntity
import vn.zembo.app.domain.AccountState
import vn.zembo.app.domain.Asset
import vn.zembo.app.domain.OrderType
import vn.zembo.app.domain.Outcome
import vn.zembo.app.domain.PriceSource
import vn.zembo.app.domain.Quote
import vn.zembo.app.domain.Side
import java.math.BigDecimal

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val container = getApplication<ZemboApp>().container
    private val repository = container.repository

    val prices: PriceSource = container.prices
    val account: StateFlow<AccountState?> = repository.state
    val loadFailed: StateFlow<Boolean> = repository.loadFailed

    val ledger: StateFlow<List<LedgerEntity>> = repository.ledger.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        emptyList(),
    )

    val step: StateFlow<Long> = flow {
        while (true) {
            emit(System.currentTimeMillis() / 1000)
            delay(1_000)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), System.currentTimeMillis() / 1000)

    var selectedAsset: Asset by mutableStateOf(Asset.BTC)
        private set

    init {
        viewModelScope.launch { repository.load() }
    }

    fun selectAsset(asset: Asset) {
        selectedAsset = asset
    }

    fun onTick(step: Long) {
        viewModelScope.launch { repository.onTick(step) }
    }

    suspend fun place(
        quote: Quote,
        side: Side,
        type: OrderType,
        quantity: BigDecimal,
        requestId: String,
    ): Outcome = repository.place(requestId, quote, side, type, quantity)

    suspend fun cancelOrder(orderId: Long): Outcome = repository.cancel(orderId)

    suspend fun addPracticeFunds(amount: BigDecimal): Outcome = repository.addPracticeFunds(amount)

    fun toggleWatch(asset: Asset) {
        update { s ->
            s.copy(watchlist = if (asset in s.watchlist) s.watchlist - asset else s.watchlist + asset)
        }
    }

    fun completeLesson(id: String) {
        update { it.copy(completedLessons = it.completedLessons + id) }
    }

    fun finishOnboarding() {
        update { it.copy(onboardingDone = true) }
    }

    fun resetAll() {
        viewModelScope.launch { repository.reset() }
    }

    private fun update(transform: (AccountState) -> AccountState) {
        viewModelScope.launch { repository.update(transform) }
    }
}
