package vn.zembo.app.domain

import java.math.BigDecimal

object AccountCodec {
    private const val VERSION = "1"

    fun encode(state: AccountState): String {
        val sb = StringBuilder()
        sb.append("v=").append(VERSION).append('\n')
        sb.append("spot=").append(state.spotPho.toPlainString()).append('\n')
        sb.append("contrib=").append(state.netContributed.toPlainString()).append('\n')
        sb.append("scan=").append(state.scanStep).append('\n')
        sb.append("nextOrder=").append(state.nextOrderId).append('\n')
        sb.append("onboarding=").append(if (state.onboardingDone) "1" else "0").append('\n')
        sb.append("lessons=").append(state.completedLessons.sorted().joinToString(",")).append('\n')
        sb.append("watch=").append(state.watchlist.map { it.symbol }.sorted().joinToString(",")).append('\n')
        for ((asset, quantity) in state.holdings) {
            if (quantity.signum() > 0) {
                sb.append("hold.").append(asset.symbol).append('=').append(quantity.toPlainString()).append('\n')
            }
        }
        for (o in state.orders) {
            val fields = listOf(
                o.id.toString(),
                o.asset.symbol,
                o.side.name,
                o.quantity.toPlainString(),
                o.limitPrice.toPlainString(),
                o.reservedPho.toPlainString(),
                o.placedStep.toString(),
            )
            sb.append("order=").append(fields.joinToString(";")).append('\n')
        }
        return sb.toString()
    }

    fun decode(text: String): AccountState? {
        return try {
            var version: String? = null
            var spot: BigDecimal? = null
            var contrib: BigDecimal? = null
            var scan = 0L
            var nextOrder = 1L
            var onboarding = false
            var lessons = emptySet<String>()
            var watch = emptySet<Asset>()
            val holdings = mutableMapOf<Asset, BigDecimal>()
            val orders = mutableListOf<PendingOrder>()
            for (line in text.lines()) {
                val idx = line.indexOf('=')
                if (idx < 0) continue
                val key = line.substring(0, idx)
                val value = line.substring(idx + 1)
                when {
                    key == "v" -> version = value
                    key == "spot" -> spot = BigDecimal(value)
                    key == "contrib" -> contrib = BigDecimal(value)
                    key == "scan" -> scan = value.toLong()
                    key == "nextOrder" -> nextOrder = value.toLong()
                    key == "onboarding" -> onboarding = value == "1"
                    key == "lessons" -> lessons = value.split(",").filter { it.isNotEmpty() }.toSet()
                    key == "watch" -> watch = value.split(",").filter { it.isNotEmpty() }
                        .map { requireNotNull(Asset.fromSymbol(it)) }.toSet()
                    key.startsWith("hold.") -> {
                        val asset = requireNotNull(Asset.fromSymbol(key.removePrefix("hold.")))
                        holdings[asset] = BigDecimal(value)
                    }
                    key == "order" -> {
                        val f = value.split(";")
                        require(f.size == 7)
                        orders.add(
                            PendingOrder(
                                id = f[0].toLong(),
                                asset = requireNotNull(Asset.fromSymbol(f[1])),
                                side = Side.valueOf(f[2]),
                                quantity = BigDecimal(f[3]),
                                limitPrice = BigDecimal(f[4]),
                                reservedPho = BigDecimal(f[5]),
                                placedStep = f[6].toLong(),
                            ),
                        )
                    }
                }
            }
            if (version != VERSION) return null
            AccountState(
                spotPho = requireNotNull(spot),
                holdings = holdings,
                orders = orders,
                nextOrderId = nextOrder,
                netContributed = requireNotNull(contrib),
                scanStep = scan,
                watchlist = watch,
                completedLessons = lessons,
                onboardingDone = onboarding,
            )
        } catch (e: Exception) {
            null
        }
    }
}
