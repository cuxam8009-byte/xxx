package vn.zembo.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Brand = Color(0xFF5B3FE0)

private val LightColors = lightColorScheme(
    primary = Brand,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFEAE6FC),
    onPrimaryContainer = Color(0xFF2B1C8F),
    background = Color(0xFFF5F4FB),
    onBackground = Color(0xFF15132B),
    surface = Color.White,
    onSurface = Color(0xFF15132B),
    error = Color(0xFFC62F44),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFA796FF),
    onPrimary = Color(0xFF1B0F63),
    primaryContainer = Color(0xFF2A2458),
    onPrimaryContainer = Color(0xFFE5DEFF),
    background = Color(0xFF0F0D1F),
    onBackground = Color(0xFFECEAFF),
    surface = Color(0xFF1A1731),
    onSurface = Color(0xFFECEAFF),
    error = Color(0xFFFF6B7F),
)

@Composable
fun ZemboTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content,
    )
}
