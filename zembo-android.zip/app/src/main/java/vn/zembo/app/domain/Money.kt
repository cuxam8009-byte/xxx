package vn.zembo.app.domain

import java.math.BigDecimal
import java.math.RoundingMode

object Money {
    const val SCALE = 8

    val ZERO: BigDecimal = BigDecimal.ZERO.setScale(SCALE)
    val FEE_RATE: BigDecimal = BigDecimal("0.001")
    val MIN_NOTIONAL: BigDecimal = BigDecimal("1")

    fun up(value: BigDecimal): BigDecimal = value.setScale(SCALE, RoundingMode.UP)

    fun down(value: BigDecimal): BigDecimal = value.setScale(SCALE, RoundingMode.DOWN)

    fun fee(base: BigDecimal): BigDecimal = up(base.multiply(FEE_RATE))

    fun floorTo(value: BigDecimal, scale: Int): BigDecimal = value.setScale(scale, RoundingMode.DOWN)
}
