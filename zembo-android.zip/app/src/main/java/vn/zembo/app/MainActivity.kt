package vn.zembo.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import vn.zembo.app.ui.ZemboRoot
import vn.zembo.app.ui.theme.ZemboTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ZemboTheme {
                ZemboRoot()
            }
        }
    }
}
