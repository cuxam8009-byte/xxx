package vn.zembo.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import vn.zembo.app.data.LedgerEntity
import vn.zembo.app.domain.Asset
import vn.zembo.app.domain.LedgerType
import java.math.BigDecimal

private fun describe(entry: LedgerEntity): String {
    val asset = entry.asset?.let { Asset.fromSymbol(it) }
    val quantity = if (asset != null && entry.quantity != null) {
        "${Fmt.quantity(BigDecimal(entry.quantity), asset)} ${asset.symbol}"
    } else {
        ""
    }
    val price = if (asset != null && entry.price != null) {
        " tại ${Fmt.price(BigDecimal(entry.price), asset)}"
    } else {
        ""
    }
    return when (runCatching { LedgerType.valueOf(entry.type) }.getOrNull()) {
        LedgerType.PRACTICE_FUNDS -> "Thêm PHO luyện tập"
        LedgerType.BUY -> "Mua $quantity$price"
        LedgerType.SELL -> "Bán $quantity$price"
        LedgerType.ORDER_PLACED -> "Đặt lệnh chờ $quantity$price"
        LedgerType.ORDER_CANCELLED -> "Hủy lệnh chờ $quantity$price"
        null -> entry.type
    }
}

@Composable
fun HistoryScreen(vm: AppViewModel, onBack: () -> Unit) {
    val entries by vm.ledger.collectAsStateWithLifecycle()
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        item { ScreenHeader("Lịch sử giao dịch", onBack) }
        if (entries.isEmpty()) {
            item { Text("Chưa có giao dịch nào.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        } else {
            items(entries.size) { index ->
                val entry = entries[index]
                val delta = BigDecimal(entry.phoDelta)
                Column(Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(describe(entry), fontWeight = FontWeight.Medium)
                            Text(
                                text = Fmt.dateTime(entry.step) + if (BigDecimal(entry.fee).signum() > 0) {
                                    " · Phí ${Fmt.pho(BigDecimal(entry.fee))}"
                                } else {
                                    ""
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        if (delta.signum() != 0) {
                            Text(
                                text = Fmt.signedPho(delta),
                                fontWeight = FontWeight.SemiBold,
                                color = gainColor(delta.signum() > 0),
                            )
                        }
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}
