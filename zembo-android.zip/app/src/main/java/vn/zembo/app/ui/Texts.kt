package vn.zembo.app.ui

import vn.zembo.app.domain.LedgerType
import vn.zembo.app.domain.Outcome
import vn.zembo.app.domain.Reject
import java.math.BigDecimal

fun rejectText(reason: Reject): String = when (reason) {
    Reject.INVALID_QUANTITY -> "Số lượng không hợp lệ hoặc có quá nhiều chữ số thập phân."
    Reject.INVALID_LIMIT_PRICE -> "Giá giới hạn không hợp lệ."
    Reject.BELOW_MIN_NOTIONAL -> "Giá trị lệnh tối thiểu là 1 PHO."
    Reject.INSUFFICIENT_PHO -> "Không đủ PHO khả dụng."
    Reject.INSUFFICIENT_ASSET -> "Không đủ số lượng tài sản khả dụng."
    Reject.QUOTE_EXPIRED -> "Giá đã hết hạn. Vui lòng xem lại lệnh."
    Reject.ORDER_NOT_FOUND -> "Không tìm thấy lệnh."
    Reject.INVALID_AMOUNT -> "Số tiền không hợp lệ."
    Reject.DUPLICATE_REQUEST -> "Yêu cầu này đã được xử lý."
    Reject.NOT_READY -> "Dữ liệu chưa sẵn sàng."
}

fun describeOutcome(outcome: Outcome): String = when (outcome) {
    is Outcome.Rejected -> rejectText(outcome.reason)
    is Outcome.Done -> when (outcome.events.lastOrNull()?.type) {
        LedgerType.ORDER_PLACED -> "Đã đặt lệnh chờ. Tiền hoặc tài sản được khóa cho đến khi lệnh khớp hoặc bị hủy."
        LedgerType.BUY, LedgerType.SELL -> "Lệnh đã khớp."
        LedgerType.ORDER_CANCELLED -> "Đã hủy lệnh. Tiền hoặc tài sản đã được trả lại."
        LedgerType.PRACTICE_FUNDS -> "Đã thêm PHO luyện tập."
        null -> "Hoàn tất."
    }
}

fun sanitizeDecimal(input: String): String {
    val sb = StringBuilder()
    var seenSeparator = false
    for (c in input) {
        if (c in '0'..'9') {
            sb.append(c)
        } else if ((c == '.' || c == ',') && !seenSeparator) {
            sb.append('.')
            seenSeparator = true
        }
    }
    return sb.toString()
}

fun parseDecimal(text: String): BigDecimal? = text.toBigDecimalOrNull()
