package vn.zembo.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import vn.zembo.app.domain.AccountState
import vn.zembo.app.domain.Asset
import vn.zembo.app.domain.Lessons
import vn.zembo.app.domain.PriceSource
import vn.zembo.app.domain.changePercent
import java.math.RoundingMode

@Composable
fun HomeScreen(
    state: AccountState,
    step: Long,
    prices: PriceSource,
    onOpenAsset: (Asset) -> Unit,
    onToggleWatch: (Asset) -> Unit,
    onGo: (String) -> Unit,
) {
    val equity = state.equity { prices.priceAt(it, step) }
    val profit = equity.subtract(state.netContributed)
    val profitPct = if (state.netContributed.signum() == 0) {
        0.0
    } else {
        profit.divide(state.netContributed, 6, RoundingMode.HALF_UP).toDouble() * 100.0
    }
    val hasHoldings = Asset.entries.any { state.totalQuantity(it).signum() > 0 }
    val nextLesson = Lessons.all.firstOrNull { it.id !in state.completedLessons }
    val watched = state.watchlist.sortedBy { it.ordinal }
    val done = Lessons.all.count { it.id in state.completedLessons }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text("Zembo", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Tổng giá trị luyện tập", style = MaterialTheme.typography.labelLarge)
                    Text(Fmt.pho(equity), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text(
                        text = "Lãi/lỗ so với vốn: ${Fmt.signedPho(profit)} (${Fmt.percent(profitPct)})",
                        color = gainColor(profit.signum() >= 0),
                    )
                    Text("PHO khả dụng: ${Fmt.pho(state.spotPho)}", style = MaterialTheme.typography.bodyMedium)
                    if (state.lockedPho.signum() > 0) {
                        Text("PHO đang khóa cho lệnh chờ: ${Fmt.pho(state.lockedPho)}", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
        item { SimulatedBanner() }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(
                    onClick = { onGo("market") },
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 8.dp),
                ) { Text("Thị trường") }
                FilledTonalButton(
                    onClick = { onGo("trade") },
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 8.dp),
                ) { Text("Giao dịch") }
                FilledTonalButton(
                    onClick = { onGo("learn") },
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 8.dp),
                ) { Text("Học tập") }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Bước tiếp theo", fontWeight = FontWeight.SemiBold)
                    if (!hasHoldings && state.orders.isEmpty()) {
                        Text("Bạn chưa có lệnh nào. Thử đặt lệnh mua đầu tiên bằng PHO mô phỏng.")
                        Button(onClick = { onGo("trade") }) { Text("Đặt lệnh đầu tiên") }
                    } else if (nextLesson != null) {
                        Text("Tiếp tục học: ${nextLesson.title}")
                        Button(onClick = { onGo("lesson/${nextLesson.id}") }) { Text("Mở bài học") }
                    } else {
                        Text("Bạn đã hoàn thành các bài học hiện có. Hãy xem lại lịch sử giao dịch và tiếp tục luyện tập.")
                    }
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Tiến độ học tập: $done/${Lessons.all.size} bài", style = MaterialTheme.typography.bodyMedium)
                LinearProgressIndicator(
                    progress = { done.toFloat() / Lessons.all.size },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
        item { Text("Danh sách theo dõi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
        if (watched.isEmpty()) {
            item { Text("Chưa theo dõi tài sản nào. Mở Thị trường và chạm biểu tượng trái tim để thêm.") }
        } else {
            items(watched) { asset ->
                AssetRow(
                    asset = asset,
                    price = prices.priceAt(asset, step),
                    changePct = prices.changePercent(asset, step),
                    watched = true,
                    onClick = { onOpenAsset(asset) },
                    onToggleWatch = { onToggleWatch(asset) },
                )
            }
        }
    }
}
