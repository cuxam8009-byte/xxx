package vn.zembo.app.domain

data class Lesson(val id: String, val title: String, val paragraphs: List<String>)

object Lessons {
    val all: List<Lesson> = listOf(
        Lesson(
            id = "pho",
            title = "PHO là tiền mô phỏng",
            paragraphs = listOf(
                "PHO (Phở Coin) là đơn vị tiền dùng để luyện tập trong Zembo. Đây không phải tiền thật và không thể nạp vào hay rút ra khỏi ứng dụng.",
                "Giá của BTC, ETH và các tài sản khác trong Zembo cũng là giá mô phỏng do ứng dụng tạo ra. Chúng không phải giá thị trường thật.",
                "Vì vậy kết quả luyện tập trong Zembo không cho biết bạn sẽ có kết quả tương tự khi giao dịch thật.",
            ),
        ),
        Lesson(
            id = "orders",
            title = "Lệnh thị trường và lệnh giới hạn",
            paragraphs = listOf(
                "Lệnh thị trường khớp ngay tại giá đang hiển thị trong bản xem lại lệnh.",
                "Lệnh giới hạn cho phép bạn đặt mức giá tối đa bạn chịu mua, hoặc tối thiểu bạn chịu bán. Nếu giá hiện tại chưa đạt mức đó, lệnh sẽ nằm chờ.",
                "Nếu mức giá giới hạn đã tốt hơn hoặc bằng giá hiện tại, lệnh khớp ngay tại giá hiện tại.",
                "Khi lệnh chờ, tiền (với lệnh mua) hoặc tài sản (với lệnh bán) bị khóa. Bạn có thể hủy lệnh để lấy lại.",
            ),
        ),
        Lesson(
            id = "fees",
            title = "Phí giao dịch",
            paragraphs = listOf(
                "Zembo mô phỏng mức phí 0,1% trên giá trị mỗi lệnh khớp.",
                "Khi mua, tổng chi phí bằng giá trị lệnh cộng phí. Khi bán, số tiền nhận được bằng giá trị lệnh trừ phí.",
                "Giao dịch càng nhiều lần thì tổng phí càng lớn. Hãy luôn xem phí trong bản xem lại lệnh trước khi xác nhận.",
            ),
        ),
        Lesson(
            id = "risk",
            title = "Rủi ro và quy mô lệnh",
            paragraphs = listOf(
                "Không có cách nào đảm bảo lợi nhuận. Giá có thể giảm sau khi bạn mua.",
                "Đặt tất cả vốn vào một tài sản làm tăng rủi ro. Hãy quyết định trước số tiền tối đa bạn chấp nhận mất cho mỗi lệnh.",
                "Đuổi theo giá đang tăng hoặc giao dịch liên tục để gỡ lỗ thường làm thiệt hại lớn hơn.",
            ),
        ),
        Lesson(
            id = "leverage",
            title = "Đòn bẩy và thanh lý (khái niệm)",
            paragraphs = listOf(
                "Đòn bẩy cho phép nắm giữ vị thế lớn hơn số tiền ký quỹ bạn bỏ ra. Nó khuếch đại cả lãi lẫn lỗ.",
                "Nếu khoản lỗ làm cạn ký quỹ, vị thế bị thanh lý và bạn mất khoản ký quỹ đó. Đòn bẩy càng cao thì giá thanh lý càng gần giá vào lệnh.",
                "Giao dịch hợp đồng tương lai chưa có trong phiên bản này. Bài học này chỉ giới thiệu khái niệm.",
            ),
        ),
    )

    fun byId(id: String): Lesson? = all.firstOrNull { it.id == id }
}
