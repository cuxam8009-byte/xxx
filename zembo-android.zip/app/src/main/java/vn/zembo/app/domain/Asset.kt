package vn.zembo.app.domain

import java.math.BigDecimal

enum class Asset(
    val symbol: String,
    val displayName: String,
    val referencePrice: BigDecimal,
    val quantityScale: Int,
    val priceScale: Int,
) {
    BTC("BTC", "Bitcoin", BigDecimal("68432"), 6, 2),
    ETH("ETH", "Ethereum", BigDecimal("3215"), 5, 2),
    SOL("SOL", "Solana", BigDecimal("142.6"), 3, 2),
    XRP("XRP", "XRP", BigDecimal("0.521"), 1, 4),
    BNB("BNB", "BNB", BigDecimal("612.3"), 3, 2),
    DOGE("DOGE", "Dogecoin", BigDecimal("0.156"), 0, 5);

    val quantityStep: BigDecimal
        get() = BigDecimal.ONE.movePointLeft(quantityScale)

    companion object {
        fun fromSymbol(symbol: String): Asset? = entries.firstOrNull { it.symbol == symbol }
    }
}
