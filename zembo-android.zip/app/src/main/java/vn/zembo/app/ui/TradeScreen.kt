package vn.zembo.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import vn.zembo.app.domain.AccountState
import vn.zembo.app.domain.Money
import vn.zembo.app.domain.OrderType
import vn.zembo.app.domain.Outcome
import vn.zembo.app.domain.PendingOrder
import vn.zembo.app.domain.Preview
import vn.zembo.app.domain.PreviewResult
import vn.zembo.app.domain.Quote
import vn.zembo.app.domain.Side
import vn.zembo.app.domain.TradingEngine
import java.math.BigDecimal
import java.util.UUID

private data class PendingConfirm(
    val quote: Quote,
    val side: Side,
    val type: OrderType,
    val quantity: BigDecimal,
    val preview: Preview,
)

@Composable
fun TradeScreen(vm: AppViewModel, state: AccountState, step: Long) {
    val asset = vm.selectedAsset
    var isBuy by rememberSaveable { mutableStateOf(true) }
    var isLimit by rememberSaveable { mutableStateOf(false) }
    var qtyText by rememberSaveable(asset) { mutableStateOf("") }
    var limitText by rememberSaveable(asset) { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf<PendingConfirm?>(null) }
    val scope = rememberCoroutineScope()

    val quote = Quote(asset, vm.prices.priceAt(asset, step), step)
    val side = if (isBuy) Side.BUY else Side.SELL
    val qty = qtyText.toBigDecimalOrNull()
    val limit = limitText.toBigDecimalOrNull()
    val type: OrderType? = if (isLimit) limit?.let { OrderType.Limit(it) } else OrderType.Market
    val result: PreviewResult? =
        if (qty != null && type != null) TradingEngine.preview(state, quote, side, type, qty) else null

    fun applyPercent(percent: Int) {
        val maxQty = if (isBuy) {
            val px = if (isLimit && limit != null && limit.signum() > 0) limit.min(quote.price) else quote.price
            TradingEngine.maxBuyQuantity(state, asset, px)
        } else {
            state.holding(asset)
        }
        val raw = maxQty.multiply(BigDecimal(percent)).divide(BigDecimal(100))
        qtyText = Money.floorTo(raw, asset.quantityScale).toPlainString()
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { ScreenHeader("Giao dịch") }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                vn.zembo.app.domain.Asset.entries.forEach { a ->
                    FilterChip(selected = a == asset, onClick = { vm.selectAsset(a) }, label = { Text(a.symbol) })
                }
            }
        }
        item {
            Text(
                text = "Giá mô phỏng: ${Fmt.price(quote.price, asset)} PHO",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = isBuy, onClick = { isBuy = true }, label = { Text("Mua") })
                    FilterChip(selected = !isBuy, onClick = { isBuy = false }, label = { Text("Bán") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !isLimit, onClick = { isLimit = false }, label = { Text("Thị trường") })
                    FilterChip(selected = isLimit, onClick = { isLimit = true }, label = { Text("Giới hạn") })
                }
            }
        }
        if (isLimit) {
            item {
                OutlinedTextField(
                    value = limitText,
                    onValueChange = { limitText = sanitizeDecimal(it) },
                    label = { Text("Giá giới hạn (PHO)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
        item {
            OutlinedTextField(
                value = qtyText,
                onValueChange = { qtyText = sanitizeDecimal(it) },
                label = { Text("Số lượng (${asset.symbol})") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(25, 50, 75, 100).forEach { percent ->
                    OutlinedButton(
                        onClick = { applyPercent(percent) },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 4.dp),
                    ) {
                        Text("$percent%")
                    }
                }
            }
        }
        item {
            Text(
                text = if (isBuy) {
                    "PHO khả dụng: ${Fmt.pho(state.spotPho)}"
                } else {
                    "${asset.symbol} khả dụng: ${Fmt.quantity(state.holding(asset), asset)}"
                },
                style = MaterialTheme.typography.bodyMedium,
            )
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Xem trước lệnh", fontWeight = FontWeight.SemiBold)
                    when (result) {
                        is PreviewResult.Ok -> {
                            val p = result.preview
                            InfoRow("Cách khớp", if (p.fillsNow) "Khớp ngay tại giá thị trường" else "Lệnh chờ tại giá giới hạn")
                            InfoRow("Giá áp dụng", "${Fmt.price(p.price, asset)} PHO")
                            InfoRow("Giá trị lệnh", Fmt.pho(p.notional))
                            InfoRow("Phí (0,1%)", Fmt.pho(p.fee))
                            InfoRow(if (isBuy) "Tổng chi phí" else "Số tiền nhận", Fmt.pho(p.total))
                        }
                        is PreviewResult.Bad -> Text(rejectText(result.reason), color = MaterialTheme.colorScheme.error)
                        null -> Text(
                            text = "Nhập số lượng" + if (isLimit) " và giá giới hạn" else "",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
        item {
            Button(
                onClick = {
                    if (result is PreviewResult.Ok && qty != null && type != null) {
                        confirm = PendingConfirm(quote, side, type, qty, result.preview)
                    }
                },
                enabled = result is PreviewResult.Ok,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(if (isBuy) "Xem lại và xác nhận mua" else "Xem lại và xác nhận bán")
            }
        }
        val note = message
        if (note != null) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(note, modifier = Modifier.weight(1f))
                        TextButton(onClick = { message = null }) { Text("Đóng") }
                    }
                }
            }
        }
        item { Text("Lệnh đang chờ", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
        if (state.orders.isEmpty()) {
            item { Text("Không có lệnh chờ.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        } else {
            val pendingOrders: List<PendingOrder> = state.orders.sortedByDescending { it.id }
            items(pendingOrders.size) { index ->
                val order = pendingOrders[index]
                Card(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                "${if (order.side == Side.BUY) "Mua" else "Bán"} ${Fmt.quantity(order.quantity, order.asset)} ${order.asset.symbol}",
                                fontWeight = FontWeight.SemiBold,
                            )
                            Text("Giá giới hạn: ${Fmt.price(order.limitPrice, order.asset)} PHO")
                            Text(
                                text = if (order.side == Side.BUY) {
                                    "Đã khóa: ${Fmt.pho(order.reservedPho)}"
                                } else {
                                    "Đã khóa: ${Fmt.quantity(order.quantity, order.asset)} ${order.asset.symbol}"
                                },
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                        OutlinedButton(onClick = {
                            scope.launch { message = describeOutcome(vm.cancelOrder(order.id)) }
                        }) { Text("Hủy") }
                    }
                }
            }
        }
    }

    val pending = confirm
    if (pending != null) {
        val remaining = (TradingEngine.QUOTE_TTL_STEPS - (step - pending.quote.step)).coerceAtLeast(0L)
        val p = pending.preview
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("Xác nhận lệnh") },
            text = {
                Column {
                    InfoRow("Lệnh", "${if (p.side == Side.BUY) "Mua" else "Bán"} ${Fmt.quantity(p.quantity, p.asset)} ${p.asset.symbol}")
                    InfoRow("Cách khớp", if (p.fillsNow) "Khớp ngay" else "Lệnh chờ")
                    InfoRow("Giá áp dụng", "${Fmt.price(p.price, p.asset)} PHO")
                    InfoRow("Giá trị lệnh", Fmt.pho(p.notional))
                    InfoRow("Phí", Fmt.pho(p.fee))
                    InfoRow(if (p.side == Side.BUY) "Tổng chi phí" else "Số tiền nhận", Fmt.pho(p.total))
                    Text(
                        text = "Giá được giữ thêm $remaining giây. Đây là PHO mô phỏng, không phải tiền thật.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = remaining > 0,
                    onClick = {
                        confirm = null
                        scope.launch {
                            val outcome = vm.place(
                                pending.quote,
                                pending.side,
                                pending.type,
                                pending.quantity,
                                UUID.randomUUID().toString(),
                            )
                            message = describeOutcome(outcome)
                            if (outcome is Outcome.Done) qtyText = ""
                        }
                    },
                ) { Text("Xác nhận") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Quay lại") } },
        )
    }
}
