package vn.zembo.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import vn.zembo.app.domain.AccountState
import vn.zembo.app.domain.Asset
import java.math.BigDecimal

private val PRACTICE_TOP_UP = BigDecimal("10000")

@Composable
fun WalletScreen(vm: AppViewModel, state: AccountState, step: Long, onOpenHistory: () -> Unit) {
    var showAdd by remember { mutableStateOf(false) }
    var showReset by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    val equity = state.equity { vm.prices.priceAt(it, step) }
    val held = Asset.entries.filter { state.totalQuantity(it).signum() > 0 }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { ScreenHeader("Ví luyện tập") }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Tổng giá trị", style = MaterialTheme.typography.labelLarge)
                    Text(Fmt.pho(equity), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    InfoRow("PHO khả dụng", Fmt.pho(state.spotPho))
                    InfoRow("PHO đang khóa (lệnh chờ)", Fmt.pho(state.lockedPho))
                    InfoRow("Vốn luyện tập đã nạp", Fmt.pho(state.netContributed))
                }
            }
        }
        item { SimulatedBanner() }
        item { Text("Tài sản", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
        if (held.isEmpty()) {
            item { Text("Chưa có tài sản nào. Đặt lệnh mua ở tab Giao dịch.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        } else {
            items(held.size) { index ->
                val asset = held[index]
                val value = state.totalQuantity(asset).multiply(vm.prices.priceAt(asset, step))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    AssetBadge(asset)
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text(asset.symbol, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = "Khả dụng ${Fmt.quantity(state.holding(asset), asset)}, khóa ${Fmt.quantity(state.lockedQuantity(asset), asset)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(Fmt.quantity(state.totalQuantity(asset), asset), fontWeight = FontWeight.SemiBold)
                        Text(Fmt.pho(value), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        val note = message
        if (note != null) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(note, modifier = Modifier.weight(1f))
                        TextButton(onClick = { message = null }) { Text("Đóng") }
                    }
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onOpenHistory, modifier = Modifier.fillMaxWidth()) { Text("Lịch sử giao dịch") }
                OutlinedButton(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Thêm 10.000 PHO luyện tập")
                }
                OutlinedButton(onClick = { showReset = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Đặt lại dữ liệu luyện tập")
                }
            }
        }
    }

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Thêm PHO luyện tập") },
            text = {
                Text(
                    "Thêm 10.000 PHO mô phỏng vào ví. Đây không phải tiền thật. " +
                        "Số này được tính là vốn luyện tập, không phải lợi nhuận.",
                )
            },
            confirmButton = {
                Button(onClick = {
                    showAdd = false
                    scope.launch { message = describeOutcome(vm.addPracticeFunds(PRACTICE_TOP_UP)) }
                }) { Text("Thêm") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Hủy") } },
        )
    }

    if (showReset) {
        AlertDialog(
            onDismissRequest = { showReset = false },
            title = { Text("Đặt lại dữ liệu luyện tập?") },
            text = {
                Text(
                    "Toàn bộ số dư, lệnh chờ, tài sản, lịch sử giao dịch và tiến độ học sẽ bị xóa. " +
                        "Bạn sẽ bắt đầu lại với 100.000 PHO mô phỏng. Không thể hoàn tác.",
                )
            },
            confirmButton = {
                Button(onClick = {
                    showReset = false
                    vm.resetAll()
                }) { Text("Xóa và đặt lại") }
            },
            dismissButton = { TextButton(onClick = { showReset = false }) { Text("Giữ lại") } },
        )
    }
}
