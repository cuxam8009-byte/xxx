package vn.zembo.app.domain

import java.math.BigDecimal
import java.math.RoundingMode

interface PriceSource {
    fun priceAt(asset: Asset, step: Long): BigDecimal
}

fun PriceSource.changePercent(asset: Asset, step: Long, windowSeconds: Long = 86_400L): Double {
    val now = priceAt(asset, step).toDouble()
    val before = priceAt(asset, step - windowSeconds).toDouble()
    return (now / before - 1.0) * 100.0
}

/**
 * Deterministic simulated prices: a bounded sum of four sine waves whose phases derive from the
 * seed. Not a realistic market model; every value stays within +/-7% of the asset's reference price.
 * The step is wall-clock seconds, so prices are continuous across restarts and need no stored history.
 */
class SimulatedPriceSource(private val seed: Long) : PriceSource {

    override fun priceAt(asset: Asset, step: Long): BigDecimal {
        val t = step.toDouble()
        var x = 0.0
        for (i in AMPLITUDES.indices) {
            x += AMPLITUDES[i] * StrictMath.sin(TWO_PI * t / PERIODS[i] + phase(asset, i))
        }
        val factor = 1.0 + MAX_DEVIATION * x
        return asset.referencePrice
            .multiply(BigDecimal.valueOf(factor))
            .setScale(asset.priceScale, RoundingMode.HALF_UP)
    }

    private fun phase(asset: Asset, index: Int): Double {
        val raw = Math.floorMod(
            seed * 1_000_003L + (asset.ordinal + 1) * 7_919L + (index + 1) * 104_729L,
            6283L,
        )
        return raw / 1000.0
    }

    companion object {
        const val MAX_DEVIATION = 0.07
        private val TWO_PI = 2.0 * Math.PI
        private val AMPLITUDES = doubleArrayOf(0.50, 0.30, 0.15, 0.05)
        private val PERIODS = doubleArrayOf(21_600.0, 5_400.0, 1_020.0, 47.0)
    }
}
