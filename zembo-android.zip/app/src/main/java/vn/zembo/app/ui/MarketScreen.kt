package vn.zembo.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import vn.zembo.app.domain.AccountState
import vn.zembo.app.domain.Asset
import vn.zembo.app.domain.PriceSource
import vn.zembo.app.domain.changePercent

@Composable
fun MarketScreen(
    state: AccountState,
    step: Long,
    prices: PriceSource,
    onOpenAsset: (Asset) -> Unit,
    onToggleWatch: (Asset) -> Unit,
) {
    var query by rememberSaveable { mutableStateOf("") }
    var onlyWatched by rememberSaveable { mutableStateOf(false) }
    val needle = query.trim()
    val shown = Asset.entries.filter { asset ->
        (!onlyWatched || asset in state.watchlist) &&
            (needle.isEmpty() ||
                asset.symbol.contains(needle, ignoreCase = true) ||
                asset.displayName.contains(needle, ignoreCase = true))
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item { ScreenHeader("Thị trường") }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Tìm tài sản") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !onlyWatched, onClick = { onlyWatched = false }, label = { Text("Tất cả") })
                FilterChip(selected = onlyWatched, onClick = { onlyWatched = true }, label = { Text("Theo dõi") })
            }
        }
        if (shown.isEmpty()) {
            item { Text("Không có tài sản phù hợp.") }
        } else {
            items(shown) { asset ->
                AssetRow(
                    asset = asset,
                    price = prices.priceAt(asset, step),
                    changePct = prices.changePercent(asset, step),
                    watched = asset in state.watchlist,
                    onClick = { onOpenAsset(asset) },
                    onToggleWatch = { onToggleWatch(asset) },
                )
            }
        }
        item {
            Text(
                text = "Giá là giá mô phỏng, không phải giá thị trường thật. " +
                    "Mức thay đổi tính so với 24 giờ trước theo cùng mô phỏng.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
