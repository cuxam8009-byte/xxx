package vn.zembo.app

import android.app.Application
import androidx.room.Room
import vn.zembo.app.data.AccountRepository
import vn.zembo.app.data.ZemboDatabase
import vn.zembo.app.domain.PriceSource
import vn.zembo.app.domain.SimulatedPriceSource

class AppContainer(application: Application) {
    val prices: PriceSource = SimulatedPriceSource(PRICE_SEED)

    private val database: ZemboDatabase =
        Room.databaseBuilder(application, ZemboDatabase::class.java, "zembo.db").build()

    val repository = AccountRepository(database, prices)

    private companion object {
        const val PRICE_SEED = 20_260_607L
    }
}

class ZemboApp : Application() {
    val container: AppContainer by lazy { AppContainer(this) }
}
