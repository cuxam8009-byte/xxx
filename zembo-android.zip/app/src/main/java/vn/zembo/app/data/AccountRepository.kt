package vn.zembo.app.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.math.BigDecimal
import vn.zembo.app.domain.AccountCodec
import vn.zembo.app.domain.AccountState
import vn.zembo.app.domain.LedgerEvent
import vn.zembo.app.domain.LedgerType
import vn.zembo.app.domain.Money
import vn.zembo.app.domain.OrderType
import vn.zembo.app.domain.Outcome
import vn.zembo.app.domain.PriceSource
import vn.zembo.app.domain.Quote
import vn.zembo.app.domain.Reject
import vn.zembo.app.domain.Side
import vn.zembo.app.domain.TradingEngine

/**
 * The database is the source of truth. The in-memory state is a write-through copy that is only
 * updated after the transaction (snapshot row plus ledger rows) has committed.
 */
class AccountRepository(
    private val db: ZemboDatabase,
    private val prices: PriceSource,
) {
    private val dao = db.dao()
    private val mutex = Mutex()
    private val seenRequests = HashSet<String>()
    private val mutableState = MutableStateFlow<AccountState?>(null)
    private val mutableLoadFailed = MutableStateFlow(false)

    val state: StateFlow<AccountState?> = mutableState.asStateFlow()
    val loadFailed: StateFlow<Boolean> = mutableLoadFailed.asStateFlow()
    val ledger: Flow<List<LedgerEntity>> = dao.observeLedger()

    private fun nowStep(): Long = System.currentTimeMillis() / 1000

    suspend fun load() {
        mutex.withLock {
            val stored = dao.snapshot()
            if (stored == null) {
                val initial = AccountState.initial()
                persist(initial, listOf(initialFundsEvent(initial)))
            } else {
                val decoded = AccountCodec.decode(stored)
                if (decoded == null) {
                    mutableLoadFailed.value = true
                } else {
                    mutableState.value = decoded
                }
            }
        }
    }

    suspend fun place(
        requestId: String,
        quote: Quote,
        side: Side,
        type: OrderType,
        quantity: BigDecimal,
    ): Outcome = mutex.withLock {
        val current = mutableState.value ?: return@withLock Outcome.Rejected(Reject.NOT_READY)
        if (!seenRequests.add(requestId)) return@withLock Outcome.Rejected(Reject.DUPLICATE_REQUEST)
        val outcome = TradingEngine.place(current, quote, nowStep(), side, type, quantity)
        if (outcome is Outcome.Done) persist(outcome.state, outcome.events)
        outcome
    }

    suspend fun cancel(orderId: Long): Outcome = mutex.withLock {
        val current = mutableState.value ?: return@withLock Outcome.Rejected(Reject.NOT_READY)
        val outcome = TradingEngine.cancel(current, orderId, nowStep())
        if (outcome is Outcome.Done) persist(outcome.state, outcome.events)
        outcome
    }

    suspend fun addPracticeFunds(amount: BigDecimal): Outcome = mutex.withLock {
        val current = mutableState.value ?: return@withLock Outcome.Rejected(Reject.NOT_READY)
        val outcome = TradingEngine.addPracticeFunds(current, amount, nowStep())
        if (outcome is Outcome.Done) persist(outcome.state, outcome.events)
        outcome
    }

    suspend fun update(transform: (AccountState) -> AccountState) {
        mutex.withLock {
            val current = mutableState.value
            if (current != null) persist(transform(current), emptyList())
        }
    }

    suspend fun onTick(step: Long) {
        mutex.withLock {
            val current = mutableState.value
            if (current != null) {
                val processed = TradingEngine.process(current, prices, step)
                if (processed.events.isEmpty()) {
                    mutableState.value = processed.state
                } else {
                    persist(processed.state, processed.events)
                }
            }
        }
    }

    suspend fun reset() {
        mutex.withLock {
            val fresh = AccountState.initial().copy(onboardingDone = true)
            db.withTransaction {
                dao.clearLedger()
                dao.saveSnapshot(AccountEntity(1, AccountCodec.encode(fresh)))
                dao.insertLedger(listOf(initialFundsEvent(fresh).toEntity()))
            }
            seenRequests.clear()
            mutableLoadFailed.value = false
            mutableState.value = fresh
        }
    }

    private fun initialFundsEvent(state: AccountState): LedgerEvent =
        LedgerEvent(nowStep(), LedgerType.PRACTICE_FUNDS, null, null, null, state.spotPho, Money.ZERO, null)

    private suspend fun persist(next: AccountState, events: List<LedgerEvent>) {
        db.withTransaction {
            dao.saveSnapshot(AccountEntity(1, AccountCodec.encode(next)))
            if (events.isNotEmpty()) dao.insertLedger(events.map { it.toEntity() })
        }
        mutableState.value = next
    }
}
