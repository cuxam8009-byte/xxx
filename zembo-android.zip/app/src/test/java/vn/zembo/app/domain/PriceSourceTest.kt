package vn.zembo.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigDecimal

class PriceSourceTest {
    @Test
    fun sameInputsGiveSamePrice() {
        val a = SimulatedPriceSource(1L)
        val b = SimulatedPriceSource(1L)
        for (asset in Asset.entries) {
            assertEquals(a.priceAt(asset, 1_760_000_123L), b.priceAt(asset, 1_760_000_123L))
        }
    }

    @Test
    fun pricesStayWithinSevenPercentOfReference() {
        val source = SimulatedPriceSource(42L)
        for (asset in Asset.entries) {
            val tolerance = BigDecimal.ONE.movePointLeft(asset.priceScale)
            val low = asset.referencePrice.multiply(BigDecimal("0.93")).subtract(tolerance)
            val high = asset.referencePrice.multiply(BigDecimal("1.07")).add(tolerance)
            var step = 1_700_000_000L
            repeat(2_000) {
                val price = source.priceAt(asset, step)
                assertTrue("$asset $price below $low", price.compareTo(low) >= 0)
                assertTrue("$asset $price above $high", price.compareTo(high) <= 0)
                step += 997L
            }
        }
    }

    @Test
    fun differentSeedsGiveDifferentPaths() {
        val a = SimulatedPriceSource(1L)
        val b = SimulatedPriceSource(2L)
        val differs = (0L..50L).any { i ->
            a.priceAt(Asset.BTC, 1_760_000_000L + i * 600) != b.priceAt(Asset.BTC, 1_760_000_000L + i * 600)
        }
        assertTrue(differs)
    }

    @Test
    fun twentyFourHourChangeIsBounded() {
        val source = SimulatedPriceSource(7L)
        for (asset in Asset.entries) {
            val change = source.changePercent(asset, 1_760_000_000L)
            assertTrue("$asset change $change", change > -16.0 && change < 16.0)
        }
    }
}
