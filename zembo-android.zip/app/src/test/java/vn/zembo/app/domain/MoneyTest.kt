package vn.zembo.app.domain

import org.junit.Test

class MoneyTest {
    @Test
    fun feeIsRoundedUpAtEightDecimals() {
        assertBd("1.00000000", Money.fee(bd("1000")))
        assertBd("0.00000001", Money.fee(bd("0.00000001")))
    }

    @Test
    fun costRoundsUpAndProceedsRoundDown() {
        assertBd("0.00000002", Money.up(bd("0.000000011")))
        assertBd("0.00000001", Money.down(bd("0.000000019")))
    }

    @Test
    fun quantityFloorsToScale() {
        assertBd("1.234567", Money.floorTo(bd("1.2345679"), 6))
    }
}
