package vn.zembo.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Random

class TradingEngineTest {
    private val btc = Asset.BTC

    private fun quote(price: String, step: Long = 1_000L) = Quote(btc, bd(price), step)

    private fun buyMarket(state: AccountState, price: String, qty: String, step: Long = 1_000L): Outcome =
        TradingEngine.place(state, quote(price, step), step, Side.BUY, OrderType.Market, bd(qty))

    private fun assertRejected(expected: Reject, outcome: Outcome) {
        assertTrue("expected Rejected but was $outcome", outcome is Outcome.Rejected)
        assertEquals(expected, (outcome as Outcome.Rejected).reason)
    }

    @Test
    fun marketBuyUpdatesBalancesAndLedger() {
        val out = done(buyMarket(AccountState.initial(), "50000.00", "0.5"))
        assertBd("74975", out.state.spotPho)
        assertBd("0.5", out.state.holding(btc))
        val event = out.events.single()
        assertEquals(LedgerType.BUY, event.type)
        assertBd("-25025", event.phoDelta)
        assertBd("25", event.fee)
    }

    @Test
    fun previewTotalMatchesExecutedAmount() {
        val state = AccountState.initial()
        val preview = TradingEngine.preview(state, quote("50000.00"), Side.BUY, OrderType.Market, bd("0.5"))
        val ok = preview as PreviewResult.Ok
        val out = done(buyMarket(state, "50000.00", "0.5"))
        assertEquals(0, ok.preview.total.negate().compareTo(out.events.single().phoDelta))
    }

    @Test
    fun buyRejectedWhenPhoIsInsufficient() {
        assertRejected(Reject.INSUFFICIENT_PHO, buyMarket(AccountState.initial(), "50000.00", "3"))
    }

    @Test
    fun orderBelowMinimumNotionalIsRejected() {
        assertRejected(Reject.BELOW_MIN_NOTIONAL, buyMarket(AccountState.initial(), "50000.00", "0.00001"))
    }

    @Test
    fun invalidQuantitiesAreRejected() {
        val state = AccountState.initial()
        assertRejected(Reject.INVALID_QUANTITY, buyMarket(state, "50000.00", "0.0000001"))
        assertRejected(Reject.INVALID_QUANTITY, buyMarket(state, "50000.00", "0"))
        assertRejected(Reject.INVALID_QUANTITY, buyMarket(state, "50000.00", "-1"))
    }

    @Test
    fun sellUpdatesBalancesAndSubtractsFee() {
        val bought = done(buyMarket(AccountState.initial(), "50000.00", "0.5")).state
        val out = done(
            TradingEngine.place(bought, quote("51000.00", 1_001L), 1_001L, Side.SELL, OrderType.Market, bd("0.2")),
        )
        assertBd("85164.8", out.state.spotPho)
        assertBd("0.3", out.state.holding(btc))
        assertBd("10189.8", out.events.single().phoDelta)
    }

    @Test
    fun sellMoreThanHeldIsRejected() {
        val out = TradingEngine.place(
            AccountState.initial(), quote("50000.00"), 1_000L, Side.SELL, OrderType.Market, bd("0.1"),
        )
        assertRejected(Reject.INSUFFICIENT_ASSET, out)
    }

    @Test
    fun quoteExpiresAfterFifteenSteps() {
        val state = AccountState.initial()
        val late = TradingEngine.place(state, quote("50000.00"), 1_016L, Side.BUY, OrderType.Market, bd("0.1"))
        assertRejected(Reject.QUOTE_EXPIRED, late)
        val onTime = TradingEngine.place(state, quote("50000.00"), 1_015L, Side.BUY, OrderType.Market, bd("0.1"))
        assertTrue(onTime is Outcome.Done)
    }

    @Test
    fun limitBuyBelowMarketRestsAndLocksFunds() {
        val out = done(
            TradingEngine.place(
                AccountState.initial(), quote("50000.00"), 1_000L, Side.BUY,
                OrderType.Limit(bd("48000.00")), bd("1"),
            ),
        )
        assertBd("51952", out.state.spotPho)
        assertBd("48048", out.state.lockedPho)
        assertEquals(1, out.state.orders.size)
        assertEquals(2L, out.state.nextOrderId)
        assertEquals(1_000L, out.state.scanStep)
        val event = out.events.single()
        assertEquals(LedgerType.ORDER_PLACED, event.type)
        assertBd("0", event.phoDelta)
    }

    @Test
    fun marketableLimitBuyFillsAtMarketPriceNotLimitPrice() {
        val out = done(
            TradingEngine.place(
                AccountState.initial(), quote("50000.00"), 1_000L, Side.BUY,
                OrderType.Limit(bd("55000.00")), bd("1"),
            ),
        )
        assertBd("49950", out.state.spotPho)
        assertTrue(out.state.orders.isEmpty())
        assertBd("50000", out.events.single().price!!)
    }

    @Test
    fun restingBuyFillsOnceAtBetterPriceAndRefundsDifference() {
        val placed = done(
            TradingEngine.place(
                AccountState.initial(), quote("50000.00"), 1_000L, Side.BUY,
                OrderType.Limit(bd("48000.00")), bd("1"),
            ),
        ).state
        val prices = FunctionPrices { _, step -> if (step <= 1_010L) bd("50000.00") else bd("47000.00") }

        val processed = TradingEngine.process(placed, prices, 1_020L)

        assertTrue(processed.state.orders.isEmpty())
        assertBd("1", processed.state.holding(btc))
        assertBd("52953", processed.state.spotPho)
        val event = processed.events.single()
        assertEquals(LedgerType.BUY, event.type)
        assertEquals(1_015L, event.step)
        assertBd("47000", event.price!!)
        assertBd("-47047", event.phoDelta)

        val again = TradingEngine.process(processed.state, prices, 1_040L)
        assertTrue(again.events.isEmpty())
        assertBd("1", again.state.holding(btc))
        assertBd("52953", again.state.spotPho)
    }

    @Test
    fun orderCannotFillAtOrBeforeItsPlacementStep() {
        val placed = done(
            TradingEngine.place(
                AccountState.initial(), quote("50000.00"), 1_000L, Side.BUY,
                OrderType.Limit(bd("48000.00")), bd("1"),
            ),
        ).state
        val prices = FunctionPrices { _, _ -> bd("47000.00") }
        val atPlacement = TradingEngine.process(placed, prices, 1_000L)
        assertTrue(atPlacement.events.isEmpty())
        assertEquals(1, atPlacement.state.orders.size)
    }

    @Test
    fun restingSellLocksAssetsAndFillsWhenPriceRises() {
        val holding = done(buyMarket(AccountState.initial(), "50000.00", "1")).state
        val placed = done(
            TradingEngine.place(
                holding, quote("50000.00"), 1_000L, Side.SELL, OrderType.Limit(bd("52000.00")), bd("0.4"),
            ),
        ).state
        assertBd("0.6", placed.holding(btc))
        assertBd("0.4", placed.lockedQuantity(btc))
        assertBd("1", placed.totalQuantity(btc))

        val prices = FunctionPrices { _, step -> if (step <= 1_010L) bd("50000.00") else bd("52500.00") }
        val processed = TradingEngine.process(placed, prices, 1_020L)

        assertTrue(processed.state.orders.isEmpty())
        assertBd("70929", processed.state.spotPho)
        assertBd("0.6", processed.state.holding(btc))
        assertBd("20979", processed.events.single().phoDelta)
    }

    @Test
    fun cancellingBuyReturnsReservedFunds() {
        val placed = done(
            TradingEngine.place(
                AccountState.initial(), quote("50000.00"), 1_000L, Side.BUY,
                OrderType.Limit(bd("48000.00")), bd("1"),
            ),
        ).state
        val cancelled = done(TradingEngine.cancel(placed, 1L, 1_005L))
        assertBd("100000", cancelled.state.spotPho)
        assertTrue(cancelled.state.orders.isEmpty())
        assertEquals(LedgerType.ORDER_CANCELLED, cancelled.events.single().type)
        assertRejected(Reject.ORDER_NOT_FOUND, TradingEngine.cancel(cancelled.state, 1L, 1_006L))
    }

    @Test
    fun cancellingSellReturnsAssets() {
        val holding = done(buyMarket(AccountState.initial(), "50000.00", "1")).state
        val placed = done(
            TradingEngine.place(
                holding, quote("50000.00"), 1_000L, Side.SELL, OrderType.Limit(bd("52000.00")), bd("0.4"),
            ),
        ).state
        val cancelled = done(TradingEngine.cancel(placed, 1L, 1_005L))
        assertBd("1", cancelled.state.holding(btc))
    }

    @Test
    fun practiceFundsAreCapitalNotProfit() {
        val out = done(TradingEngine.addPracticeFunds(AccountState.initial(), bd("10000"), 5L))
        assertBd("110000", out.state.spotPho)
        val equity = out.state.equity { bd("50000.00") }
        assertBd("0", equity.subtract(out.state.netContributed))
    }

    @Test
    fun invalidPracticeFundsAreRejected() {
        val state = AccountState.initial()
        assertRejected(Reject.INVALID_AMOUNT, TradingEngine.addPracticeFunds(state, bd("0"), 5L))
        assertRejected(Reject.INVALID_AMOUNT, TradingEngine.addPracticeFunds(state, bd("-5"), 5L))
        assertRejected(Reject.INVALID_AMOUNT, TradingEngine.addPracticeFunds(state, bd("1000001"), 5L))
    }

    @Test
    fun maxBuyQuantityIsAcceptedAndOneMoreStepIsRejected() {
        val rnd = Random(1L)
        repeat(300) {
            val asset = Asset.entries[rnd.nextInt(Asset.entries.size)]
            val factor = BigDecimal.valueOf(0.93 + rnd.nextInt(141) / 1000.0)
            val price = asset.referencePrice.multiply(factor).setScale(asset.priceScale, RoundingMode.HALF_UP)
            val pho = BigDecimal(10 + rnd.nextInt(99_990)).add(BigDecimal(rnd.nextInt(100)).movePointLeft(2))
            val state = AccountState.initial().copy(spotPho = Money.down(pho))
            val quote = Quote(asset, price, 1L)

            val max = TradingEngine.maxBuyQuantity(state, asset, price)
            assertTrue("max quantity should be positive for $asset at $price with $pho", max.signum() > 0)
            val accepted = TradingEngine.preview(state, quote, Side.BUY, OrderType.Market, max)
            assertTrue("max $max rejected: $accepted", accepted is PreviewResult.Ok)
            val tooMuch = TradingEngine.preview(state, quote, Side.BUY, OrderType.Market, max.add(asset.quantityStep))
            assertEquals(PreviewResult.Bad(Reject.INSUFFICIENT_PHO), tooMuch)
        }
    }

    @Test
    fun randomOperationsPreserveBalancesAndHoldings() {
        val prices = SimulatedPriceSource(7L)
        val rnd = Random(42L)
        var state = AccountState.initial()
        val events = mutableListOf<LedgerEvent>()
        var step = 1_760_000_000L

        fun commit(outcome: Outcome) {
            if (outcome is Outcome.Done) {
                state = outcome.state
                events.addAll(outcome.events)
            }
        }

        fun buyQuantity(asset: Asset, price: BigDecimal): BigDecimal {
            val target = BigDecimal(5 + rnd.nextInt(3_000))
            return Money.floorTo(target.divide(price, 12, RoundingMode.DOWN), asset.quantityScale)
        }

        fun sellQuantity(asset: Asset): BigDecimal {
            val part = state.holding(asset).multiply(BigDecimal(1 + rnd.nextInt(100))).divide(BigDecimal(100))
            return Money.floorTo(part, asset.quantityScale)
        }

        repeat(400) {
            step += 1L + rnd.nextInt(600)
            val asset = Asset.entries[rnd.nextInt(Asset.entries.size)]
            val price = prices.priceAt(asset, step)
            val quote = Quote(asset, price, step)
            when (rnd.nextInt(6)) {
                0 -> commit(TradingEngine.place(state, quote, step, Side.BUY, OrderType.Market, buyQuantity(asset, price)))
                1 -> commit(TradingEngine.place(state, quote, step, Side.SELL, OrderType.Market, sellQuantity(asset)))
                2, 3 -> {
                    val side = if (rnd.nextBoolean()) Side.BUY else Side.SELL
                    val factor = BigDecimal.valueOf(1.0 + (rnd.nextInt(61) - 30) / 1000.0)
                    val limit = price.multiply(factor).setScale(asset.priceScale, RoundingMode.HALF_UP)
                    val qty = if (side == Side.BUY) buyQuantity(asset, price) else sellQuantity(asset)
                    commit(TradingEngine.place(state, quote, step, side, OrderType.Limit(limit), qty))
                }
                4 -> state.orders.firstOrNull()?.let { commit(TradingEngine.cancel(state, it.id, step)) }
                else -> {
                    val processed = TradingEngine.process(state, prices, step)
                    state = processed.state
                    events.addAll(processed.events)
                }
            }
            assertInvariants(state, events)
        }
        assertTrue(events.isNotEmpty())
    }

    private fun assertInvariants(state: AccountState, events: List<LedgerEvent>) {
        val deltas = events.fold(BigDecimal.ZERO) { acc, e -> acc.add(e.phoDelta) }
        val expectedTotal = AccountState.INITIAL_PHO.add(deltas)
        assertEquals(0, expectedTotal.compareTo(state.spotPho.add(state.lockedPho)))
        assertTrue(state.spotPho.signum() >= 0)
        for (asset in Asset.entries) {
            assertTrue(state.holding(asset).signum() >= 0)
            val bought = events
                .filter { it.asset == asset && it.type == LedgerType.BUY }
                .fold(BigDecimal.ZERO) { acc, e -> acc.add(e.quantity!!) }
            val sold = events
                .filter { it.asset == asset && it.type == LedgerType.SELL }
                .fold(BigDecimal.ZERO) { acc, e -> acc.add(e.quantity!!) }
            assertEquals(0, bought.subtract(sold).compareTo(state.totalQuantity(asset)))
        }
    }
}
