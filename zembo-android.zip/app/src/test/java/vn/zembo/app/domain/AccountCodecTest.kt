package vn.zembo.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class AccountCodecTest {
    private fun sample(): AccountState = AccountState.initial().copy(
        spotPho = bd("51952.12345678"),
        holdings = mapOf(Asset.BTC to bd("0.600000"), Asset.DOGE to bd("1200")),
        orders = listOf(
            PendingOrder(3L, Asset.BTC, Side.BUY, bd("1.000000"), bd("48000.00"), bd("48048.00000000"), 1000L),
            PendingOrder(4L, Asset.ETH, Side.SELL, bd("2.50000"), bd("3300.00"), Money.ZERO, 1010L),
        ),
        nextOrderId = 5L,
        netContributed = bd("110000.00000000"),
        scanStep = 1020L,
        watchlist = setOf(Asset.BTC, Asset.SOL),
        completedLessons = setOf("pho", "fees"),
        onboardingDone = true,
    )

    @Test
    fun roundTripPreservesState() {
        val original = sample()
        assertEquals(original, AccountCodec.decode(AccountCodec.encode(original)))
    }

    @Test
    fun initialStateRoundTrips() {
        val original = AccountState.initial()
        assertEquals(original, AccountCodec.decode(AccountCodec.encode(original)))
    }

    @Test
    fun garbageIsRejected() {
        assertNull(AccountCodec.decode("not a snapshot"))
        assertNull(AccountCodec.decode(""))
    }

    @Test
    fun unknownVersionIsRejected() {
        val text = AccountCodec.encode(sample()).replace("v=1", "v=99")
        assertNull(AccountCodec.decode(text))
    }

    @Test
    fun corruptOrderLineIsRejected() {
        val text = AccountCodec.encode(sample()) + "order=1;BTC;BUY\n"
        assertNull(AccountCodec.decode(text))
    }
}
