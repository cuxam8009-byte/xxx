package vn.zembo.app.domain

import org.junit.Assert.assertEquals
import java.math.BigDecimal

fun bd(value: String): BigDecimal = BigDecimal(value)

fun assertBd(expected: String, actual: BigDecimal) {
    assertEquals("expected $expected but was ${actual.toPlainString()}", 0, BigDecimal(expected).compareTo(actual))
}

class FunctionPrices(private val f: (Asset, Long) -> BigDecimal) : PriceSource {
    override fun priceAt(asset: Asset, step: Long): BigDecimal = f(asset, step)
}

fun done(outcome: Outcome): Outcome.Done {
    check(outcome is Outcome.Done) { "expected Done but was $outcome" }
    return outcome
}
