# Zembo (bản 0.1.0)

Ứng dụng Android luyện tập giao dịch với **PHO, tiền mô phỏng**. Không có tiền thật, không nạp/rút thật, không có kết nối mạng (ứng dụng không xin quyền INTERNET). Đây là mô phỏng chạy cục bộ trên máy, không có tài khoản hay máy chủ.

## Build bằng GitHub Actions
1. Tạo repository trên GitHub.
2. Đưa vào repository file `.github/workflows/build.yml` (có sẵn trong zip) và nội dung dự án, hoặc file zip này (workflow tự giải nén).
3. Mở tab **Actions**, chọn lần chạy mới nhất, tải artifact `zembo-debug-apk` (file `app-debug.apk`).
4. Artifact `unit-test-report` chứa báo cáo unit test. Nếu test lỗi, APK vẫn được tạo trước.

Cài APK debug: bật "cài ứng dụng không rõ nguồn gốc" trên điện thoại.

## Đã có trong bản này
Giới thiệu đầu tiên, Trang chủ, Thị trường (tìm kiếm, theo dõi lưu bền vững), chi tiết tài sản và biểu đồ, giao dịch spot (lệnh thị trường và giới hạn, xem trước, xác nhận, hủy lệnh), ví, thêm PHO luyện tập, đặt lại dữ liệu, lịch sử giao dịch, 5 bài học ngắn.

## Chưa có (chủ động hoãn, không giả lập)
Futures, đòn bẩy, thanh lý, chuyển ví Spot/Futures, quy đổi, Earn, vay, thông báo, nhật ký giao dịch, cài đặt/hồ sơ, bảng xếp hạng.

## Mô hình mô phỏng
- Giá: tổng của 4 sóng sin có pha phụ thuộc seed, luôn nằm trong ±7% giá tham chiếu. Giá là hàm của thời gian (giây), nên nhất quán giữa các màn hình và liên tục sau khi mở lại app. Đây **không** phải mô hình thị trường thực tế.
- Phí: 0,1% giá trị lệnh. Phí và chi phí mua làm tròn lên, tiền bán làm tròn xuống (8 chữ số thập phân); số lượng làm tròn xuống theo bước của tài sản. Giá trị lệnh tối thiểu 1 PHO.
- Lệnh thị trường khớp tại giá trong bản xem trước, báo giá hết hạn sau 15 giây.
- Lệnh giới hạn: nếu giá giới hạn đã tốt hơn thị trường thì khớp ngay tại giá thị trường; nếu không thì chờ, khóa tiền hoặc tài sản. Lệnh chờ khớp theo giá lấy mẫu mỗi 5 giây, kể cả khoảng thời gian app đóng (tối đa 24 giờ).
- Lãi/lỗ = tổng giá trị trừ vốn luyện tập (PHO thêm vào được tính là vốn, không phải lãi).
- Dữ liệu lưu bằng Room: mỗi thay đổi (số dư, lệnh, sổ cái) nằm trong một giao dịch cơ sở dữ liệu.

## Cấu trúc
`domain/` logic thuần Kotlin có unit test; `data/` Room và repository; `ui/` Jetpack Compose.
