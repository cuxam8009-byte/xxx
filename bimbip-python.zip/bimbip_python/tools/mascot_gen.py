# Sinh mascot Bìm Bịp: vừa vẽ preview (PIL) vừa xuất code Dart tương ứng
import math, re, os
ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from PIL import Image, ImageDraw

S = 4  # supersample
W = 200

def hexc(v):
    a = (v >> 24) & 255; r = (v >> 16) & 255; g = (v >> 8) & 255; b = v & 255
    return (r, g, b, a)

class Rec:
    def __init__(self):
        self.img = Image.new('RGBA', (W*S, W*S), (0, 0, 0, 0))
        self.dart = []
        self.rots = []  # list of (px,py,angle)
    def _tx(self, x, y):
        for (px, py, a) in reversed(self.rots):
            dx, dy = x - px, y - py
            x = px + dx*math.cos(a) - dy*math.sin(a)
            y = py + dx*math.sin(a) + dy*math.cos(a)
        return x, y
    def _layer(self, drawfn):
        layer = Image.new('RGBA', self.img.size, (0, 0, 0, 0))
        drawfn(ImageDraw.Draw(layer))
        self.img = Image.alpha_composite(self.img, layer)
    def oval(self, cx, cy, rx, ry, col):
        pts = []
        for i in range(72):
            t = 2*math.pi*i/72
            pts.append(self._tx(cx + rx*math.cos(t), cy + ry*math.sin(t)))
        self._layer(lambda d: d.polygon([(x*S, y*S) for x, y in pts], fill=hexc(col)))
        self.dart.append("_oval(c, %s, %s, %s, %s, 0x%08X);" % (cx, cy, rx, ry, col))
    def circle(self, cx, cy, r, col):
        self.oval(cx, cy, r, r, col)
    def _flat(self, d):
        toks = d.split()
        i = 0; subs = []; cur = []; pos = (0, 0)
        while i < len(toks):
            t = toks[i]
            if t == 'M':
                if cur: subs.append(cur)
                pos = (float(toks[i+1]), float(toks[i+2])); cur = [pos]; i += 3
            elif t == 'L':
                pos = (float(toks[i+1]), float(toks[i+2])); cur.append(pos); i += 3
            elif t == 'C':
                x1, y1, x2, y2, x3, y3 = [float(v) for v in toks[i+1:i+7]]
                x0, y0 = pos
                for k in range(1, 25):
                    u = k/24
                    x = (1-u)**3*x0 + 3*(1-u)**2*u*x1 + 3*(1-u)*u*u*x2 + u**3*x3
                    y = (1-u)**3*y0 + 3*(1-u)**2*u*y1 + 3*(1-u)*u*u*y2 + u**3*y3
                    cur.append((x, y))
                pos = (x3, y3); i += 7
            elif t == 'Z':
                i += 1
            else:
                raise ValueError(t)
        if cur: subs.append(cur)
        return subs
    def fill(self, d, col):
        for sub in self._flat(d):
            pts = [self._tx(x, y) for x, y in sub]
            self._layer(lambda dr: dr.polygon([(x*S, y*S) for x, y in pts], fill=hexc(col)))
        self.dart.append("_fill(c, '%s', 0x%08X);" % (d, col))
    def line(self, d, col, w):
        for sub in self._flat(d):
            pts = [self._tx(x, y) for x, y in sub]
            sp = [(x*S, y*S) for x, y in pts]
            def f(dr, sp=sp):
                dr.line(sp, fill=hexc(col), width=int(w*S), joint='curve')
                for (x, y) in (sp[0], sp[-1]):
                    r = w*S/2
                    dr.ellipse([x-r, y-r, x+r, y+r], fill=hexc(col))
            self._layer(f)
        self.dart.append("_line(c, '%s', 0x%08X, %s);" % (d, col, w))
    def rot_begin(self, px, py, a):
        self.rots.append((px, py, a))
        self.dart.append("c.save(); c.translate(%s, %s); c.rotate(%s); c.translate(%s, %s);" % (px, py, a, -px, -py))
    def rot_end(self):
        self.rots.pop()
        self.dart.append("c.restore();")

BLACK = 0xFF2A2830; BELLY = 0xFF3D3A46; SHEEN = 0xFF55515F
CH = 0xFFB4501E; CH_D = 0xFF8A3A12; CH_L = 0xFFD8702C
BEAK = 0xFF5E564D; BEAK_HI = 0xFF8C8276; BEAK_D = 0xFF2E2A26
MOUTH = 0xFFE5505A; TONGUE = 0xFFFF8A8A
WHITE = 0xFFFFFFFF; IRIS = 0xFFE23A2E; PUPIL = 0xFF16161A
FEET = 0xFFFF9600; CHEEK = 0x66FF8A3D; BROW = 0xFFEDE6DA; TEAR = 0xFF7FD6FF

def tail(r):
    r.fill("M 116 142 C 148 142 186 160 197 197 C 168 202 128 192 98 172 Z", BLACK)
    r.line("M 122 154 C 150 158 178 172 188 192", SHEEN, 2.5)
    r.line("M 130 150 C 156 152 176 160 186 172", CH_D, 3)
def body(r):
    r.oval(100, 124, 52, 52, BLACK)
    r.oval(100, 134, 32, 34, BELLY)
    r.oval(80, 177, 15, 6, FEET)
    r.oval(120, 177, 15, 6, FEET)
def wing_l(r):
    r.fill("M 60 98 C 38 108 32 146 50 166 C 60 176 74 166 74 150 C 74 128 72 108 60 98 Z", CH)
    r.line("M 50 122 C 48 136 50 150 56 160", CH_D, 3)
    r.line("M 60 112 C 58 128 60 144 64 156", CH_D, 3)
    r.fill("M 50 166 C 60 176 74 166 74 150 C 66 160 58 164 50 166 Z", CH_L)
def wing_r(r):
    r.fill("M 140 98 C 162 108 168 146 150 166 C 140 176 126 166 126 150 C 126 128 128 108 140 98 Z", CH)
    r.line("M 150 122 C 152 136 150 150 144 160", CH_D, 3)
    r.line("M 140 112 C 142 128 140 144 136 156", CH_D, 3)
    r.fill("M 150 166 C 140 176 126 166 126 150 C 134 160 142 164 150 166 Z", CH_L)
def wings_down(r):
    wing_l(r); wing_r(r)
def wings_up(r):
    r.rot_begin(62, 104, 1.15); wing_l(r); r.rot_end()
    r.rot_begin(138, 104, -1.15); wing_r(r); r.rot_end()
def head(r):
    r.fill("M 90 36 C 86 24 92 18 100 14 C 108 18 114 24 110 36 Z", BLACK)
    r.circle(100, 74, 44, BLACK)
    r.oval(84, 50, 14, 7, SHEEN)
    r.circle(66, 92, 8, CHEEK)
    r.circle(134, 92, 8, CHEEK)

def eye(r, cx, cy, dx=0, dy=0):
    r.circle(cx, cy, 13.5, WHITE)
    r.circle(cx + dx, cy + dy, 9, IRIS)
    r.circle(cx + dx, cy + dy, 5, PUPIL)
    r.circle(cx + dx - 2.5, cy + dy - 3, 2.2, WHITE)
def eye_closed_up(r, cx, cy):  # ∩ vui
    r.line("M %s %s C %s %s %s %s %s %s" % (cx-12, cy+4, cx-8, cy-10, cx+8, cy-10, cx+12, cy+4), WHITE, 4)
def eye_closed_down(r, cx, cy):  # ∪ chớp mắt
    r.line("M %s %s C %s %s %s %s %s %s" % (cx-11, cy-1, cx-7, cy+8, cx+7, cy+8, cx+11, cy-1), WHITE, 4)

def beak_closed(r):
    r.fill("M 100 82 C 86 82 80 92 84 99 C 90 110 110 110 116 99 C 120 92 114 82 100 82 Z", BEAK)
    r.oval(100, 88, 9, 3.5, BEAK_HI)
    r.line("M 85 98 C 94 102 106 102 115 98", BEAK_D, 2.2)
def beak_open(r):
    r.fill("M 100 82 C 86 82 80 90 84 97 C 92 100 108 100 116 97 C 120 90 114 82 100 82 Z", BEAK)
    r.oval(100, 88, 9, 3.2, BEAK_HI)
    r.fill("M 84 99 C 82 112 92 120 100 120 C 108 120 118 112 116 99 C 108 102 92 102 84 99 Z", MOUTH)
    r.oval(100, 113, 8, 4.5, TONGUE)
    # hàm dưới
    r.fill("M 86 106 C 90 118 110 118 114 106 C 108 110 92 110 86 106 Z", BEAK)

def face(r, mood, blink=False):
    L, R = 76, 124
    if blink and mood in ('happy', 'think', 'sad'):
        eye_closed_down(r, L, 68); eye_closed_down(r, R, 68)
    elif mood == 'happy':
        eye(r, L, 68); eye(r, R, 68)
    elif mood == 'wink':
        eye(r, L, 68); eye_closed_up(r, R, 68)
    elif mood == 'cheer':
        eye_closed_up(r, L, 70); eye_closed_up(r, R, 70)
    elif mood == 'think':
        eye(r, L, 68, 3, -3); eye(r, R, 68, 3, -3)
        r.line("M 62 48 C 70 42 82 42 90 48", BROW, 3.5)
        r.line("M 110 52 L 138 50", BROW, 3.5)
    elif mood == 'sad':
        eye(r, L, 70, 0, 3); eye(r, R, 70, 0, 3)
        r.line("M 62 56 L 90 46", BROW, 3.5)
        r.line("M 110 46 L 138 56", BROW, 3.5)
        r.fill("M 64 86 C 60 94 60 100 65 100 C 70 100 70 94 64 86 Z", TEAR)
    if mood == 'cheer': beak_open(r)
    else: beak_closed(r)

def sparkle(r, cx, cy, s, col):
    r.fill("M %s %s C %s %s %s %s %s %s C %s %s %s %s %s %s C %s %s %s %s %s %s C %s %s %s %s %s %s Z" % (
        cx, cy-s, cx+s*0.1, cy-s*0.1, cx+s*0.1, cy-s*0.1, cx+s, cy,
        cx+s*0.1, cy+s*0.1, cx+s*0.1, cy+s*0.1, cx, cy+s,
        cx-s*0.1, cy+s*0.1, cx-s*0.1, cy+s*0.1, cx-s, cy,
        cx-s*0.1, cy-s*0.1, cx-s*0.1, cy-s*0.1, cx, cy-s), col)

def render(mood, blink=False):
    r = Rec()
    tail(r)
    if mood == 'cheer': wings_up(r)
    body(r)
    if mood != 'cheer': wings_down(r)
    head(r)
    face(r, mood, blink)
    if mood == 'cheer':
        sparkle(r, 28, 40, 12, 0xFFFFC800); sparkle(r, 176, 30, 10, 0xFFFF9600); sparkle(r, 172, 100, 7, 0xFFFFC800)
    return r

def gen_func(name, fn):
    r = Rec(); fn(r)
    return "void %s(Canvas c) {\n  %s\n}\n" % (name, "\n  ".join(r.dart))


def face_fn(mood, blink):
    return lambda r: face(r, mood, blink)

def build_dart():
    out = ["// GENERATED by gen/mascot_gen.py - không sửa tay", "part of 'mascot.dart';", ""]
    out.append(gen_func("artTail", tail))
    out.append(gen_func("artBody", body))
    out.append(gen_func("artWingsDown", wings_down))
    out.append(gen_func("artWingsUp", wings_up))
    out.append(gen_func("artHead", head))
    for m in ['happy', 'wink', 'cheer', 'think', 'sad']:
        out.append(gen_func("artFace_" + m, face_fn(m, False)))
    for m in ['happy', 'think', 'sad']:
        out.append(gen_func("artFace_%s_blink" % m, face_fn(m, True)))
    def sp(r):
        sparkle(r, 28, 40, 12, 0xFFFFC800); sparkle(r, 176, 30, 10, 0xFFFF9600); sparkle(r, 172, 100, 7, 0xFFFFC800)
    out.append(gen_func("artSparkles", sp))
    return "\n".join(out)

if __name__ == '__main__':
    import os
    open('' + ROOT + '/lib/widgets/mascot_art.dart', 'w').write(build_dart())
    moods = ['happy', 'wink', 'cheer', 'think', 'sad']
    sheet = Image.new('RGBA', (W*S*3, W*S*2), (255, 244, 214, 255))
    for i, m in enumerate(moods + ['blink']):
        r = render(m if m != 'blink' else 'happy', blink=(m == 'blink'))
        sheet.alpha_composite(r.img, ((i % 3)*W*S, (i//3)*W*S))
    sheet.resize((W*3*2, W*2*2), Image.LANCZOS).save('sheet.png')
    # icon
    base = ROOT + '/assets/icon/res'
    r = render('happy')
    big = 1024
    bg = Image.new('RGBA', (big, big), (255, 200, 0, 255))
    d = ImageDraw.Draw(bg)
    d.ellipse([-200, 520, 1224, 1500], fill=(255, 150, 0, 255))
    bird = r.img.resize((int(big*0.92), int(big*0.92)), Image.LANCZOS)
    bg.alpha_composite(bird, (int(big*0.04), int(big*0.06)))
    os.makedirs(ROOT + '/assets/icon', exist_ok=True)
    bg.save(ROOT + '/assets/icon/icon.png')
    for name, px in [('mdpi', 48), ('hdpi', 72), ('xhdpi', 96), ('xxhdpi', 144), ('xxxhdpi', 192)]:
        os.makedirs('%s/mipmap-%s' % (base, name), exist_ok=True)
        bg.convert('RGB').resize((px, px), Image.LANCZOS).save('%s/mipmap-%s/ic_launcher.png' % (base, name))
