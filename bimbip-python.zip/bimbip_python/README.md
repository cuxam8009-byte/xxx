# 🐦 Bìm Bịp Python

Ứng dụng Android học lập trình **Python** cho người chưa biết gì, giao diện kiểu Duolingo
nhưng tông **cam – vàng**. Linh vật **Bìm Bịp** đồng hành: giảng bài, cổ vũ, an ủi.

## Có gì trong app?

- **6 chương, 18 bài học, ~140 thử thách**: print → biến → phép toán → if/else → vòng lặp → danh sách.
- **12 dạng bài**, không bài nào giống bài nào:

| Dạng | Ý tưởng |
|---|---|
| 🧩 Ghép khối code | Chạm các khối để ghép thành một dòng lệnh |
| ✏️ Điền chỗ trống | Điền từ khoá còn thiếu vào code |
| 🐛 Bìm bắt sâu | Chạm vào dòng code bị lỗi (bug = con sâu) |
| ↕️ Xếp dòng code | Kéo thả các dòng về đúng thứ tự (học thụt lề) |
| 🔮 Đoán kết quả | Bìm chạy code, màn hình hiện gì? |
| 🔍 Xem Bìm chạy code | Chạy từng dòng, nhìn "hộp biến" và màn hình thay đổi |
| 🔗 Nối cặp | Nối khái niệm với ý nghĩa |
| 👆 Vuốt thẻ | Vuốt phải = đúng, trái = sai |
| 🧺 Nhặt đồ vào giỏ | Phân loại giá trị theo kiểu dữ liệu |
| 🗺️ Mê cung của Bìm | Lập trình cho Bìm đi ăn sâu; học `for` qua "số lần" |
| ⌨️ Tự gõ code | Gõ bằng tay, có thanh phím tắt `" ( ) : =` |
| 🎯 Trắc nghiệm | Chọn đáp án |

- Hệ thống 5 tim mỗi bài, câu sai sẽ được **làm lại ở cuối bài**.
- Chuỗi ngày 🔥, "sâu" 🐛 (điểm thưởng), 1–3 sao mỗi bài, huy hiệu.
- **Sân chơi**: luyện riêng từng dạng bài. **Sổ tay**: ôn lại kiến thức đã học.
- Tiến độ được lưu trên máy. Không cần mạng, không quảng cáo.

## Build APK bằng GitHub (không cần cài gì trên máy)

1. Tạo repo mới trên GitHub (Public hay Private đều được).
2. **Add file → Upload files**, kéo thả file `bimbip-python.zip` vào, bấm **Commit changes**.
   *(Không cần giải nén. Hoặc giải nén rồi up cả thư mục cũng được.)*
3. **Add file → Create new file**, đặt tên đúng là `.github/workflows/build-apk.yml`,
   dán nội dung file `build-apk.yml` (đi kèm) vào, bấm **Commit changes**.
   *(Nếu bạn up thư mục đã giải nén thì bước này đã có sẵn, bỏ qua.)*
4. Vào tab **Actions** → chọn **Build APK** → chờ khoảng 8–12 phút cho tới khi có dấu ✅.
   (Nếu không tự chạy: bấm **Run workflow**.)
5. Lấy file APK ở một trong hai nơi:
   - Mục **Releases** (cột bên phải trang repo): bấm `BimBipPython.apk` để tải thẳng về điện thoại.
   - Hoặc trong lần chạy ở tab **Actions** → **Artifacts** → `BimBipPython-APK`.
6. Mở file APK trên điện thoại, cho phép "Cài ứng dụng không rõ nguồn gốc" nếu máy hỏi.

> Mỗi lần bạn sửa code và commit, GitHub tự build lại APK mới.

## Chạy trên máy (tuỳ chọn)

```bash
flutter create --platforms=android --project-name bimbip_python --org vn.bimbip .
flutter pub get
flutter run
```

## Sửa / thêm bài học

Toàn bộ nội dung nằm trong `lib/data/curriculum.dart`. Mỗi bài là một danh sách các bước, ví dụ:

```dart
QuizEx('Màn hình hiện gì?', ['5', '2', '3', 'Lỗi'], 0, code: 'print(2 + 3)'),
BugEx('Chạm vào dòng lỗi', ['print("A")', 'print("B)'], 1),
FillEx('Điền chỗ trống', 'print{0}"Hi"{1}', ['(', ')', '[', '{'], ['(', ')']),
MazeEx('Giúp Bìm', ['B...W'], 1, [[3, 4]]),
```

- Đáp án đúng của `QuizEx` là số thứ tự (bắt đầu từ 0); app tự xáo trộn thứ tự khi hiển thị.
- Trong chữ, đặt `` `code` `` trong dấu huyền để hiện kiểu code.
- Màn "Xem Bìm chạy code" được sinh tự động bằng Python thật: sửa `tools/step_gen.py` rồi chạy
  `python3 tools/step_gen.py` để tạo lại `lib/data/step_data.dart`.
- Linh vật được vẽ bằng code (`tools/mascot_gen.py` → `lib/widgets/mascot_art.dart`), không cần file ảnh.

## Cấu trúc thư mục

```
lib/
  main.dart            Khởi động app
  theme.dart           Bảng màu cam-vàng
  data/                Nội dung bài học
  models/              Các lớp dạng bài, bài học, chương
  state/               Lưu tiến độ (shared_preferences)
  exercises/           Giao diện từng dạng bài
  screens/             Màn hình: đường học, sân chơi, sổ tay, hồ sơ, làm bài
  widgets/             Bìm Bịp, nút nổi khối, khung code tô màu
.github/workflows/     Tự động build APK
```
