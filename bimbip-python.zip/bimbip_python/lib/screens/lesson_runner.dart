import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../exercises/exercise_view.dart';
import '../models/exercise.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../widgets/chunky_button.dart';
import '../widgets/mascot.dart';
import 'result_screen.dart';

enum Phase { answering, correct, wrong }

const List<String> _praise = [
  'Chính xác! 🎉',
  'Tuyệt vời!',
  'Giỏi quá!',
  'Đúng rồi, bịp bịp!',
  'Hay lắm!',
  'Quá đỉnh!',
];

/// Màn hình làm bài: thanh tiến độ, tim, câu hỏi, thanh phản hồi.
class LessonRunner extends StatefulWidget {
  final String title;
  final List<Exercise> items;
  final String? lessonId; // null = luyện tập
  LessonRunner({super.key, required this.title, required this.items, this.lessonId});

  @override
  State<LessonRunner> createState() => _LessonRunnerState();
}

class _LessonRunnerState extends State<LessonRunner> {
  late List<Exercise> queue;
  late ExController ctrl;
  final Set<Exercise> retried = {};
  int index = 0;
  int step = 0;
  int hearts = 5;
  int answered = 0;
  int okCount = 0;
  int mistakes = 0;
  Phase phase = Phase.answering;
  String title = '';
  String sub = '';
  bool dialogOpen = false;

  @override
  void initState() {
    super.initState();
    queue = List<Exercise>.of(widget.items);
    _newCtrl();
  }

  void _newCtrl() {
    ctrl = ExController();
    ctrl.addListener(_onCtrl);
    ctrl.finishCb = _onSelfFinish;
    ctrl.mistakeCb = _onSelfMistake;
  }

  void _onCtrl() {
    if (mounted) setState(() {});
  }

  Exercise get current => queue[index];

  void _restart() {
    setState(() {
      queue = List<Exercise>.of(widget.items);
      retried.clear();
      index = 0;
      step += 1;
      hearts = 5;
      answered = 0;
      okCount = 0;
      mistakes = 0;
      phase = Phase.answering;
      _newCtrl();
    });
  }

  // ---- chấm bài ----
  void _record(bool ok) {
    answered += 1;
    if (ok) {
      okCount += 1;
    } else {
      mistakes += 1;
      final ex = current;
      if (!retried.contains(ex)) {
        retried.add(ex);
        queue.add(ex);
      }
    }
  }

  void _loseHeart() {
    if (hearts > 0) hearts -= 1;
  }

  void _check() {
    final fn = ctrl.checker;
    if (fn == null || phase != Phase.answering) return;
    final ok = fn();
    ctrl.checked = true;
    ctrl.correct = ok;
    _record(ok);
    if (!ok) _loseHeart();
    _feedback(ok);
    setState(() {
      title = ok ? _praise[math.Random().nextInt(_praise.length)] : 'Chưa đúng rồi';
      sub = current.explain;
      phase = ok ? Phase.correct : Phase.wrong;
    });
  }

  void _onSelfMistake() {
    if (ctrl.penalized) return;
    ctrl.penalized = true;
    HapticFeedback.heavyImpact();
    setState(() => _loseHeart());
    if (hearts <= 0) _outOfHearts();
  }

  void _onSelfFinish(bool ok) {
    if (phase != Phase.answering) return;
    ctrl.checked = true;
    ctrl.correct = ok;
    _record(ok);
    _feedback(ok);
    setState(() {
      title = ok ? _praise[math.Random().nextInt(_praise.length)] : 'Xong rồi, có vài lỗi nhỏ';
      sub = ok ? current.explain : 'Bìm sẽ cho bạn làm lại câu này ở cuối bài để nhớ lâu hơn nhé.';
      phase = ok ? Phase.correct : Phase.wrong;
    });
  }

  void _feedback(bool ok) {
    if (ok) {
      HapticFeedback.lightImpact();
    } else {
      HapticFeedback.heavyImpact();
    }
  }

  void _next() {
    if (hearts <= 0) {
      _outOfHearts();
      return;
    }
    if (index + 1 >= queue.length) {
      _finishLesson();
      return;
    }
    setState(() {
      index += 1;
      step += 1;
      phase = Phase.answering;
      _newCtrl();
    });
  }

  void _finishLesson() {
    final total = widget.items.where((e) => !isInfo(e)).length;
    final stars = mistakes == 0 ? 3 : (mistakes <= 2 ? 2 : 1);
    int reward = 10;
    if (widget.lessonId == null) {
      reward = 5;
    } else if (stars == 3) {
      reward = 15;
    }
    final ok = total - math.min(total, mistakes);
    if (widget.lessonId != null) {
      appState.completeLesson(widget.lessonId!, stars, reward, ok, total);
    } else {
      appState.completePractice(reward, ok, total);
    }
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => ResultScreen(stars: stars, reward: reward, ok: ok, total: total, practice: widget.lessonId == null),
      ),
    );
  }

  // ---- hộp thoại ----
  Future<void> _outOfHearts() async {
    if (dialogOpen) return;
    dialogOpen = true;
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Mascot(size: 110, mood: Mood.sad),
              const SizedBox(height: 8),
              Text('Hết tim rồi!', style: ts(24, w: FontWeight.w800)),
              const SizedBox(height: 8),
              Text(
                'Không sao đâu, lập trình viên nào cũng sai nhiều lần. Nghỉ một chút rồi thử lại nhé!',
                textAlign: TextAlign.center,
                style: ts(16, w: FontWeight.w600, c: AppColors.subtext),
              ),
              const SizedBox(height: 18),
              ChunkyButton(
                onPressed: () {
                  Navigator.of(ctx).pop();
                  _restart();
                },
                child: ChunkyButton.label('THỬ LẠI BÀI NÀY'),
              ),
              const SizedBox(height: 8),
              ChunkyButton(
                color: Colors.white,
                shadow: AppColors.border,
                borderColor: AppColors.border,
                onPressed: () {
                  Navigator.of(ctx).pop();
                  Navigator.of(context).pop();
                },
                child: ChunkyButton.label('THOÁT', color: AppColors.subtext),
              ),
            ],
          ),
        ),
      ),
    );
    dialogOpen = false;
  }

  Future<void> _confirmExit() async {
    if (dialogOpen) return;
    dialogOpen = true;
    final leave = await showDialog<bool>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Mascot(size: 100, mood: Mood.think),
              const SizedBox(height: 8),
              Text('Thoát bài học?', style: ts(22, w: FontWeight.w800)),
              const SizedBox(height: 6),
              Text('Tiến độ bài này sẽ không được lưu.',
                  textAlign: TextAlign.center, style: ts(15, w: FontWeight.w600, c: AppColors.subtext)),
              const SizedBox(height: 16),
              ChunkyButton(onPressed: () => Navigator.of(ctx).pop(false), child: ChunkyButton.label('TIẾP TỤC HỌC')),
              const SizedBox(height: 8),
              ChunkyButton(
                color: Colors.white,
                shadow: AppColors.border,
                borderColor: AppColors.border,
                onPressed: () => Navigator.of(ctx).pop(true),
                child: ChunkyButton.label('THOÁT', color: AppColors.red),
              ),
            ],
          ),
        ),
      ),
    );
    dialogOpen = false;
    if (leave == true && mounted) Navigator.of(context).pop();
  }

  // ---- giao diện ----
  Widget _topBar() {
    final p = queue.isEmpty ? 0.0 : index / queue.length;
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 8, 16, 4),
      child: Row(
        children: [
          IconButton(onPressed: _confirmExit, icon: Icon(Icons.close_rounded, color: AppColors.grayDark, size: 30)),
          Expanded(
            child: TweenAnimationBuilder<double>(
              tween: Tween<double>(begin: 0, end: p),
              duration: const Duration(milliseconds: 400),
              builder: (context, v, _) => LayoutBuilder(
                builder: (context, cons) => Stack(
                  children: [
                    Container(
                      height: 16,
                      decoration: BoxDecoration(color: AppColors.gray, borderRadius: BorderRadius.circular(10)),
                    ),
                    Container(
                      height: 16,
                      width: math.max(16.0, cons.maxWidth * v),
                      decoration: BoxDecoration(color: AppColors.yellow, borderRadius: BorderRadius.circular(10)),
                      alignment: Alignment.topCenter,
                      padding: const EdgeInsets.fromLTRB(8, 3, 8, 0),
                      child: Container(
                        height: 4,
                        decoration: BoxDecoration(color: alpha(Colors.white, 0.45), borderRadius: BorderRadius.circular(4)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Icon(Icons.favorite_rounded, color: AppColors.red, size: 26),
          const SizedBox(width: 4),
          Text('$hearts', style: ts(20, w: FontWeight.w800, c: AppColors.red)),
        ],
      ),
    );
  }

  Widget _bottom() {
    final bottomInset = MediaQuery.of(context).padding.bottom;
    final ex = current;

    if (phase == Phase.answering) {
      Widget? button;
      if (isInfo(ex)) {
        button = ChunkyButton(onPressed: _next, child: ChunkyButton.label('TIẾP TỤC'));
      } else if (!isSelfChecking(ex)) {
        button = ChunkyButton(onPressed: ctrl.ready ? _check : null, child: ChunkyButton.label('KIỂM TRA', color: ctrl.ready ? Colors.white : AppColors.grayDark));
      }
      if (button == null) {
        return Container(
          padding: EdgeInsets.fromLTRB(20, 14, 20, 14 + bottomInset),
          decoration: BoxDecoration(border: Border(top: BorderSide(color: AppColors.border, width: 2))),
          child: Text('Hoàn thành thử thách để tiếp tục', textAlign: TextAlign.center, style: ts(14, w: FontWeight.w600, c: AppColors.grayDark)),
        );
      }
      return Container(
        padding: EdgeInsets.fromLTRB(20, 14, 20, 14 + bottomInset),
        decoration: BoxDecoration(border: Border(top: BorderSide(color: AppColors.border, width: 2))),
        child: button,
      );
    }

    final ok = phase == Phase.correct;
    final Color main = ok ? AppColors.greenDark : AppColors.redDark;
    final bool showAnswer = !ok && ctrl.correctText.isNotEmpty;
    return Container(
      width: double.infinity,
      padding: EdgeInsets.fromLTRB(20, 16, 20, 14 + bottomInset),
      color: ok ? AppColors.greenBg : AppColors.redBg,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: ts(22, w: FontWeight.w800, c: main)),
                    if (showAnswer) const SizedBox(height: 6),
                    if (showAnswer) Text('Đáp án đúng:', style: ts(14, c: main)),
                    if (showAnswer) Text(ctrl.correctText, style: TextStyle(fontFamily: 'monospace', fontSize: 15, fontWeight: FontWeight.w700, color: main)),
                    if (sub.isNotEmpty) const SizedBox(height: 6),
                    if (sub.isNotEmpty) Text(sub, style: ts(14, w: FontWeight.w600, c: main, h: 1.35)),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Mascot(size: 64, mood: ok ? Mood.cheer : Mood.sad, animate: false),
            ],
          ),
          const SizedBox(height: 14),
          ChunkyButton(
            color: ok ? AppColors.green : AppColors.red,
            shadow: ok ? AppColors.greenDark : AppColors.redDark,
            onPressed: _next,
            child: ChunkyButton.label('TIẾP TỤC'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) _confirmExit();
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        body: Column(
          children: [
            SafeArea(bottom: false, child: _topBar()),
            Expanded(
              child: SingleChildScrollView(
                keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
                child: KeyedSubtree(
                  key: ValueKey<int>(step),
                  child: buildExercise(current, ctrl),
                ),
              ),
            ),
            _bottom(),
          ],
        ),
      ),
    );
  }
}
