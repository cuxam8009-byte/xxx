import 'package:flutter/material.dart';
import '../theme.dart';
import '../widgets/chunky_button.dart';
import '../widgets/mascot.dart';

class ResultScreen extends StatelessWidget {
  final int stars;
  final int reward;
  final int ok;
  final int total;
  final bool practice;
  ResultScreen({super.key, required this.stars, required this.reward, required this.ok, required this.total, required this.practice});

  String get _quote {
    if (stars >= 3) return 'Không sai câu nào luôn! Bìm bịp phục bạn sát đất!';
    if (stars == 2) return 'Rất tốt! Vài lỗi nhỏ thôi, lần sau sẽ hoàn hảo.';
    return 'Hoàn thành rồi, quan trọng nhất là bạn đã cố gắng! Ôn lại để nhớ lâu hơn nhé.';
  }

  Widget _stat(String emoji, String value, String label, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: color, width: 2),
        ),
        child: Column(
          children: [
            Text(label, style: ts(12, w: FontWeight.w800, c: color)),
            const SizedBox(height: 6),
            Text('$emoji $value', style: ts(22, w: FontWeight.w800, c: color)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final int pct = total == 0 ? 100 : ((ok * 100) / total).round();
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 16, 24, 16),
          child: Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      const SizedBox(height: 12),
                      Mascot(size: 200, mood: Mood.cheer),
                      const SizedBox(height: 8),
                      Text(practice ? 'Luyện tập xong!' : 'Hoàn thành bài học!', style: ts(28, w: FontWeight.w800, c: AppColors.orange)),
                      const SizedBox(height: 14),
                      if (!practice)
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            for (int i = 0; i < 3; i++)
                              Icon(Icons.star_rounded, size: 56, color: i < stars ? AppColors.yellow : AppColors.gray),
                          ],
                        ),
                      const SizedBox(height: 18),
                      Row(
                        children: [
                          _stat('🐛', '+$reward', 'SÂU THU ĐƯỢC', AppColors.green),
                          const SizedBox(width: 12),
                          _stat('🎯', '$pct%', 'CHÍNH XÁC', AppColors.orange),
                        ],
                      ),
                      const SizedBox(height: 22),
                      BimSay(_quote, mood: Mood.wink, size: 80, fontSize: 15),
                    ],
                  ),
                ),
              ),
              ChunkyButton(onPressed: () => Navigator.of(context).pop(), child: ChunkyButton.label('TIẾP TỤC')),
            ],
          ),
        ),
      ),
    );
  }
}
