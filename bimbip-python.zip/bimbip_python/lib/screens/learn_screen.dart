import 'package:flutter/material.dart';
import '../data/curriculum.dart';
import '../models/exercise.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../widgets/chunky_button.dart';
import '../widgets/mascot.dart';
import 'lesson_runner.dart';

class LearnScreen extends StatelessWidget {
  LearnScreen({super.key});

  static const List<double> _offsets = [0, 46, 66, 46, 0, -46, -66, -46];

  Widget _stat(String emoji, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(color: alpha(color, 0.12), borderRadius: BorderRadius.circular(14)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 20)),
          const SizedBox(width: 6),
          Text(value, style: ts(18, w: FontWeight.w800, c: color)),
        ],
      ),
    );
  }

  Widget _topBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Row(
        children: [
          _stat('🔥', '${appState.streakShown}', AppColors.orange),
          Expanded(
            child: Text('Python cùng Bìm', textAlign: TextAlign.center, style: ts(18, w: FontWeight.w800, c: AppColors.orange)),
          ),
          _stat('🐛', '${appState.sau}', AppColors.greenDark),
        ],
      ),
    );
  }

  Widget _unitHeader(Unit u, int number) {
    return Container(
      margin: const EdgeInsets.only(top: 12, bottom: 10),
      padding: const EdgeInsets.fromLTRB(18, 14, 14, 16),
      decoration: BoxDecoration(
        color: u.color,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: u.dark, offset: const Offset(0, 5), blurRadius: 0)],
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('CHƯƠNG $number', style: ts(12, w: FontWeight.w800, c: alpha(Colors.white, 0.85), ls: 1)),
                const SizedBox(height: 2),
                Text(u.title, style: ts(23, w: FontWeight.w800, c: Colors.white)),
                const SizedBox(height: 2),
                Text(u.subtitle, style: ts(14, w: FontWeight.w600, c: alpha(Colors.white, 0.92))),
              ],
            ),
          ),
          Text(u.emoji, style: const TextStyle(fontSize: 44)),
        ],
      ),
    );
  }

  Widget _circle(Color c, Color shadow, Widget icon) {
    return Container(
      width: 76,
      height: 76,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: c,
        boxShadow: [BoxShadow(color: shadow, offset: const Offset(0, 6), blurRadius: 0)],
      ),
      child: Center(child: icon),
    );
  }

  Widget _node(BuildContext context, Unit u, Lesson l, int globalIdx, int currentIdx, int posInUnit) {
    final bool done = appState.isDone(l.id);
    final bool isCurrent = globalIdx == currentIdx;
    final bool locked = !done && !isCurrent;
    final double dx = _offsets[posInUnit % _offsets.length];

    Widget circle;
    if (locked) {
      circle = _circle(AppColors.gray, AppColors.grayDark, Icon(Icons.lock_rounded, color: AppColors.grayDark, size: 32));
    } else {
      circle = _circle(u.color, u.dark, Text(l.icon, style: const TextStyle(fontSize: 34)));
    }

    final int stars = appState.stars[l.id] ?? 0;
    final node = GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => _openSheet(context, u, l, locked, done),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (isCurrent)
            Bob(
              child: Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: u.color, width: 2),
                ),
                child: Text('BẮT ĐẦU', style: ts(13, w: FontWeight.w800, c: u.dark, ls: 0.8)),
              ),
            ),
          circle,
          const SizedBox(height: 8),
          if (done)
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                for (int i = 0; i < 3; i++)
                  Icon(Icons.star_rounded, size: 18, color: i < stars ? AppColors.yellow : AppColors.gray),
              ],
            ),
        ],
      ),
    );

    return SizedBox(
      height: 142,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Transform.translate(offset: Offset(dx, 0), child: node),
          if (isCurrent)
            Align(
              alignment: dx >= 0 ? Alignment.centerLeft : Alignment.centerRight,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                child: Mascot(size: 84, mood: Mood.wink),
              ),
            ),
        ],
      ),
    );
  }

  void _openSheet(BuildContext context, Unit u, Lesson l, bool locked, bool done) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => SafeArea(
        top: false,
        child: Container(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: locked ? AppColors.gray : u.color,
            borderRadius: BorderRadius.circular(24),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(l.title, style: ts(23, w: FontWeight.w800, c: locked ? AppColors.text : Colors.white)),
              const SizedBox(height: 6),
              Text(
                locked ? 'Hoàn thành bài ngay trước đó để mở khoá bài này.' : l.subtitle,
                style: ts(16, w: FontWeight.w600, c: locked ? AppColors.subtext : alpha(Colors.white, 0.95)),
              ),
              if (!locked) const SizedBox(height: 6),
              if (!locked)
                Text('${l.items.length} bước · ${l.items.where((e) => e is! TeachCard && e is! StepEx).length} thử thách',
                    style: ts(14, w: FontWeight.w600, c: alpha(Colors.white, 0.85))),
              const SizedBox(height: 18),
              ChunkyButton(
                color: Colors.white,
                shadow: AppColors.border,
                onPressed: locked
                    ? null
                    : () {
                        Navigator.of(ctx).pop();
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => LessonRunner(title: l.title, items: l.items, lessonId: l.id),
                          ),
                        );
                      },
                child: ChunkyButton.label(
                  locked ? 'ĐÃ KHOÁ 🔒' : (done ? 'ÔN LẠI' : 'BẮT ĐẦU  +10 🐛'),
                  color: locked ? AppColors.grayDark : u.dark,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: AnimatedBuilder(
        animation: appState,
        builder: (context, _) {
          final int currentIdx = allLessons.indexWhere((l) => !appState.isDone(l.id));
          final children = <Widget>[];
          for (int ui = 0; ui < curriculum.length; ui++) {
            final u = curriculum[ui];
            children.add(_unitHeader(u, ui + 1));
            for (int li = 0; li < u.lessons.length; li++) {
              final l = u.lessons[li];
              children.add(_node(context, u, l, allLessons.indexOf(l), currentIdx, li));
            }
          }
          children.add(const SizedBox(height: 16));
          return Column(
            children: [
              _topBar(),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                  children: children,
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
