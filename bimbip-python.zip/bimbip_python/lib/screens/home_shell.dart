import 'package:flutter/material.dart';
import '../theme.dart';
import 'learn_screen.dart';
import 'notebook_screen.dart';
import 'practice_screen.dart';
import 'profile_screen.dart';

class HomeShell extends StatefulWidget {
  HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int tab = 0;

  static const List<IconData> icons = [
    Icons.home_rounded,
    Icons.sports_esports_rounded,
    Icons.menu_book_rounded,
    Icons.person_rounded,
  ];
  static const List<String> labels = ['Học', 'Chơi', 'Sổ tay', 'Hồ sơ'];

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).padding.bottom;
    return Scaffold(
      backgroundColor: Colors.white,
      body: IndexedStack(
        index: tab,
        children: [LearnScreen(), PracticeScreen(), NotebookScreen(), ProfileScreen()],
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.fromLTRB(8, 8, 8, 8 + bottomInset),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border(top: BorderSide(color: AppColors.border, width: 2)),
        ),
        child: Row(
          children: [
            for (int i = 0; i < icons.length; i++)
              Expanded(
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => setState(() => tab = i),
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    decoration: BoxDecoration(
                      color: tab == i ? AppColors.honey : Colors.transparent,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: tab == i ? AppColors.honeyBorder : Colors.transparent, width: 2),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(icons[i], size: 28, color: tab == i ? AppColors.orange : AppColors.grayDark),
                        Text(labels[i], style: ts(11, c: tab == i ? AppColors.orangeDark : AppColors.grayDark)),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
