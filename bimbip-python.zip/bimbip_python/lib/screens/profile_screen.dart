import 'package:flutter/material.dart';
import '../data/curriculum.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../widgets/chunky_button.dart';
import '../widgets/mascot.dart';

class _Badge {
  final String emoji;
  final String title;
  final String desc;
  final bool unlocked;
  _Badge(this.emoji, this.title, this.desc, this.unlocked);
}

class ProfileScreen extends StatelessWidget {
  ProfileScreen({super.key});

  bool _unitDone(String id) {
    for (final u in curriculum) {
      if (u.id == id) return u.lessons.every((l) => appState.isDone(l.id));
    }
    return false;
  }

  String get _rank {
    final n = appState.lessonsDone;
    if (n >= allLessons.length) return 'Bìm bậc thầy 🎓';
    if (n >= 12) return 'Bìm lập trình viên 💻';
    if (n >= 6) return 'Bìm tập sự 🐣';
    if (n >= 1) return 'Chim non ham học 🥚';
    return 'Người mới chào sân 👋';
  }

  List<_Badge> _badges() {
    return [
      _Badge('🥚', 'Bước đầu tiên', 'Hoàn thành bài học đầu tiên', appState.lessonsDone >= 1),
      _Badge('🔥', 'Chuỗi 3 ngày', 'Học liên tục 3 ngày', appState.streakShown >= 3),
      _Badge('⭐', 'Hoàn hảo', 'Được 3 sao ở một bài', appState.perfectCount >= 1),
      _Badge('🐛', 'Thợ săn sâu', 'Thu thập 100 con sâu', appState.sau >= 100),
      _Badge('🎮', 'Học mà chơi', 'Chơi 3 lần ở Sân chơi', appState.practiceRuns >= 3),
      _Badge('📦', 'Chủ nhân của biến', 'Xong Chương 2', _unitDone('u2')),
      _Badge('🔀', 'Bậc thầy ngã rẽ', 'Xong Chương 4', _unitDone('u4')),
      _Badge('🔁', 'Vòng lặp bất tận', 'Xong Chương 5', _unitDone('u5')),
      _Badge('🎓', 'Tốt nghiệp nhập môn', 'Xong tất cả các chương', appState.lessonsDone >= allLessons.length),
    ];
  }

  Widget _stat(String emoji, String value, String label) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.border, width: 2),
        ),
        child: Column(
          children: [
            Text(emoji, style: const TextStyle(fontSize: 26)),
            const SizedBox(height: 4),
            Text(value, style: ts(20, w: FontWeight.w800)),
            Text(label, style: ts(12, w: FontWeight.w600, c: AppColors.subtext)),
          ],
        ),
      ),
    );
  }

  Widget _badgeTile(_Badge b) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: b.unlocked ? AppColors.honey : Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: b.unlocked ? AppColors.honeyBorder : AppColors.border, width: 2),
      ),
      child: Row(
        children: [
          Opacity(
            opacity: b.unlocked ? 1 : 0.35,
            child: Text(b.emoji, style: const TextStyle(fontSize: 32)),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(b.title, style: ts(16, w: FontWeight.w800, c: b.unlocked ? AppColors.text : AppColors.grayDark)),
                Text(b.desc, style: ts(13, w: FontWeight.w600, c: AppColors.subtext)),
              ],
            ),
          ),
          if (b.unlocked) Icon(Icons.check_circle_rounded, color: AppColors.green),
        ],
      ),
    );
  }

  Future<void> _confirmReset(BuildContext context) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Mascot(size: 100, mood: Mood.sad),
              const SizedBox(height: 8),
              Text('Xoá hết tiến độ?', style: ts(22, w: FontWeight.w800)),
              const SizedBox(height: 6),
              Text('Mọi bài học, sao và sâu sẽ bị xoá. Không thể hoàn tác.',
                  textAlign: TextAlign.center, style: ts(15, w: FontWeight.w600, c: AppColors.subtext)),
              const SizedBox(height: 16),
              ChunkyButton(onPressed: () => Navigator.of(ctx).pop(false), child: ChunkyButton.label('GIỮ LẠI')),
              const SizedBox(height: 8),
              ChunkyButton(
                color: Colors.white,
                shadow: AppColors.border,
                borderColor: AppColors.border,
                onPressed: () => Navigator.of(ctx).pop(true),
                child: ChunkyButton.label('XOÁ HẾT', color: AppColors.red),
              ),
            ],
          ),
        ),
      ),
    );
    if (yes == true) appState.reset();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: AnimatedBuilder(
        animation: appState,
        builder: (context, _) {
          final int pct = (appState.accuracy * 100).round();
          return ListView(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
            children: [
              Center(child: Mascot(size: 150, mood: Mood.happy)),
              Center(child: Text(_rank, style: ts(22, w: FontWeight.w800, c: AppColors.orange))),
              const SizedBox(height: 4),
              Center(
                child: Text('${appState.lessonsDone}/${allLessons.length} bài đã hoàn thành',
                    style: ts(14, w: FontWeight.w600, c: AppColors.subtext)),
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  _stat('🔥', '${appState.streakShown}', 'Chuỗi ngày'),
                  const SizedBox(width: 10),
                  _stat('🐛', '${appState.sau}', 'Sâu'),
                  const SizedBox(width: 10),
                  _stat('🎯', '$pct%', 'Chính xác'),
                ],
              ),
              const SizedBox(height: 24),
              Text('Huy hiệu', style: ts(20, w: FontWeight.w800)),
              const SizedBox(height: 10),
              for (final b in _badges()) _badgeTile(b),
              const SizedBox(height: 14),
              ChunkyButton(
                color: Colors.white,
                shadow: AppColors.border,
                borderColor: AppColors.border,
                height: 46,
                onPressed: () => _confirmReset(context),
                child: ChunkyButton.label('XOÁ TIẾN ĐỘ', color: AppColors.red, size: 14),
              ),
            ],
          );
        },
      ),
    );
  }
}
