import 'package:flutter/material.dart';
import '../data/curriculum.dart';
import '../models/exercise.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../widgets/code_view.dart';
import '../widgets/mascot.dart';

/// Sổ tay: tóm tắt các bài đã học để ôn nhanh.
class NotebookScreen extends StatelessWidget {
  NotebookScreen({super.key});

  Widget _entry(Unit u, Lesson l) {
    final bool done = appState.isDone(l.id);
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: done ? Colors.white : AppColors.gray.withAlpha(80),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: done ? AppColors.border : AppColors.gray, width: 2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(done ? l.icon : '🔒', style: const TextStyle(fontSize: 22)),
              const SizedBox(width: 10),
              Expanded(child: Text(l.title, style: ts(17, w: FontWeight.w800, c: done ? AppColors.text : AppColors.grayDark))),
            ],
          ),
          const SizedBox(height: 8),
          if (!done) Text('Học bài này để mở trang sổ tay.', style: ts(14, w: FontWeight.w600, c: AppColors.subtext)),
          if (done) Text.rich(TextSpan(children: richSpans(l.note, 15, AppColors.text))),
          if (done) const SizedBox(height: 10),
          if (done) CodeView(l.noteCode, fontSize: 14, showNumbers: false),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: AnimatedBuilder(
        animation: appState,
        builder: (context, _) {
          final children = <Widget>[
            Text('Sổ tay của Bìm', style: ts(26, w: FontWeight.w800, c: AppColors.orange)),
            const SizedBox(height: 12),
            BimSay('Quên gì thì lật sổ ra xem nhé! Mỗi bài học xong sẽ có một trang mới.', mood: Mood.happy, size: 84, fontSize: 15),
            const SizedBox(height: 18),
          ];
          for (int ui = 0; ui < curriculum.length; ui++) {
            final u = curriculum[ui];
            children.add(Padding(
              padding: const EdgeInsets.only(top: 6, bottom: 10),
              child: Text('${u.emoji}  Chương ${ui + 1}: ${u.title}', style: ts(18, w: FontWeight.w800, c: u.dark)),
            ));
            for (final l in u.lessons) {
              children.add(_entry(u, l));
            }
          }
          return ListView(padding: const EdgeInsets.fromLTRB(20, 16, 20, 24), children: children);
        },
      ),
    );
  }
}
