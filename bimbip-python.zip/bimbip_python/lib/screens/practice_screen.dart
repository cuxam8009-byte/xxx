import 'package:flutter/material.dart';
import '../data/curriculum.dart';
import '../exercises/exercise_view.dart';
import '../models/exercise.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../widgets/mascot.dart';
import 'lesson_runner.dart';

class _Mode {
  final String emoji;
  final String title;
  final String desc;
  final bool Function(Exercise) test;
  final int count;
  _Mode(this.emoji, this.title, this.desc, this.test, this.count);
}

/// "Sân chơi của Bìm": chọn trò chơi, Bìm lấy bài từ các bài bạn đã mở khoá.
class PracticeScreen extends StatelessWidget {
  PracticeScreen({super.key});

  final List<_Mode> modes = [
    _Mode('🐛', 'Bìm bắt sâu', 'Tìm dòng code bị lỗi', (e) => e is BugEx, 5),
    _Mode('👆', 'Đúng hay Sai?', 'Vuốt thẻ thật nhanh', (e) => e is SwipeEx, 2),
    _Mode('🗺️', 'Mê cung của Bìm', 'Lập trình cho Bìm đi ăn sâu', (e) => e is MazeEx, 2),
    _Mode('🧩', 'Ghép khối code', 'Xếp các khối thành lệnh', (e) => e is BlocksEx, 5),
    _Mode('↕️', 'Xếp dòng code', 'Kéo thả cho đúng thứ tự', (e) => e is OrderEx, 4),
    _Mode('🔮', 'Đoán kết quả', 'Bìm chạy code, màn hình hiện gì?', (e) => e is QuizEx && e.code != null, 5),
    _Mode('⌨️', 'Tự gõ code', 'Thử thách gõ bằng tay', (e) => e is TypeEx, 4),
    _Mode('🔗', 'Nối cặp & nhặt đồ', 'Ghép khái niệm với ý nghĩa', (e) => e is MatchEx || e is SortEx, 3),
    _Mode('🎲', 'Trộn tất cả', 'Mỗi thứ một chút, bất ngờ!', (e) => !isInfo(e), 8),
  ];

  List<Exercise> _pool(_Mode m) {
    final int cur = allLessons.indexWhere((l) => !appState.isDone(l.id));
    final int last = cur < 0 ? allLessons.length - 1 : cur;
    final out = <Exercise>[];
    for (int i = 0; i <= last; i++) {
      for (final e in allLessons[i].items) {
        if (m.test(e)) out.add(e);
      }
    }
    return out;
  }

  void _play(BuildContext context, _Mode m) {
    final pool = _pool(m);
    if (pool.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Chưa có bài dạng này. Học thêm vài bài nữa nhé!', style: ts(15, c: Colors.white))),
      );
      return;
    }
    pool.shuffle();
    final picked = pool.take(m.count).toList();
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => LessonRunner(title: m.title, items: picked)));
  }

  Widget _card(BuildContext context, _Mode m) {
    final int n = _pool(m).length;
    final bool open = n > 0;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => _play(context, m),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: open ? Colors.white : AppColors.gray.withAlpha(90),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: open ? AppColors.border : AppColors.gray, width: 2),
          boxShadow: [BoxShadow(color: open ? AppColors.border : AppColors.gray, offset: const Offset(0, 4), blurRadius: 0)],
        ),
        child: Row(
          children: [
            Container(
              width: 52,
              height: 52,
              alignment: Alignment.center,
              decoration: BoxDecoration(color: AppColors.honey, borderRadius: BorderRadius.circular(14)),
              child: Text(m.emoji, style: const TextStyle(fontSize: 28)),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(m.title, style: ts(17, w: FontWeight.w800, c: open ? AppColors.text : AppColors.grayDark)),
                  const SizedBox(height: 2),
                  Text(open ? m.desc : 'Học thêm để mở khoá', style: ts(13, w: FontWeight.w600, c: AppColors.subtext)),
                ],
              ),
            ),
            if (open) Icon(Icons.play_circle_fill_rounded, color: AppColors.orange, size: 34),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: AnimatedBuilder(
        animation: appState,
        builder: (context, _) {
          return ListView(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
            children: [
              Text('Sân chơi của Bìm', style: ts(26, w: FontWeight.w800, c: AppColors.orange)),
              const SizedBox(height: 12),
              BimSay('Học chán thì chơi! Chọn một trò, mình sẽ lấy câu hỏi từ những bài bạn đã học.', mood: Mood.cheer, size: 84, fontSize: 15),
              const SizedBox(height: 18),
              for (final m in modes) _card(context, m),
            ],
          );
        },
      ),
    );
  }
}
