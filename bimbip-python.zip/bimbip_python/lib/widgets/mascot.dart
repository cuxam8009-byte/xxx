import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../theme.dart';
import 'code_view.dart';

part 'mascot_art.dart';

/// Tâm trạng của Bìm.
enum Mood { happy, wink, cheer, think, sad }

// ---- Hàm vẽ phụ trợ cho mascot_art.dart (sinh tự động) ----
final Map<String, Path> _pathCache = {};

Path _parsePath(String d) {
  final cached = _pathCache[d];
  if (cached != null) return cached;
  final t = d.split(' ');
  final p = Path();
  int i = 0;
  while (i < t.length) {
    final k = t[i];
    if (k == 'M') {
      p.moveTo(double.parse(t[i + 1]), double.parse(t[i + 2]));
      i += 3;
    } else if (k == 'L') {
      p.lineTo(double.parse(t[i + 1]), double.parse(t[i + 2]));
      i += 3;
    } else if (k == 'C') {
      p.cubicTo(double.parse(t[i + 1]), double.parse(t[i + 2]), double.parse(t[i + 3]), double.parse(t[i + 4]),
          double.parse(t[i + 5]), double.parse(t[i + 6]));
      i += 7;
    } else if (k == 'Z') {
      p.close();
      i += 1;
    } else {
      i += 1;
    }
  }
  _pathCache[d] = p;
  return p;
}

void _fill(Canvas c, String d, int col) {
  final paint = Paint()
    ..color = Color(col)
    ..style = PaintingStyle.fill
    ..isAntiAlias = true;
  c.drawPath(_parsePath(d), paint);
}

void _line(Canvas c, String d, int col, double w) {
  final paint = Paint()
    ..color = Color(col)
    ..style = PaintingStyle.stroke
    ..strokeWidth = w
    ..strokeCap = StrokeCap.round
    ..strokeJoin = StrokeJoin.round
    ..isAntiAlias = true;
  c.drawPath(_parsePath(d), paint);
}

void _oval(Canvas c, double cx, double cy, double rx, double ry, int col) {
  final paint = Paint()
    ..color = Color(col)
    ..style = PaintingStyle.fill
    ..isAntiAlias = true;
  c.drawOval(Rect.fromCenter(center: Offset(cx, cy), width: rx * 2, height: ry * 2), paint);
}

void paintMascot(Canvas c, Mood mood, bool blink) {
  artTail(c);
  if (mood == Mood.cheer) artWingsUp(c);
  artBody(c);
  if (mood != Mood.cheer) artWingsDown(c);
  artHead(c);
  switch (mood) {
    case Mood.happy:
      if (blink) {
        artFace_happy_blink(c);
      } else {
        artFace_happy(c);
      }
      break;
    case Mood.wink:
      artFace_wink(c);
      break;
    case Mood.cheer:
      artFace_cheer(c);
      artSparkles(c);
      break;
    case Mood.think:
      if (blink) {
        artFace_think_blink(c);
      } else {
        artFace_think(c);
      }
      break;
    case Mood.sad:
      if (blink) {
        artFace_sad_blink(c);
      } else {
        artFace_sad(c);
      }
      break;
  }
}

class MascotPainter extends CustomPainter {
  final Mood mood;
  final bool blink;
  MascotPainter(this.mood, this.blink);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 200, size.height / 200);
    paintMascot(canvas, mood, blink);
    canvas.restore();
  }

  @override
  bool shouldRepaint(MascotPainter old) => old.mood != mood || old.blink != blink;
}

/// Linh vật Bìm Bịp (vẽ bằng code, không cần ảnh).
class Mascot extends StatefulWidget {
  final double size;
  final Mood mood;
  final bool animate;
  Mascot({super.key, this.size = 120, this.mood = Mood.happy, this.animate = true});

  @override
  State<Mascot> createState() => _MascotState();
}

class _MascotState extends State<Mascot> with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 3200));
    if (widget.animate) _c.repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (context, child) {
        final t = _c.value;
        final bob = widget.animate ? math.sin(t * 2 * math.pi) * widget.size * 0.025 : 0.0;
        final blink = widget.animate && t > 0.92 && t < 0.97;
        return Transform.translate(
          offset: Offset(0, bob),
          child: CustomPaint(
            size: Size(widget.size, widget.size),
            painter: MascotPainter(widget.mood, blink),
          ),
        );
      },
    );
  }
}

/// Hiệu ứng nhún lên xuống nhẹ cho bất kỳ widget nào.
class Bob extends StatefulWidget {
  final Widget child;
  final double amount;
  Bob({super.key, required this.child, this.amount = 6});

  @override
  State<Bob> createState() => _BobState();
}

class _BobState extends State<Bob> with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (context, child) => Transform.translate(offset: Offset(0, -widget.amount * _c.value), child: child),
      child: widget.child,
    );
  }
}

class _TailPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final path = Path()
      ..moveTo(size.width, 0)
      ..lineTo(0, size.height / 2)
      ..lineTo(size.width, size.height)
      ..close();
    canvas.drawPath(path, Paint()..color = Colors.white);
    final stroke = Paint()
      ..color = AppColors.border
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    final edge = Path()
      ..moveTo(size.width, 0)
      ..lineTo(0, size.height / 2)
      ..lineTo(size.width, size.height);
    canvas.drawPath(edge, stroke);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// Bóng thoại (có đuôi chỉ sang trái, về phía Bìm).
class SpeechBubble extends StatelessWidget {
  final String text;
  final double fontSize;
  SpeechBubble(this.text, {super.key, this.fontSize = 16});

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.border, width: 2),
          ),
          child: Text.rich(TextSpan(children: richSpans(text, fontSize, AppColors.text))),
        ),
        Positioned(
          left: -10,
          top: 20,
          child: CustomPaint(size: const Size(12, 18), painter: _TailPainter()),
        ),
      ],
    );
  }
}

/// Bìm + bóng thoại nói một câu.
class BimSay extends StatelessWidget {
  final String text;
  final Mood mood;
  final double size;
  final double fontSize;
  BimSay(this.text, {super.key, this.mood = Mood.happy, this.size = 92, this.fontSize = 16});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Mascot(size: size, mood: mood),
        const SizedBox(width: 10),
        Expanded(child: SpeechBubble(text, fontSize: fontSize)),
      ],
    );
  }
}
