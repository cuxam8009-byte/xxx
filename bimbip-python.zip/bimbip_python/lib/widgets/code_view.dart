import 'package:flutter/material.dart';
import '../theme.dart';

const String kMono = 'monospace';

final RegExp _tokRe = RegExp(
    r'''(#.*)|(f?"[^"]*"?|f?'[^']*'?)|(\b\d+(?:\.\d+)?\b)|([A-Za-z_][A-Za-z_0-9]*)''');
final RegExp _blankRe = RegExp(r'\{(\d+)\}');

const Set<String> _keywords = {
  'if', 'elif', 'else', 'for', 'while', 'in', 'def', 'return', 'True', 'False', 'None', 'and', 'or', 'not',
  'import', 'from', 'break', 'continue', 'pass',
};
const Set<String> _builtins = {'print', 'input', 'int', 'str', 'float', 'len', 'range', 'type', 'append'};

/// Tô màu cú pháp Python cho một dòng code.
List<TextSpan> codeSpans(String line, {Color base = AppColors.codeText}) {
  final spans = <TextSpan>[];
  int pos = 0;
  for (final m in _tokRe.allMatches(line)) {
    if (m.start > pos) spans.add(TextSpan(text: line.substring(pos, m.start), style: TextStyle(color: base)));
    final t = m.group(0)!;
    Color col = base;
    FontWeight? fw;
    if (m.group(1) != null) {
      col = AppColors.codeComment;
    } else if (m.group(2) != null) {
      col = AppColors.codeString;
    } else if (m.group(3) != null) {
      col = AppColors.codeNumber;
    } else if (m.group(4) != null) {
      if (_keywords.contains(t)) {
        col = AppColors.codeKeyword;
        fw = FontWeight.w700;
      } else if (_builtins.contains(t)) {
        col = AppColors.codeBuiltin;
      }
    }
    spans.add(TextSpan(text: t, style: TextStyle(color: col, fontWeight: fw)));
    pos = m.end;
  }
  if (pos < line.length) spans.add(TextSpan(text: line.substring(pos), style: TextStyle(color: base)));
  return spans;
}

/// Văn bản thường, nhưng đoạn trong `dấu huyền` được hiển thị như code.
List<InlineSpan> richSpans(String text, double size, Color color, {FontWeight weight = FontWeight.w600}) {
  final parts = text.split('`');
  final spans = <InlineSpan>[];
  for (int i = 0; i < parts.length; i++) {
    if (parts[i].isEmpty) continue;
    if (i % 2 == 1) {
      spans.add(TextSpan(
        text: parts[i],
        style: TextStyle(
          fontFamily: kMono,
          fontSize: size - 1,
          fontWeight: FontWeight.w700,
          color: AppColors.orangeDark,
          backgroundColor: AppColors.honey,
        ),
      ));
    } else {
      spans.add(TextSpan(text: parts[i], style: TextStyle(fontSize: size, fontWeight: weight, color: color, height: 1.4)));
    }
  }
  return spans;
}

/// Khung hiển thị code (nền tối, có số dòng, tô màu cú pháp).
class CodeView extends StatelessWidget {
  final String code;
  final double fontSize;
  final bool showNumbers;
  final int? arrowLine;
  final Map<int, Color>? lineBg;
  final Map<int, String>? lineBadge;
  final void Function(int)? onLineTap;
  final Widget Function(int)? blankBuilder;

  CodeView(
    this.code, {
    super.key,
    this.fontSize = 14,
    this.showNumbers = true,
    this.arrowLine,
    this.lineBg,
    this.lineBadge,
    this.onLineTap,
    this.blankBuilder,
  });

  List<InlineSpan> _spansFor(String line) {
    final builder = blankBuilder;
    if (builder == null) return codeSpans(line);
    final spans = <InlineSpan>[];
    int pos = 0;
    for (final m in _blankRe.allMatches(line)) {
      if (m.start > pos) spans.addAll(codeSpans(line.substring(pos, m.start)));
      spans.add(WidgetSpan(alignment: PlaceholderAlignment.middle, child: builder(int.parse(m.group(1)!))));
      pos = m.end;
    }
    if (pos < line.length) spans.addAll(codeSpans(line.substring(pos)));
    return spans;
  }

  Widget _row(int i, String line) {
    final bg = lineBg == null ? null : lineBg![i];
    final isArrow = arrowLine != null && arrowLine == i;
    final badge = lineBadge == null ? null : lineBadge![i];
    final numberText = isArrow ? '▶' : '${i + 1}';
    final content = Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(6)),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          if (showNumbers)
            SizedBox(
              width: 22,
              child: Text(
                numberText,
                style: TextStyle(
                  fontFamily: kMono,
                  fontSize: fontSize - 2,
                  color: isArrow ? AppColors.yellow : AppColors.codeLineNo,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          Expanded(
            child: Text.rich(
              TextSpan(
                style: TextStyle(fontFamily: kMono, fontSize: fontSize, height: 1.45, color: AppColors.codeText),
                children: _spansFor(line.isEmpty ? ' ' : line),
              ),
            ),
          ),
          if (badge != null) Text(badge, style: const TextStyle(fontSize: 16)),
        ],
      ),
    );
    if (onLineTap == null) return content;
    return GestureDetector(behavior: HitTestBehavior.opaque, onTap: () => onLineTap!(i), child: content);
  }

  @override
  Widget build(BuildContext context) {
    final lines = code.split('\n');
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
      decoration: BoxDecoration(color: AppColors.code, borderRadius: BorderRadius.circular(14)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [for (int i = 0; i < lines.length; i++) _row(i, lines[i])],
      ),
    );
  }
}

/// Một dòng code đơn (dùng cho đáp án, thẻ...).
class CodeText extends StatelessWidget {
  final String text;
  final double fontSize;
  final Color base;
  CodeText(this.text, {super.key, this.fontSize = 15, this.base = AppColors.text});

  @override
  Widget build(BuildContext context) {
    return Text.rich(
      TextSpan(
        style: TextStyle(fontFamily: kMono, fontSize: fontSize, fontWeight: FontWeight.w700, color: base),
        children: [TextSpan(text: text)],
      ),
    );
  }
}
