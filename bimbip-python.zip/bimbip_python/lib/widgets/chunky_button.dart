import 'package:flutter/material.dart';
import '../theme.dart';

/// Nút "nổi khối" kiểu Duolingo: có bóng dày phía dưới, nhấn thì lún xuống.
class ChunkyButton extends StatefulWidget {
  final Widget child;
  final VoidCallback? onPressed;
  final Color color;
  final Color shadow;
  final double height;
  final double radius;
  final double width;
  final Color? borderColor;

  ChunkyButton({
    super.key,
    required this.child,
    this.onPressed,
    this.color = AppColors.orange,
    this.shadow = AppColors.orangeDark,
    this.height = 52,
    this.radius = 16,
    this.width = double.infinity,
    this.borderColor,
  });

  /// Nút chữ trắng đậm tiêu chuẩn.
  static Widget label(String text, {Color color = Colors.white, double size = 16}) {
    return Text(text, style: TextStyle(color: color, fontSize: size, fontWeight: FontWeight.w800, letterSpacing: 0.8));
  }

  @override
  State<ChunkyButton> createState() => _ChunkyButtonState();
}

class _ChunkyButtonState extends State<ChunkyButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    final enabled = widget.onPressed != null;
    final color = enabled ? widget.color : AppColors.gray;
    final shadow = enabled ? widget.shadow : AppColors.border;
    const depth = 4.0;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: enabled ? (_) => setState(() => _down = true) : null,
      onTapCancel: enabled ? () => setState(() => _down = false) : null,
      onTapUp: enabled ? (_) => setState(() => _down = false) : null,
      onTap: widget.onPressed,
      child: SizedBox(
        width: widget.width,
        height: widget.height + depth,
        child: Stack(
          children: [
            Positioned(
              left: 0,
              right: 0,
              top: depth,
              height: widget.height,
              child: Container(
                decoration: BoxDecoration(color: shadow, borderRadius: BorderRadius.circular(widget.radius)),
              ),
            ),
            Positioned(
              left: 0,
              right: 0,
              top: _down ? depth : 0,
              height: widget.height,
              child: Container(
                alignment: Alignment.center,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(widget.radius),
                  border: widget.borderColor == null ? null : Border.all(color: widget.borderColor!, width: 2),
                ),
                child: widget.child,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
