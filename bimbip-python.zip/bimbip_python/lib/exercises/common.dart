import 'package:flutter/material.dart';
import '../theme.dart';
import '../widgets/code_view.dart';

/// Tiêu đề dạng bài + câu hỏi.
class ExHeader extends StatelessWidget {
  final String label;
  final String prompt;
  ExHeader(this.label, this.prompt, {super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
            decoration: BoxDecoration(color: AppColors.honey, borderRadius: BorderRadius.circular(20)),
            child: Text(label, style: ts(13, c: AppColors.orangeDark)),
          ),
          const SizedBox(height: 12),
          Text.rich(TextSpan(children: richSpans(prompt, 22, AppColors.text, weight: FontWeight.w800))),
        ],
      ),
    );
  }
}

/// Ô lựa chọn nổi khối. result: 0 = chưa chấm, 1 = đúng, 2 = sai.
class ChoiceTile extends StatelessWidget {
  final Widget child;
  final bool selected;
  final int result;
  final VoidCallback? onTap;
  final Alignment align;
  ChoiceTile({
    super.key,
    required this.child,
    this.selected = false,
    this.result = 0,
    this.onTap,
    this.align = Alignment.centerLeft,
  });

  @override
  Widget build(BuildContext context) {
    Color border = AppColors.border;
    Color bg = Colors.white;
    if (result == 1) {
      border = AppColors.green;
      bg = AppColors.greenBg;
    } else if (result == 2) {
      border = AppColors.red;
      bg = AppColors.redBg;
    } else if (selected) {
      border = AppColors.orange;
      bg = AppColors.honey;
    }
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        width: double.infinity,
        alignment: align,
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: border, width: 2),
          boxShadow: [BoxShadow(color: border, offset: const Offset(0, 3), blurRadius: 0)],
        ),
        child: child,
      ),
    );
  }
}

/// Khối chữ nhỏ (token) dùng trong ghép khối / điền chỗ trống.
class TokenChip extends StatelessWidget {
  final String text;
  final bool ghost;
  final int result;
  final VoidCallback? onTap;
  TokenChip(this.text, {super.key, this.ghost = false, this.result = 0, this.onTap});

  @override
  Widget build(BuildContext context) {
    Color border = AppColors.border;
    Color bg = Colors.white;
    Color fg = AppColors.text;
    if (ghost) {
      bg = AppColors.gray;
      fg = Colors.transparent;
      border = AppColors.gray;
    } else if (result == 1) {
      border = AppColors.green;
      bg = AppColors.greenBg;
    } else if (result == 2) {
      border = AppColors.red;
      bg = AppColors.redBg;
    }
    return GestureDetector(
      onTap: ghost ? null : onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: border, width: 2),
          boxShadow: ghost ? null : [BoxShadow(color: border, offset: const Offset(0, 3), blurRadius: 0)],
        ),
        child: Text(
          text,
          style: TextStyle(fontFamily: kMono, fontSize: 16, fontWeight: FontWeight.w700, color: fg),
        ),
      ),
    );
  }
}

bool sameList(List<String> a, List<String> b) {
  if (a.length != b.length) return false;
  for (int i = 0; i < a.length; i++) {
    if (a[i] != b[i]) return false;
  }
  return true;
}
