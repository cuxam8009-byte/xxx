import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../models/exercise.dart';
import '../theme.dart';
import '../widgets/chunky_button.dart';
import '../widgets/code_view.dart';
import '../widgets/mascot.dart';
import 'common.dart';

// ------------------------------------------------------------------
// Thẻ học
// ------------------------------------------------------------------
class TeachView extends StatelessWidget {
  final TeachCard ex;
  TeachView(this.ex, {super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(ex.title, style: ts(26, w: FontWeight.w800, h: 1.2)),
        const SizedBox(height: 16),
        BimSay(ex.body, mood: ex.mood, size: 96, fontSize: 17),
        if (ex.code != null) const SizedBox(height: 18),
        if (ex.code != null) CodeView(ex.code!, fontSize: 15),
      ],
    );
  }
}

// ------------------------------------------------------------------
// Xem Bìm chạy code từng dòng
// ------------------------------------------------------------------
class StepView extends StatefulWidget {
  final StepEx ex;
  StepView(this.ex, {super.key});

  @override
  State<StepView> createState() => _StepViewState();
}

class _StepViewState extends State<StepView> {
  int i = 0;

  Widget _varBox(String name, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.honey,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.honeyBorder, width: 2),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(name, style: TextStyle(fontFamily: kMono, fontSize: 12, fontWeight: FontWeight.w800, color: AppColors.orangeDark)),
          const SizedBox(height: 4),
          CodeText(value, fontSize: 18),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ex = widget.ex;
    final s = ex.steps[i];
    final last = i >= ex.steps.length - 1;
    final Map<int, Color> bg = {};
    if (s.line >= 0) bg[s.line] = alpha(AppColors.orange, 0.30);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
          decoration: BoxDecoration(color: AppColors.honey, borderRadius: BorderRadius.circular(20)),
          child: Text('🔍 Xem Bìm chạy code', style: ts(13, c: AppColors.orangeDark)),
        ),
        const SizedBox(height: 12),
        Text(ex.title, style: ts(22, w: FontWeight.w800)),
        const SizedBox(height: 14),
        CodeView(ex.code, fontSize: 15, arrowLine: s.line >= 0 ? s.line : null, lineBg: bg),
        const SizedBox(height: 14),
        Text('📦 Các hộp biến', style: ts(15, c: AppColors.subtext)),
        const SizedBox(height: 8),
        if (s.vars.isEmpty) Text('(chưa có hộp nào)', style: ts(15, w: FontWeight.w600, c: AppColors.grayDark)),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [for (final e in s.vars.entries) _varBox(e.key, e.value)],
        ),
        const SizedBox(height: 14),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: AppColors.code, borderRadius: BorderRadius.circular(14)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('🖥️ Màn hình', style: ts(13, c: AppColors.codeComment)),
              const SizedBox(height: 6),
              if (s.out.isEmpty) Text('(chưa có gì)', style: ts(14, w: FontWeight.w600, c: AppColors.codeLineNo)),
              for (final line in s.out)
                Text(line, style: TextStyle(fontFamily: kMono, fontSize: 15, color: AppColors.codeText, height: 1.4)),
            ],
          ),
        ),
        const SizedBox(height: 14),
        BimSay(s.note, mood: last ? Mood.cheer : Mood.think, size: 72, fontSize: 15),
        const SizedBox(height: 16),
        ChunkyButton(
          color: AppColors.yellow,
          shadow: AppColors.yellowDark,
          height: 48,
          onPressed: () => setState(() => i = last ? 0 : i + 1),
          child: ChunkyButton.label(last ? '↺  XEM LẠI TỪ ĐẦU' : '▶  CHẠY DÒNG NÀY', color: AppColors.text, size: 15),
        ),
      ],
    );
  }
}

// ------------------------------------------------------------------
// Trắc nghiệm / đoán kết quả
// ------------------------------------------------------------------
class QuizView extends StatefulWidget {
  final QuizEx ex;
  final ExController ctrl;
  QuizView(this.ex, this.ctrl, {super.key});

  @override
  State<QuizView> createState() => _QuizViewState();
}

class _QuizViewState extends State<QuizView> {
  late List<int> order;
  int? sel;

  @override
  void initState() {
    super.initState();
    order = List<int>.generate(widget.ex.options.length, (i) => i)..shuffle(math.Random());
    widget.ctrl.checker = _check;
  }

  bool _check() {
    widget.ctrl.correctText = widget.ex.options[widget.ex.answer];
    return sel == widget.ex.answer;
  }

  int _result(int i) {
    if (!widget.ctrl.checked) return 0;
    if (i == widget.ex.answer) return 1;
    if (i == sel) return 2;
    return 0;
  }

  @override
  Widget build(BuildContext context) {
    final ex = widget.ex;
    final ctrl = widget.ctrl;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ExHeader(ex.code != null ? '🔮 Đoán kết quả' : '🎯 Chọn đáp án', ex.prompt),
        if (ex.code != null) CodeView(ex.code!, fontSize: 15),
        if (ex.code != null) const SizedBox(height: 18),
        for (final i in order)
          ChoiceTile(
            selected: sel == i,
            result: _result(i),
            onTap: ctrl.checked
                ? null
                : () {
                    setState(() => sel = i);
                    ctrl.setReady(true);
                  },
            child: ex.mono
                ? CodeText(ex.options[i], fontSize: 16)
                : Text(ex.options[i], style: ts(17, w: FontWeight.w700)),
          ),
      ],
    );
  }
}

// ------------------------------------------------------------------
// Tự gõ code
// ------------------------------------------------------------------
String normCode(String s) {
  var t = s.replaceAll("'", '"');
  t = t.split('\n').map((l) => l.trim()).where((l) => l.isNotEmpty).join('\n');
  t = t.replaceAll(RegExp(r'[ \t]+'), ' ');
  t = t.replaceAllMapped(RegExp(r' ?([()\[\]{}=,+\-*/%<>:!]) ?'), (m) => m.group(1)!);
  return t;
}

class TypeView extends StatefulWidget {
  final TypeEx ex;
  final ExController ctrl;
  TypeView(this.ex, this.ctrl, {super.key});

  @override
  State<TypeView> createState() => _TypeViewState();
}

class _TypeViewState extends State<TypeView> {
  final TextEditingController tc = TextEditingController();
  final FocusNode focus = FocusNode();
  bool showHint = false;

  // [nhãn, chuỗi chèn, số ký tự lùi con trỏ]
  final List<List<Object>> keys = [
    ['""', '""', 1],
    ['()', '()', 1],
    [':', ':', 0],
    ['=', ' = ', 0],
    ['+', ' + ', 0],
    ['#', '#', 0],
    ['{}', '{}', 1],
    ['[]', '[]', 1],
  ];

  @override
  void initState() {
    super.initState();
    widget.ctrl.checker = _check;
    tc.addListener(() {
      widget.ctrl.setReady(tc.text.trim().isNotEmpty);
    });
  }

  @override
  void dispose() {
    tc.dispose();
    focus.dispose();
    super.dispose();
  }

  bool _check() {
    final got = normCode(tc.text);
    widget.ctrl.correctText = widget.ex.answers.first;
    for (final a in widget.ex.answers) {
      if (normCode(a) == got) return true;
    }
    return false;
  }

  void _insert(String s, int back) {
    if (widget.ctrl.checked) return;
    final t = tc.text;
    final sel = tc.selection;
    final start = sel.start < 0 ? t.length : sel.start;
    final end = sel.end < 0 ? t.length : sel.end;
    final nt = t.replaceRange(start, end, s);
    tc.value = TextEditingValue(
      text: nt,
      selection: TextSelection.collapsed(offset: start + s.length - back),
    );
    focus.requestFocus();
  }

  @override
  Widget build(BuildContext context) {
    final ex = widget.ex;
    final ctrl = widget.ctrl;
    Color border = AppColors.border;
    if (ctrl.checked) border = ctrl.correct ? AppColors.green : AppColors.red;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ExHeader('⌨️ Tự gõ code', ex.prompt),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
          decoration: BoxDecoration(
            color: AppColors.code,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: border, width: 2),
          ),
          child: TextField(
            controller: tc,
            focusNode: focus,
            enabled: !ctrl.checked,
            autocorrect: false,
            enableSuggestions: false,
            textCapitalization: TextCapitalization.none,
            keyboardType: ex.multiline ? TextInputType.multiline : TextInputType.text,
            minLines: ex.multiline ? 3 : 1,
            maxLines: ex.multiline ? 6 : 1,
            cursorColor: AppColors.yellow,
            style: TextStyle(fontFamily: kMono, fontSize: 16, color: AppColors.codeText, height: 1.5),
            decoration: InputDecoration(
              border: InputBorder.none,
              hintText: 'Gõ code của bạn ở đây...',
              hintStyle: TextStyle(fontFamily: kMono, fontSize: 15, color: AppColors.codeLineNo),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final k in keys)
              GestureDetector(
                onTap: () => _insert(k[1] as String, k[2] as int),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: AppColors.honey,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppColors.honeyBorder, width: 2),
                  ),
                  child: Text(k[0] as String, style: TextStyle(fontFamily: kMono, fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.orangeDark)),
                ),
              ),
          ],
        ),
        const SizedBox(height: 16),
        if (ex.hint.isNotEmpty)
          GestureDetector(
            onTap: () => setState(() => showHint = true),
            child: showHint
                ? BimSay(ex.hint, mood: Mood.wink, size: 64, fontSize: 15)
                : Text('💡 Cần gợi ý? Chạm vào đây', style: ts(15, c: AppColors.orange)),
          ),
      ],
    );
  }
}
