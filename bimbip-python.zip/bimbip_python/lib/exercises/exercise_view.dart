import 'package:flutter/material.dart';
import '../models/exercise.dart';
import 'basic_views.dart';
import 'code_views.dart';
import 'game_views.dart';

/// Thẻ học / xem chạy code: chỉ cần bấm "Tiếp tục".
bool isInfo(Exercise e) => e is TeachCard || e is StepEx;

/// Dạng bài tự báo kết quả khi hoàn thành (không có nút KIỂM TRA).
bool isSelfChecking(Exercise e) => e is MatchEx || e is SwipeEx || e is SortEx || e is MazeEx;

Widget buildExercise(Exercise e, ExController c) {
  if (e is TeachCard) return TeachView(e);
  if (e is StepEx) return StepView(e);
  if (e is QuizEx) return QuizView(e, c);
  if (e is BlocksEx) return BlocksView(e, c);
  if (e is FillEx) return FillView(e, c);
  if (e is BugEx) return BugView(e, c);
  if (e is OrderEx) return OrderView(e, c);
  if (e is MatchEx) return MatchView(e, c);
  if (e is SwipeEx) return SwipeView(e, c);
  if (e is SortEx) return SortView(e, c);
  if (e is MazeEx) return MazeView(e, c);
  if (e is TypeEx) return TypeView(e, c);
  return const SizedBox.shrink();
}
