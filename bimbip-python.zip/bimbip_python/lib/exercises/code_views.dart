import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../models/exercise.dart';
import '../theme.dart';
import '../widgets/code_view.dart';
import 'common.dart';

// ------------------------------------------------------------------
// Ghép khối code
// ------------------------------------------------------------------
class BlocksView extends StatefulWidget {
  final BlocksEx ex;
  final ExController ctrl;
  BlocksView(this.ex, this.ctrl, {super.key});

  @override
  State<BlocksView> createState() => _BlocksViewState();
}

class _BlocksViewState extends State<BlocksView> {
  late List<String> pool;
  final List<int> chosen = [];

  @override
  void initState() {
    super.initState();
    pool = [...widget.ex.answer, ...widget.ex.extras]..shuffle(math.Random());
    widget.ctrl.checker = _check;
  }

  bool _check() {
    final got = chosen.map((i) => pool[i]).toList();
    widget.ctrl.correctText = widget.ex.show ?? widget.ex.answer.join(' ');
    return sameList(got, widget.ex.answer);
  }

  void _pick(int i) {
    if (widget.ctrl.checked || chosen.contains(i)) return;
    setState(() => chosen.add(i));
    widget.ctrl.setReady(true);
  }

  void _unpick(int pos) {
    if (widget.ctrl.checked) return;
    setState(() => chosen.removeAt(pos));
    widget.ctrl.setReady(chosen.isNotEmpty);
  }

  @override
  Widget build(BuildContext context) {
    final ctrl = widget.ctrl;
    final int res = ctrl.checked ? (ctrl.correct ? 1 : 2) : 0;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ExHeader('🧩 Ghép khối code', widget.ex.prompt),
        Container(
          width: double.infinity,
          constraints: const BoxConstraints(minHeight: 84),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppColors.honey,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.honeyBorder, width: 2),
          ),
          child: chosen.isEmpty
              ? Text('Chạm vào các khối bên dưới để ghép lệnh', style: ts(15, w: FontWeight.w600, c: AppColors.subtext))
              : Wrap(
                  spacing: 8,
                  runSpacing: 10,
                  children: [
                    for (int p = 0; p < chosen.length; p++)
                      TokenChip(pool[chosen[p]], result: res, onTap: () => _unpick(p)),
                  ],
                ),
        ),
        const SizedBox(height: 24),
        Wrap(
          spacing: 8,
          runSpacing: 12,
          children: [
            for (int i = 0; i < pool.length; i++)
              TokenChip(pool[i], ghost: chosen.contains(i), onTap: () => _pick(i)),
          ],
        ),
      ],
    );
  }
}

// ------------------------------------------------------------------
// Điền chỗ trống
// ------------------------------------------------------------------
class FillView extends StatefulWidget {
  final FillEx ex;
  final ExController ctrl;
  FillView(this.ex, this.ctrl, {super.key});

  @override
  State<FillView> createState() => _FillViewState();
}

class _FillViewState extends State<FillView> {
  late List<int> bankOrder;
  late List<int?> filled;

  @override
  void initState() {
    super.initState();
    bankOrder = List<int>.generate(widget.ex.options.length, (i) => i)..shuffle(math.Random());
    filled = List<int?>.filled(widget.ex.answers.length, null);
    widget.ctrl.checker = _check;
  }

  bool _slotOk(int slot) {
    final idx = filled[slot];
    if (idx == null) return false;
    return widget.ex.options[idx] == widget.ex.answers[slot];
  }

  bool _check() {
    widget.ctrl.correctText = widget.ex.answers.join('   ');
    for (int s = 0; s < filled.length; s++) {
      if (!_slotOk(s)) return false;
    }
    return true;
  }

  void _pick(int optIndex) {
    if (widget.ctrl.checked || filled.contains(optIndex)) return;
    final slot = filled.indexOf(null);
    if (slot < 0) return;
    setState(() => filled[slot] = optIndex);
    widget.ctrl.setReady(!filled.contains(null));
  }

  void _clear(int slot) {
    if (widget.ctrl.checked || filled[slot] == null) return;
    setState(() => filled[slot] = null);
    widget.ctrl.setReady(false);
  }

  Widget _blank(int slot) {
    final ctrl = widget.ctrl;
    final idx = slot < filled.length ? filled[slot] : null;
    Color bg = alpha(Colors.white, 0.10);
    Color border = AppColors.codeLineNo;
    Color fg = Colors.white;
    if (idx != null) {
      bg = AppColors.orange;
      border = AppColors.orangeDark;
    }
    if (ctrl.checked && idx != null) {
      final ok = _slotOk(slot);
      bg = ok ? AppColors.green : AppColors.red;
      border = ok ? AppColors.greenDark : AppColors.redDark;
    }
    return GestureDetector(
      onTap: () => _clear(slot),
      child: Container(
        constraints: const BoxConstraints(minWidth: 46),
        margin: const EdgeInsets.symmetric(horizontal: 2),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 1),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(8), border: Border.all(color: border, width: 2)),
        child: Text(
          idx == null ? ' ' : widget.ex.options[idx],
          textAlign: TextAlign.center,
          style: TextStyle(fontFamily: kMono, fontSize: 15, fontWeight: FontWeight.w800, color: fg),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ExHeader('✏️ Điền chỗ trống', widget.ex.prompt),
        CodeView(widget.ex.code, fontSize: 15, blankBuilder: _blank),
        const SizedBox(height: 24),
        Wrap(
          spacing: 8,
          runSpacing: 12,
          children: [
            for (final i in bankOrder)
              TokenChip(widget.ex.options[i], ghost: filled.contains(i), onTap: () => _pick(i)),
          ],
        ),
      ],
    );
  }
}

// ------------------------------------------------------------------
// Bìm bắt sâu: chạm vào dòng lỗi
// ------------------------------------------------------------------
class BugView extends StatefulWidget {
  final BugEx ex;
  final ExController ctrl;
  BugView(this.ex, this.ctrl, {super.key});

  @override
  State<BugView> createState() => _BugViewState();
}

class _BugViewState extends State<BugView> {
  int? sel;

  @override
  void initState() {
    super.initState();
    widget.ctrl.checker = _check;
  }

  bool _check() {
    final b = widget.ex.bugLine;
    widget.ctrl.correctText = 'Dòng ${b + 1}:  ${widget.ex.lines[b].trim()}';
    return sel == b;
  }

  @override
  Widget build(BuildContext context) {
    final ex = widget.ex;
    final ctrl = widget.ctrl;
    final Map<int, Color> bg = {};
    final Map<int, String> badge = {};
    if (ctrl.checked) {
      bg[ex.bugLine] = alpha(AppColors.green, 0.35);
      badge[ex.bugLine] = '🐛';
      if (sel != null && sel != ex.bugLine) bg[sel!] = alpha(AppColors.red, 0.35);
    } else if (sel != null) {
      bg[sel!] = alpha(AppColors.orange, 0.30);
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ExHeader('🐛 Bìm bắt sâu', ex.prompt),
        CodeView(
          ex.lines.join('\n'),
          fontSize: 15,
          lineBg: bg,
          lineBadge: badge,
          onLineTap: ctrl.checked
              ? null
              : (i) {
                  setState(() => sel = i);
                  ctrl.setReady(true);
                },
        ),
        const SizedBox(height: 12),
        Text('Chạm vào dòng code bị lỗi, rồi bấm KIỂM TRA.', style: ts(14, w: FontWeight.w600, c: AppColors.subtext)),
      ],
    );
  }
}

// ------------------------------------------------------------------
// Kéo thả sắp xếp dòng code
// ------------------------------------------------------------------
class OrderView extends StatefulWidget {
  final OrderEx ex;
  final ExController ctrl;
  OrderView(this.ex, this.ctrl, {super.key});

  @override
  State<OrderView> createState() => _OrderViewState();
}

class _OrderViewState extends State<OrderView> {
  late List<int> order; // chỉ số các dòng, đang ở thứ tự người dùng xếp

  @override
  void initState() {
    super.initState();
    final rnd = math.Random();
    order = List<int>.generate(widget.ex.lines.length, (i) => i);
    for (int tries = 0; tries < 20; tries++) {
      order.shuffle(rnd);
      if (!_isSolved()) break;
    }
    widget.ctrl.checker = _check;
    widget.ctrl.setReadyLater(true);
  }

  String _text(int p) => widget.ex.lines[order[p]];

  bool _isSolved() {
    for (int p = 0; p < order.length; p++) {
      if (_text(p) != widget.ex.lines[p]) return false;
    }
    return true;
  }

  bool _check() {
    widget.ctrl.correctText = widget.ex.lines.join('\n');
    return _isSolved();
  }

  @override
  Widget build(BuildContext context) {
    final ctrl = widget.ctrl;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ExHeader('↕️ Xếp thứ tự các dòng code', widget.ex.prompt),
        ReorderableListView(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          buildDefaultDragHandles: false,
          onReorder: (int oldIndex, int newIndex) {
            if (ctrl.checked) return;
            setState(() {
              if (newIndex > oldIndex) newIndex -= 1;
              final item = order.removeAt(oldIndex);
              order.insert(newIndex, item);
            });
          },
          children: [
            for (int p = 0; p < order.length; p++)
              Container(
                key: ValueKey('ord_${order[p]}'),
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.fromLTRB(14, 6, 6, 6),
                decoration: BoxDecoration(
                  color: AppColors.code,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: !ctrl.checked
                        ? AppColors.code
                        : (_text(p) == widget.ex.lines[p] ? AppColors.green : AppColors.red),
                    width: 2,
                  ),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Text.rich(
                        TextSpan(
                          style: TextStyle(fontFamily: kMono, fontSize: 15, height: 1.4, color: AppColors.codeText),
                          children: codeSpans(_text(p)),
                        ),
                      ),
                    ),
                    ReorderableDragStartListener(
                      index: p,
                      child: Padding(
                        padding: const EdgeInsets.all(8),
                        child: Icon(Icons.drag_indicator_rounded, color: AppColors.codeComment),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
        const SizedBox(height: 4),
        Text('Giữ biểu tượng ⋮⋮ rồi kéo để đổi chỗ.', style: ts(14, w: FontWeight.w600, c: AppColors.subtext)),
      ],
    );
  }
}
