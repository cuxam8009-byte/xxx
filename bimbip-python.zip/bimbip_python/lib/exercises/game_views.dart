import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../models/exercise.dart';
import '../theme.dart';
import '../widgets/chunky_button.dart';
import '../widgets/code_view.dart';
import '../widgets/mascot.dart';
import 'common.dart';

// ------------------------------------------------------------------
// Nối cặp
// ------------------------------------------------------------------
class MatchView extends StatefulWidget {
  final MatchEx ex;
  final ExController ctrl;
  MatchView(this.ex, this.ctrl, {super.key});

  @override
  State<MatchView> createState() => _MatchViewState();
}

class _MatchViewState extends State<MatchView> {
  late List<int> rOrder;
  int? selL;
  int? selR;
  int? badL;
  int? badR;
  bool busy = false;
  final Set<int> done = {};

  @override
  void initState() {
    super.initState();
    rOrder = List<int>.generate(widget.ex.pairs.length, (i) => i)..shuffle(math.Random());
  }

  void _tapL(int i) {
    if (busy || widget.ctrl.checked || done.contains(i)) return;
    setState(() => selL = i);
    _resolve();
  }

  void _tapR(int j) {
    if (busy || widget.ctrl.checked || done.contains(j)) return;
    setState(() => selR = j);
    _resolve();
  }

  void _resolve() {
    final l = selL;
    final r = selR;
    if (l == null || r == null) return;
    if (l == r) {
      setState(() {
        done.add(l);
        selL = null;
        selR = null;
      });
      if (done.length == widget.ex.pairs.length) widget.ctrl.finish(!widget.ctrl.penalized);
    } else {
      widget.ctrl.mistake();
      setState(() {
        busy = true;
        badL = l;
        badR = r;
      });
      Future.delayed(const Duration(milliseconds: 550), () {
        if (!mounted) return;
        setState(() {
          badL = null;
          badR = null;
          selL = null;
          selR = null;
          busy = false;
        });
      });
    }
  }

  Widget _label(String text, bool mono) {
    if (mono) return Center(child: CodeText(text, fontSize: 15));
    return Center(child: Text(text, textAlign: TextAlign.center, style: ts(15, w: FontWeight.w700)));
  }

  @override
  Widget build(BuildContext context) {
    final ex = widget.ex;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ExHeader('🔗 Nối cặp', ex.prompt),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Column(
                children: [
                  for (int i = 0; i < ex.pairs.length; i++)
                    ChoiceTile(
                      selected: selL == i,
                      result: done.contains(i) ? 1 : (badL == i ? 2 : 0),
                      align: Alignment.center,
                      onTap: () => _tapL(i),
                      child: _label(ex.pairs[i][0], ex.monoLeft),
                    ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                children: [
                  for (final j in rOrder)
                    ChoiceTile(
                      selected: selR == j,
                      result: done.contains(j) ? 1 : (badR == j ? 2 : 0),
                      align: Alignment.center,
                      onTap: () => _tapR(j),
                      child: _label(ex.pairs[j][1], ex.monoRight),
                    ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }
}

// ------------------------------------------------------------------
// Vuốt thẻ đúng / sai
// ------------------------------------------------------------------
class SwipeView extends StatefulWidget {
  final SwipeEx ex;
  final ExController ctrl;
  SwipeView(this.ex, this.ctrl, {super.key});

  @override
  State<SwipeView> createState() => _SwipeViewState();
}

class _SwipeViewState extends State<SwipeView> {
  int idx = 0;
  double dx = 0;
  bool answered = false;
  bool lastOk = false;

  void _answer(bool right) {
    if (answered || widget.ctrl.checked) return;
    final card = widget.ex.cards[idx];
    final ok = (right == card.truth);
    if (!ok) widget.ctrl.mistake();
    setState(() {
      answered = true;
      lastOk = ok;
      dx = 0;
    });
    if (idx == widget.ex.cards.length - 1) widget.ctrl.finish(!widget.ctrl.penalized);
  }

  void _next() {
    setState(() {
      idx += 1;
      answered = false;
      dx = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    final ex = widget.ex;
    final card = ex.cards[idx];
    final isLast = idx == ex.cards.length - 1;

    Color border = AppColors.border;
    if (answered) {
      border = lastOk ? AppColors.green : AppColors.red;
    } else if (dx > 25) {
      border = AppColors.green;
    } else if (dx < -25) {
      border = AppColors.red;
    }

    final Widget face = card.isCode
        ? CodeView(card.text, fontSize: 17, showNumbers: false)
        : Text(card.text, textAlign: TextAlign.center, style: ts(21, w: FontWeight.w800, h: 1.3));

    final cardWidget = Container(
      width: double.infinity,
      constraints: const BoxConstraints(minHeight: 150),
      alignment: Alignment.center,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: answered ? (lastOk ? AppColors.greenBg : AppColors.redBg) : Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: border, width: 3),
        boxShadow: [BoxShadow(color: border, offset: const Offset(0, 5), blurRadius: 0)],
      ),
      child: face,
    );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ExHeader('👆 Vuốt thẻ', ex.prompt),
        Text('Thẻ ${idx + 1}/${ex.cards.length}', style: ts(14, c: AppColors.subtext)),
        const SizedBox(height: 10),
        GestureDetector(
          onHorizontalDragUpdate: answered ? null : (d) => setState(() => dx += d.delta.dx),
          onHorizontalDragEnd: answered
              ? null
              : (d) {
                  if (dx > 80) {
                    _answer(true);
                  } else if (dx < -80) {
                    _answer(false);
                  } else {
                    setState(() => dx = 0);
                  }
                },
          child: Transform.translate(
            offset: Offset(dx, 0),
            child: Transform.rotate(angle: dx / 1000, child: cardWidget),
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('← ${ex.leftLabel}', style: ts(14, c: AppColors.red)),
            Text('${ex.rightLabel} →', style: ts(14, c: AppColors.greenDark)),
          ],
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
              child: ChunkyButton(
                height: 50,
                color: AppColors.red,
                shadow: AppColors.redDark,
                onPressed: answered ? null : () => _answer(false),
                child: ChunkyButton.label('✗  ${ex.leftLabel.toUpperCase()}', size: 15),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: ChunkyButton(
                height: 50,
                color: AppColors.green,
                shadow: AppColors.greenDark,
                onPressed: answered ? null : () => _answer(true),
                child: ChunkyButton.label('✓  ${ex.rightLabel.toUpperCase()}', size: 15),
              ),
            ),
          ],
        ),
        if (answered) const SizedBox(height: 18),
        if (answered)
          BimSay(
            (lastOk ? 'Chuẩn! ' : 'Chưa đúng. ') + card.why,
            mood: lastOk ? Mood.cheer : Mood.sad,
            size: 64,
            fontSize: 15,
          ),
        if (answered && !isLast) const SizedBox(height: 14),
        if (answered && !isLast)
          ChunkyButton(
            height: 46,
            color: AppColors.yellow,
            shadow: AppColors.yellowDark,
            onPressed: _next,
            child: ChunkyButton.label('THẺ TIẾP THEO', color: AppColors.text, size: 14),
          ),
      ],
    );
  }
}

// ------------------------------------------------------------------
// Nhặt đồ bỏ vào giỏ
// ------------------------------------------------------------------
class SortView extends StatefulWidget {
  final SortEx ex;
  final ExController ctrl;
  SortView(this.ex, this.ctrl, {super.key});

  @override
  State<SortView> createState() => _SortViewState();
}

class _SortViewState extends State<SortView> {
  int idx = 0;
  int? bad;
  bool busy = false;
  late List<List<String>> collected;

  @override
  void initState() {
    super.initState();
    collected = List<List<String>>.generate(widget.ex.buckets.length, (_) => <String>[]);
  }

  void _tap(int b) {
    if (busy || widget.ctrl.checked || idx >= widget.ex.items.length) return;
    final item = widget.ex.items[idx];
    if (item.bucket == b) {
      setState(() {
        collected[b].add(item.text);
        idx += 1;
      });
      if (idx >= widget.ex.items.length) widget.ctrl.finish(!widget.ctrl.penalized);
    } else {
      widget.ctrl.mistake();
      setState(() {
        bad = b;
        busy = true;
      });
      Future.delayed(const Duration(milliseconds: 500), () {
        if (!mounted) return;
        setState(() {
          bad = null;
          busy = false;
        });
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final ex = widget.ex;
    final finished = idx >= ex.items.length;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ExHeader('🧺 Nhặt đồ vào giỏ', ex.prompt),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 16),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: AppColors.honey,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: AppColors.honeyBorder, width: 2),
          ),
          child: finished
              ? Text('🎉 Đã nhặt xong!', style: ts(22, w: FontWeight.w800))
              : Column(
                  children: [
                    Text('Món này bỏ vào giỏ nào?  (${idx + 1}/${ex.items.length})', style: ts(14, c: AppColors.subtext)),
                    const SizedBox(height: 8),
                    CodeText(ex.items[idx].text, fontSize: 30, base: AppColors.orangeDark),
                  ],
                ),
        ),
        const SizedBox(height: 18),
        for (int b = 0; b < ex.buckets.length; b++)
          ChoiceTile(
            result: bad == b ? 2 : 0,
            onTap: () => _tap(b),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Text('🧺 ', style: TextStyle(fontSize: 20)),
                    CodeText(ex.buckets[b], fontSize: 18),
                    const Spacer(),
                    Text('${collected[b].length}', style: ts(16, c: AppColors.subtext)),
                  ],
                ),
                if (collected[b].isNotEmpty) const SizedBox(height: 8),
                if (collected[b].isNotEmpty)
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      for (final t in collected[b])
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(color: AppColors.greenBg, borderRadius: BorderRadius.circular(8)),
                          child: CodeText(t, fontSize: 13, base: AppColors.greenDark),
                        ),
                    ],
                  ),
              ],
            ),
          ),
      ],
    );
  }
}

// ------------------------------------------------------------------
// Mê cung của Bìm: lập trình cho Bìm đi ăn sâu
// ------------------------------------------------------------------
class _Cmd {
  final int dir;
  final int n;
  _Cmd(this.dir, this.n);
}

class MazeView extends StatefulWidget {
  final MazeEx ex;
  final ExController ctrl;
  MazeView(this.ex, this.ctrl, {super.key});

  @override
  State<MazeView> createState() => _MazeViewState();
}

class _MazeViewState extends State<MazeView> {
  static const List<int> dr = [-1, 1, 0, 0];
  static const List<int> dc = [0, 0, -1, 1];
  static const List<String> names = ['di_len', 'di_xuong', 'di_trai', 'di_phai'];
  static const List<IconData> arrows = [
    Icons.arrow_upward_rounded,
    Icons.arrow_downward_rounded,
    Icons.arrow_back_rounded,
    Icons.arrow_forward_rounded,
  ];

  late int rows;
  late int cols;
  int startR = 0;
  int startC = 0;
  int birdR = 0;
  int birdC = 0;
  final Set<int> rocks = {};
  final Set<int> wormsInit = {};
  final Set<int> worms = {};
  final List<_Cmd> prog = [];
  int dir = 3;
  int count = 1;
  bool running = false;
  int fails = 0;
  String msg = '';

  @override
  void initState() {
    super.initState();
    final g = widget.ex.grid;
    rows = g.length;
    cols = g[0].length;
    for (int r = 0; r < rows; r++) {
      for (int c = 0; c < cols; c++) {
        final ch = g[r][c];
        if (ch == 'B') {
          startR = r;
          startC = c;
        } else if (ch == 'W') {
          wormsInit.add(r * cols + c);
        } else if (ch == '#') {
          rocks.add(r * cols + c);
        }
      }
    }
    worms.addAll(wormsInit);
    birdR = startR;
    birdC = startC;
  }

  String _code() {
    if (prog.isEmpty) return '# Bấm "THÊM LỆNH" để viết code cho Bìm';
    final b = StringBuffer();
    for (final s in prog) {
      if (s.n == 1) {
        b.writeln('${names[s.dir]}()');
      } else {
        b.writeln('for i in range(${s.n}):');
        b.writeln('    ${names[s.dir]}()');
      }
    }
    return b.toString().trimRight();
  }

  void _add() {
    if (running) return;
    if (prog.length >= widget.ex.maxBlocks) {
      setState(() => msg = 'Hết khối rồi! Hãy tăng "số lần" để lặp thay vì thêm khối.');
      return;
    }
    setState(() {
      prog.add(_Cmd(dir, count));
      msg = '';
    });
  }

  void _removeLast() {
    if (running || prog.isEmpty) return;
    setState(() {
      prog.removeLast();
      msg = '';
    });
  }

  void _showSolution() {
    if (running) return;
    widget.ctrl.mistake();
    setState(() {
      prog.clear();
      for (final s in widget.ex.solution) {
        prog.add(_Cmd(s[0], s[1]));
      }
      msg = 'Đây là lời giải. Bấm CHẠY để xem Bìm đi nhé!';
    });
  }

  void _resetBird() {
    birdR = startR;
    birdC = startC;
    worms
      ..clear()
      ..addAll(wormsInit);
  }

  Future<void> _run() async {
    if (running || prog.isEmpty || widget.ctrl.checked) return;
    setState(() {
      running = true;
      msg = '';
      _resetBird();
    });
    bool crashed = false;
    for (final s in prog) {
      for (int k = 0; k < s.n; k++) {
        final nr = birdR + dr[s.dir];
        final nc = birdC + dc[s.dir];
        if (nr < 0 || nr >= rows || nc < 0 || nc >= cols || rocks.contains(nr * cols + nc)) {
          crashed = true;
          break;
        }
        await Future.delayed(const Duration(milliseconds: 380));
        if (!mounted) return;
        setState(() {
          birdR = nr;
          birdC = nc;
          worms.remove(nr * cols + nc);
        });
      }
      if (crashed) break;
    }
    await Future.delayed(const Duration(milliseconds: 400));
    if (!mounted) return;
    if (!crashed && worms.isEmpty) {
      setState(() {
        running = false;
        msg = 'Giỏi quá! Bìm ăn hết sâu rồi! 🎉';
      });
      widget.ctrl.finish(!widget.ctrl.penalized);
      return;
    }
    await Future.delayed(const Duration(milliseconds: 500));
    if (!mounted) return;
    setState(() {
      fails += 1;
      running = false;
      msg = crashed ? 'Ôi, Bìm đụng tường/đá rồi! Thử lại nhé.' : 'Bìm chưa ăn hết sâu 🐛. Thử lại nhé!';
      _resetBird();
    });
  }

  Widget _cell(int r, int c, double cell) {
    final idx = r * cols + c;
    Widget? inner;
    Color bg = ((r + c) % 2 == 0) ? const Color(0xFFFFF1CC) : const Color(0xFFFFE8AD);
    if (rocks.contains(idx)) {
      bg = const Color(0xFFB08968);
      inner = Container(
        margin: EdgeInsets.all(cell * 0.12),
        decoration: BoxDecoration(color: const Color(0xFF8A6A4C), borderRadius: BorderRadius.circular(10)),
      );
    } else if (worms.contains(idx)) {
      inner = Center(child: Text('🐛', style: TextStyle(fontSize: cell * 0.5)));
    }
    return Positioned(
      left: c * cell,
      top: r * cell,
      width: cell,
      height: cell,
      child: Container(color: bg, child: inner),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ex = widget.ex;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ExHeader('🗺️ Mê cung của Bìm', ex.prompt),
        if (ex.hint.isNotEmpty) BimSay(ex.hint, mood: Mood.think, size: 64, fontSize: 14),
        if (ex.hint.isNotEmpty) const SizedBox(height: 14),
        LayoutBuilder(
          builder: (context, cons) {
            final cell = math.min(58.0, cons.maxWidth / cols);
            return Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: SizedBox(
                  width: cell * cols,
                  height: cell * rows,
                  child: Stack(
                    children: [
                      for (int r = 0; r < rows; r++)
                        for (int c = 0; c < cols; c++) _cell(r, c, cell),
                      AnimatedPositioned(
                        duration: const Duration(milliseconds: 300),
                        curve: Curves.easeInOut,
                        left: birdC * cell,
                        top: birdR * cell,
                        width: cell,
                        height: cell,
                        child: Mascot(size: cell, animate: false),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 14),
        Text('Chương trình của Bìm  (khối: ${prog.length}/${ex.maxBlocks})', style: ts(14, c: AppColors.subtext)),
        const SizedBox(height: 6),
        CodeView(_code(), fontSize: 14),
        const SizedBox(height: 14),
        Row(
          children: [
            for (int d = 0; d < 4; d++)
              Expanded(
                child: Padding(
                  padding: EdgeInsets.only(right: d < 3 ? 8 : 0),
                  child: ChunkyButton(
                    height: 44,
                    radius: 12,
                    color: dir == d ? AppColors.orange : Colors.white,
                    shadow: dir == d ? AppColors.orangeDark : AppColors.border,
                    borderColor: dir == d ? null : AppColors.border,
                    onPressed: running ? null : () => setState(() => dir = d),
                    child: Icon(arrows[d], color: dir == d ? Colors.white : AppColors.text),
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Text('Số lần:', style: ts(15)),
            IconButton(
              onPressed: running ? null : () => setState(() => count = math.max(1, count - 1)),
              icon: Icon(Icons.remove_circle_outline_rounded, color: AppColors.orange),
            ),
            SizedBox(width: 22, child: Text('$count', textAlign: TextAlign.center, style: ts(20, w: FontWeight.w800))),
            IconButton(
              onPressed: running ? null : () => setState(() => count = math.min(9, count + 1)),
              icon: Icon(Icons.add_circle_outline_rounded, color: AppColors.orange),
            ),
            const Spacer(),
          ],
        ),
        ChunkyButton(
          height: 44,
          radius: 12,
          color: AppColors.yellow,
          shadow: AppColors.yellowDark,
          onPressed: running ? null : _add,
          child: ChunkyButton.label('THÊM LỆNH', color: AppColors.text, size: 14),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: ChunkyButton(
                height: 46,
                color: Colors.white,
                shadow: AppColors.border,
                borderColor: AppColors.border,
                onPressed: (running || prog.isEmpty) ? null : _removeLast,
                child: ChunkyButton.label('XOÁ LỆNH CUỐI', color: AppColors.subtext, size: 13),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: ChunkyButton(
                height: 46,
                color: AppColors.green,
                shadow: AppColors.greenDark,
                onPressed: (running || prog.isEmpty) ? null : _run,
                child: ChunkyButton.label('CHẠY  ▶', size: 15),
              ),
            ),
          ],
        ),
        if (msg.isNotEmpty) const SizedBox(height: 12),
        if (msg.isNotEmpty) Text(msg, style: ts(15, c: AppColors.orangeDark)),
        if (fails >= 3 && !widget.ctrl.checked && !running) const SizedBox(height: 10),
        if (fails >= 3 && !widget.ctrl.checked && !running)
          GestureDetector(
            onTap: _showSolution,
            child: Text('💡 Xem lời giải (mất 1 tim)', style: ts(15, c: AppColors.orange)),
          ),
      ],
    );
  }
}
