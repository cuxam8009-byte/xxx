import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'screens/home_shell.dart';
import 'state/app_state.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
      systemNavigationBarColor: Colors.white,
      systemNavigationBarIconBrightness: Brightness.dark,
    ),
  );
  await appState.load();
  runApp(BimBipApp());
}

class BimBipApp extends StatelessWidget {
  BimBipApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Bìm Bịp Python',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: HomeShell(),
    );
  }
}
