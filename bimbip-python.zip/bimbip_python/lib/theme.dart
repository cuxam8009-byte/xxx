import 'package:flutter/material.dart';

/// Bảng màu chủ đạo: cam - vàng (ấm như mật ong), giữ xanh/đỏ cho đúng/sai.
class AppColors {
  static const Color orange = Color(0xFFFF9600);
  static const Color orangeDark = Color(0xFFD97E00);
  static const Color yellow = Color(0xFFFFC800);
  static const Color yellowDark = Color(0xFFE0A800);
  static const Color amber = Color(0xFFFFAA1D);
  static const Color amberDark = Color(0xFFD98A00);
  static const Color tangerine = Color(0xFFFF7A1A);
  static const Color tangerineDark = Color(0xFFD95F00);
  static const Color honey = Color(0xFFFFF4D6);
  static const Color honeyBorder = Color(0xFFFFD98A);
  static const Color text = Color(0xFF4B3F36);
  static const Color subtext = Color(0xFF9A8F85);
  static const Color border = Color(0xFFE8E2DA);
  static const Color gray = Color(0xFFE9E4DC);
  static const Color grayDark = Color(0xFFBDB6AC);
  static const Color green = Color(0xFF58CC02);
  static const Color greenDark = Color(0xFF46A302);
  static const Color greenBg = Color(0xFFDDF8C6);
  static const Color red = Color(0xFFFF4B4B);
  static const Color redDark = Color(0xFFD93A3A);
  static const Color redBg = Color(0xFFFFE0DE);
  static const Color blue = Color(0xFF1CB0F6);

  // Màu khung code (nền tối ấm) và màu tô cú pháp
  static const Color code = Color(0xFF2B2520);
  static const Color codeText = Color(0xFFF5EFE6);
  static const Color codeKeyword = Color(0xFFFF9F43);
  static const Color codeString = Color(0xFFA6E36B);
  static const Color codeNumber = Color(0xFF6FD6FF);
  static const Color codeComment = Color(0xFF8F8576);
  static const Color codeBuiltin = Color(0xFFFFD84D);
  static const Color codeLineNo = Color(0xFF6E655A);
}

/// Đổi độ trong suốt (không dùng withOpacity để tránh cảnh báo phiên bản).
Color alpha(Color c, double opacity) => c.withAlpha((opacity * 255).round());

TextStyle ts(double size, {FontWeight w = FontWeight.w700, Color c = AppColors.text, double? h, double? ls}) {
  return TextStyle(fontSize: size, fontWeight: w, color: c, height: h, letterSpacing: ls);
}

ThemeData buildTheme() {
  final base = ThemeData.light();
  return ThemeData(
    useMaterial3: true,
    colorSchemeSeed: AppColors.orange,
    scaffoldBackgroundColor: Colors.white,
    textTheme: base.textTheme.apply(bodyColor: AppColors.text, displayColor: AppColors.text),
    splashFactory: NoSplash.splashFactory,
  );
}
