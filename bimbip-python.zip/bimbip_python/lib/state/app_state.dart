import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Tiến độ học: sao từng bài, chuỗi ngày, số "sâu" kiếm được...
class AppState extends ChangeNotifier {
  final Map<String, int> stars = {};
  int sau = 0;
  int streak = 0;
  String lastDay = '';
  int answered = 0;
  int correct = 0;
  int practiceRuns = 0;

  bool isDone(String id) => stars.containsKey(id);
  int get lessonsDone => stars.length;
  int get perfectCount => stars.values.where((s) => s >= 3).length;
  double get accuracy => answered == 0 ? 0 : correct / answered;

  String _fmt(DateTime d) {
    final m = d.month.toString().padLeft(2, '0');
    final day = d.day.toString().padLeft(2, '0');
    return '${d.year}-$m-$day';
  }

  /// Chuỗi ngày đang hiển thị (về 0 nếu bỏ lỡ hơn 1 ngày).
  int get streakShown {
    if (lastDay.isEmpty) return 0;
    final now = DateTime.now();
    if (lastDay == _fmt(now)) return streak;
    if (lastDay == _fmt(now.subtract(const Duration(days: 1)))) return streak;
    return 0;
  }

  void _touchStreak() {
    final now = DateTime.now();
    final today = _fmt(now);
    if (lastDay == today) return;
    if (lastDay == _fmt(now.subtract(const Duration(days: 1)))) {
      streak += 1;
    } else {
      streak = 1;
    }
    lastDay = today;
  }

  Future<void> load() async {
    try {
      final p = await SharedPreferences.getInstance();
      final raw = p.getString('save_v1');
      if (raw == null) return;
      final m = jsonDecode(raw);
      if (m is Map) {
        sau = _asInt(m['sau']);
        streak = _asInt(m['streak']);
        lastDay = (m['lastDay'] ?? '').toString();
        answered = _asInt(m['answered']);
        correct = _asInt(m['correct']);
        practiceRuns = _asInt(m['practiceRuns']);
        final s = m['stars'];
        if (s is Map) {
          s.forEach((k, v) {
            stars[k.toString()] = _asInt(v);
          });
        }
      }
    } catch (_) {
      // Không đọc được dữ liệu cũ: bắt đầu mới.
    }
  }

  int _asInt(dynamic v) {
    if (v is num) return v.toInt();
    return 0;
  }

  Future<void> _save() async {
    try {
      final p = await SharedPreferences.getInstance();
      final data = {
        'sau': sau,
        'streak': streak,
        'lastDay': lastDay,
        'answered': answered,
        'correct': correct,
        'practiceRuns': practiceRuns,
        'stars': stars,
      };
      await p.setString('save_v1', jsonEncode(data));
    } catch (_) {
      // Bỏ qua lỗi lưu.
    }
  }

  void completeLesson(String id, int starCount, int reward, int ok, int total) {
    final old = stars[id] ?? 0;
    if (starCount > old) stars[id] = starCount;
    sau += reward;
    answered += total;
    correct += ok;
    _touchStreak();
    notifyListeners();
    _save();
  }

  void completePractice(int reward, int ok, int total) {
    sau += reward;
    answered += total;
    correct += ok;
    practiceRuns += 1;
    _touchStreak();
    notifyListeners();
    _save();
  }

  void reset() {
    stars.clear();
    sau = 0;
    streak = 0;
    lastDay = '';
    answered = 0;
    correct = 0;
    practiceRuns = 0;
    notifyListeners();
    _save();
  }
}

final AppState appState = AppState();
