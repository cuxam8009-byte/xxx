import 'package:flutter/material.dart';
import '../widgets/mascot.dart';

/// Lớp cha của mọi dạng bài.
abstract class Exercise {
  final String explain;
  Exercise({this.explain = ''});
}

/// Thẻ học: Bìm giảng một ý nhỏ.
class TeachCard extends Exercise {
  final String title;
  final String body;
  final String? code;
  final Mood mood;
  TeachCard(this.title, this.body, {this.code, this.mood = Mood.happy});
}

/// Một trạng thái trong màn "xem Bìm chạy code".
class StepFrame {
  final int line; // dòng sắp chạy (0-based), -1 = đã xong
  final Map<String, String> vars;
  final List<String> out;
  final String note;
  StepFrame(this.line, this.vars, this.out, this.note);
}

/// Xem Bìm chạy code từng dòng, thấy "hộp biến" và màn hình thay đổi.
class StepEx extends Exercise {
  final String title;
  final String code;
  final List<StepFrame> steps;
  StepEx(this.title, this.code, this.steps);
}

/// Trắc nghiệm / đoán kết quả.
class QuizEx extends Exercise {
  final String prompt;
  final List<String> options;
  final int answer;
  final String? code;
  final bool mono;
  QuizEx(this.prompt, this.options, this.answer, {this.code, this.mono = false, String explain = ''})
      : super(explain: explain);
}

/// Ghép khối code thành một dòng lệnh.
class BlocksEx extends Exercise {
  final String prompt;
  final List<String> answer;
  final List<String> extras;
  final String? show;
  BlocksEx(this.prompt, this.answer, this.extras, {this.show, String explain = ''}) : super(explain: explain);
}

/// Điền chỗ trống trong code ({0}, {1}... là các chỗ trống).
class FillEx extends Exercise {
  final String prompt;
  final String code;
  final List<String> options;
  final List<String> answers;
  FillEx(this.prompt, this.code, this.options, this.answers, {String explain = ''}) : super(explain: explain);
}

/// Bìm bắt sâu: chạm vào dòng bị lỗi.
class BugEx extends Exercise {
  final String prompt;
  final List<String> lines;
  final int bugLine;
  BugEx(this.prompt, this.lines, this.bugLine, {String explain = ''}) : super(explain: explain);
}

/// Kéo thả sắp xếp các dòng code đúng thứ tự.
class OrderEx extends Exercise {
  final String prompt;
  final List<String> lines;
  OrderEx(this.prompt, this.lines, {String explain = ''}) : super(explain: explain);
}

/// Nối cặp.
class MatchEx extends Exercise {
  final String prompt;
  final List<List<String>> pairs;
  final bool monoLeft;
  final bool monoRight;
  MatchEx(this.prompt, this.pairs, {this.monoLeft = true, this.monoRight = false, String explain = ''})
      : super(explain: explain);
}

class SwipeCard {
  final String text;
  final bool truth;
  final String why;
  final bool isCode;
  SwipeCard(this.text, this.truth, this.why, {this.isCode = false});
}

/// Vuốt thẻ đúng / sai.
class SwipeEx extends Exercise {
  final String prompt;
  final String rightLabel;
  final String leftLabel;
  final List<SwipeCard> cards;
  SwipeEx(this.prompt, this.cards, {this.rightLabel = 'Đúng', this.leftLabel = 'Sai', String explain = ''})
      : super(explain: explain);
}

class SortItem {
  final String text;
  final int bucket;
  SortItem(this.text, this.bucket);
}

/// Nhặt đồ bỏ vào đúng giỏ (phân loại).
class SortEx extends Exercise {
  final String prompt;
  final List<String> buckets;
  final List<SortItem> items;
  SortEx(this.prompt, this.buckets, this.items, {String explain = ''}) : super(explain: explain);
}

/// Mê cung: lập trình cho Bìm đi ăn sâu.
class MazeEx extends Exercise {
  final String prompt;
  final List<String> grid; // B = Bìm, W = sâu, # = đá, . = cỏ
  final int maxBlocks;
  final List<List<int>> solution; // mỗi phần tử: [hướng, số lần]; hướng 0=lên 1=xuống 2=trái 3=phải
  final String hint;
  MazeEx(this.prompt, this.grid, this.maxBlocks, this.solution, {this.hint = '', String explain = ''})
      : super(explain: explain);
}

/// Tự gõ code.
class TypeEx extends Exercise {
  final String prompt;
  final List<String> answers;
  final String hint;
  final bool multiline;
  TypeEx(this.prompt, this.answers, {this.hint = '', this.multiline = false, String explain = ''})
      : super(explain: explain);
}

class Lesson {
  final String id;
  final String title;
  final String subtitle;
  final String icon;
  final String note;
  final String noteCode;
  final List<Exercise> items;
  Lesson(this.id, this.title, this.subtitle, this.icon, this.note, this.noteCode, this.items);
}

class Unit {
  final String id;
  final String title;
  final String subtitle;
  final String emoji;
  final Color color;
  final Color dark;
  final List<Lesson> lessons;
  Unit(this.id, this.title, this.subtitle, this.emoji, this.color, this.dark, this.lessons);
}

/// Bộ điều khiển trao đổi giữa màn làm bài và từng dạng bài.
class ExController extends ChangeNotifier {
  bool ready = false;
  bool checked = false;
  bool correct = false;
  bool penalized = false;
  String correctText = '';
  bool Function()? checker;
  void Function(bool ok)? finishCb;
  VoidCallback? mistakeCb;

  void setReady(bool v) {
    if (ready == v) return;
    ready = v;
    notifyListeners();
  }

  /// Dùng trong initState: bật nút kiểm tra sau khi khung hình đầu tiên vẽ xong.
  void setReadyLater(bool v) {
    Future.microtask(() => setReady(v));
  }

  void mistake() {
    if (mistakeCb != null) mistakeCb!();
  }

  void finish(bool ok) {
    if (finishCb != null) finishCb!(ok);
  }
}
